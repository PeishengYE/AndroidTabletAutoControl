package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import o.afe;
import o.afl;
import o.ahi;
import o.ahk;

public final class Status
  implements SafeParcelable
{
  public static final Parcelable.Creator<Status> CREATOR = new afl();
  public static final Status a = new Status(0);
  public static final Status b = new Status(14);
  public static final Status c = new Status(8);
  public static final Status d = new Status(15);
  public static final Status e = new Status(16);
  private final int f;
  private final int g;
  private final String h;
  private final PendingIntent i;
  
  public Status(int paramInt)
  {
    this(paramInt, null);
  }
  
  public Status(int paramInt1, int paramInt2, String paramString, PendingIntent paramPendingIntent)
  {
    this.f = paramInt1;
    this.g = paramInt2;
    this.h = paramString;
    this.i = paramPendingIntent;
  }
  
  public Status(int paramInt, String paramString)
  {
    this(1, paramInt, paramString, null);
  }
  
  private String f()
  {
    if (this.h != null) {
      return this.h;
    }
    return afe.a(this.g);
  }
  
  public PendingIntent a()
  {
    return this.i;
  }
  
  public String b()
  {
    return this.h;
  }
  
  public int c()
  {
    return this.f;
  }
  
  public boolean d()
  {
    return this.g <= 0;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public int e()
  {
    return this.g;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Status)) {}
    do
    {
      return false;
      paramObject = (Status)paramObject;
    } while ((this.f != ((Status)paramObject).f) || (this.g != ((Status)paramObject).g) || (!ahi.a(this.h, ((Status)paramObject).h)) || (!ahi.a(this.i, ((Status)paramObject).i)));
    return true;
  }
  
  public int hashCode()
  {
    return ahi.a(new Object[] { Integer.valueOf(this.f), Integer.valueOf(this.g), this.h, this.i });
  }
  
  public String toString()
  {
    return ahi.a(this).a("statusCode", f()).a("resolution", this.i).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    afl.a(this, paramParcel, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/common/api/Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */