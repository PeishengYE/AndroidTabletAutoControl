package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import o.aij;
import o.aim;
import o.aio;
import o.aiq;
import o.ais;
import o.aiu;
import o.aiw;
import o.akn;

public class FlagProviderImpl
  extends akn
{
  private boolean a = false;
  private SharedPreferences b;
  
  public boolean getBooleanFlagValue(String paramString, boolean paramBoolean, int paramInt)
  {
    return aio.a(this.b, paramString, Boolean.valueOf(paramBoolean)).booleanValue();
  }
  
  public int getIntFlagValue(String paramString, int paramInt1, int paramInt2)
  {
    return aiq.a(this.b, paramString, Integer.valueOf(paramInt1)).intValue();
  }
  
  public long getLongFlagValue(String paramString, long paramLong, int paramInt)
  {
    return ais.a(this.b, paramString, Long.valueOf(paramLong)).longValue();
  }
  
  public String getStringFlagValue(String paramString1, String paramString2, int paramInt)
  {
    return aiu.a(this.b, paramString1, paramString2);
  }
  
  public void init(aij paramaij)
  {
    paramaij = (Context)aim.a(paramaij);
    if (this.a) {
      return;
    }
    try
    {
      this.b = aiw.a(paramaij.createPackageContext("com.google.android.gms", 0));
      this.a = true;
      return;
    }
    catch (PackageManager.NameNotFoundException paramaij) {}
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/flags/impl/FlagProviderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */