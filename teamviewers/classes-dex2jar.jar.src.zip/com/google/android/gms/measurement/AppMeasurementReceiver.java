package com.google.android.gms.measurement;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import o.ahl;
import o.alq;
import o.anj;
import o.anm;
import o.aof;
import o.aoh;
import o.apa;

public final class AppMeasurementReceiver
  extends BroadcastReceiver
{
  static final Object a = new Object();
  static alq b;
  static Boolean c;
  
  public static boolean a(Context paramContext)
  {
    ahl.a(paramContext);
    if (c != null) {
      return c.booleanValue();
    }
    boolean bool = anj.a(paramContext, AppMeasurementReceiver.class, false);
    c = Boolean.valueOf(bool);
    return bool;
  }
  
  public void onReceive(Context paramContext, Intent arg2)
  {
    Object localObject = apa.a(paramContext);
    localaof = ((apa)localObject).f();
    ??? = ???.getAction();
    if (((apa)localObject).d().N()) {
      localaof.z().a("Device AppMeasurementReceiver got", ???);
    }
    for (;;)
    {
      boolean bool;
      if ("com.google.android.gms.measurement.UPLOAD".equals(???))
      {
        bool = AppMeasurementService.a(paramContext);
        localObject = new Intent(paramContext, AppMeasurementService.class);
        ((Intent)localObject).setAction("com.google.android.gms.measurement.UPLOAD");
      }
      synchronized (a)
      {
        paramContext.startService((Intent)localObject);
        if (!bool)
        {
          return;
          localaof.z().a("Local AppMeasurementReceiver got", ???);
          continue;
        }
        try
        {
          if (b == null)
          {
            b = new alq(paramContext, 1, "AppMeasurement WakeLock");
            b.a(false);
          }
          b.a(1000L);
        }
        catch (SecurityException paramContext)
        {
          for (;;)
          {
            localaof.c().a("AppMeasurementService at risk of not starting. For more reliable app measurements, add the WAKE_LOCK permission to your manifest.");
          }
        }
        return;
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/measurement/AppMeasurementReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */