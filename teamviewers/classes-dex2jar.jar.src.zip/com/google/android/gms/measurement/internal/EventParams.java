package com.google.android.gms.measurement.internal;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.Iterator;
import o.ahl;
import o.amd;
import o.anw;

public class EventParams
  implements SafeParcelable, Iterable<String>
{
  public static final anw CREATOR = new anw();
  public final int a;
  private final Bundle b;
  
  public EventParams(int paramInt, Bundle paramBundle)
  {
    this.a = paramInt;
    this.b = paramBundle;
  }
  
  public EventParams(Bundle paramBundle)
  {
    ahl.a(paramBundle);
    this.b = paramBundle;
    this.a = 1;
  }
  
  public int a()
  {
    return this.b.size();
  }
  
  public Object a(String paramString)
  {
    return this.b.get(paramString);
  }
  
  public Bundle b()
  {
    return new Bundle(this.b);
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public Iterator<String> iterator()
  {
    return new amd(this);
  }
  
  public String toString()
  {
    return this.b.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    anw.a(this, paramParcel, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/measurement/internal/EventParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */