package com.google.android.gms.measurement.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import o.ahl;
import o.anh;
import o.ani;

public class UserAttributeParcel
  implements SafeParcelable
{
  public static final anh CREATOR = new anh();
  public final int a;
  public final String b;
  public final long c;
  public final Long d;
  public final Float e;
  public final String f;
  public final String g;
  
  public UserAttributeParcel(int paramInt, String paramString1, long paramLong, Long paramLong1, Float paramFloat, String paramString2, String paramString3)
  {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramLong;
    this.d = paramLong1;
    this.e = paramFloat;
    this.f = paramString2;
    this.g = paramString3;
  }
  
  public UserAttributeParcel(String paramString1, long paramLong, Object paramObject, String paramString2)
  {
    ahl.a(paramString1);
    this.a = 1;
    this.b = paramString1;
    this.c = paramLong;
    this.g = paramString2;
    if (paramObject == null)
    {
      this.d = null;
      this.e = null;
      this.f = null;
      return;
    }
    if ((paramObject instanceof Long))
    {
      this.d = ((Long)paramObject);
      this.e = null;
      this.f = null;
      return;
    }
    if ((paramObject instanceof Float))
    {
      this.d = null;
      this.e = ((Float)paramObject);
      this.f = null;
      return;
    }
    if ((paramObject instanceof String))
    {
      this.d = null;
      this.e = null;
      this.f = ((String)paramObject);
      return;
    }
    throw new IllegalArgumentException("User attribute given of un-supported type");
  }
  
  public UserAttributeParcel(ani paramani)
  {
    this(paramani.b, paramani.c, paramani.d, paramani.a);
  }
  
  public Object a()
  {
    if (this.d != null) {
      return this.d;
    }
    if (this.e != null) {
      return this.e;
    }
    if (this.f != null) {
      return this.f;
    }
    return null;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    anh.a(this, paramParcel, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/measurement/internal/UserAttributeParcel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */