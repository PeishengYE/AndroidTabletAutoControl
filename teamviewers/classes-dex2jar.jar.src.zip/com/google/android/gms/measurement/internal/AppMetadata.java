package com.google.android.gms.measurement.internal;

import android.os.Parcel;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import o.ahl;
import o.ank;

public class AppMetadata
  implements SafeParcelable
{
  public static final ank CREATOR = new ank();
  public final int a;
  public final String b;
  public final String c;
  public final String d;
  public final String e;
  public final long f;
  public final long g;
  public final String h;
  public final boolean i;
  public final boolean j;
  
  public AppMetadata(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramString4;
    this.f = paramLong1;
    this.g = paramLong2;
    this.h = paramString5;
    if (paramInt >= 3) {}
    for (this.i = paramBoolean1;; this.i = true)
    {
      this.j = paramBoolean2;
      return;
    }
  }
  
  public AppMetadata(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, boolean paramBoolean1, boolean paramBoolean2)
  {
    ahl.a(paramString1);
    this.a = 4;
    this.b = paramString1;
    paramString1 = paramString2;
    if (TextUtils.isEmpty(paramString2)) {
      paramString1 = null;
    }
    this.c = paramString1;
    this.d = paramString3;
    this.e = paramString4;
    this.f = paramLong1;
    this.g = paramLong2;
    this.h = paramString5;
    this.i = paramBoolean1;
    this.j = paramBoolean2;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    ank.a(this, paramParcel, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/measurement/internal/AppMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */