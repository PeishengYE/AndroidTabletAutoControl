package com.google.android.gms.measurement;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import o.ahl;
import o.alq;
import o.amb;
import o.anj;
import o.anm;
import o.aof;
import o.aoh;
import o.aow;
import o.apa;
import o.apf;

public final class AppMeasurementService
  extends Service
{
  private static Boolean b;
  private final Handler a = new Handler();
  
  private void a()
  {
    try
    {
      synchronized (AppMeasurementReceiver.a)
      {
        alq localalq = AppMeasurementReceiver.b;
        if ((localalq != null) && (localalq.b())) {
          localalq.a();
        }
        return;
      }
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public static boolean a(Context paramContext)
  {
    ahl.a(paramContext);
    if (b != null) {
      return b.booleanValue();
    }
    boolean bool = anj.a(paramContext, AppMeasurementService.class);
    b = Boolean.valueOf(bool);
    return bool;
  }
  
  private aof b()
  {
    return apa.a(this).f();
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    if (paramIntent == null)
    {
      b().b().a("onBind called with null intent");
      return null;
    }
    paramIntent = paramIntent.getAction();
    if ("com.google.android.gms.measurement.START".equals(paramIntent)) {
      return new apf(apa.a(this));
    }
    b().c().a("onBind received unknown action", paramIntent);
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    apa localapa = apa.a(this);
    aof localaof = localapa.f();
    if (localapa.d().N())
    {
      localaof.z().a("Device AppMeasurementService is starting up");
      return;
    }
    localaof.z().a("Local AppMeasurementService is starting up");
  }
  
  public void onDestroy()
  {
    apa localapa = apa.a(this);
    aof localaof = localapa.f();
    if (localapa.d().N()) {
      localaof.z().a("Device AppMeasurementService is shutting down");
    }
    for (;;)
    {
      super.onDestroy();
      return;
      localaof.z().a("Local AppMeasurementService is shutting down");
    }
  }
  
  public void onRebind(Intent paramIntent)
  {
    if (paramIntent == null)
    {
      b().b().a("onRebind called with null intent");
      return;
    }
    paramIntent = paramIntent.getAction();
    b().z().a("onRebind called. action", paramIntent);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    a();
    apa localapa = apa.a(this);
    aof localaof = localapa.f();
    paramIntent = paramIntent.getAction();
    if (localapa.d().N()) {
      localaof.z().a("Device AppMeasurementService called. startId, action", Integer.valueOf(paramInt2), paramIntent);
    }
    for (;;)
    {
      if ("com.google.android.gms.measurement.UPLOAD".equals(paramIntent)) {
        localapa.h().a(new amb(this, localapa, paramInt2, localaof));
      }
      return 2;
      localaof.z().a("Local AppMeasurementService called. startId, action", Integer.valueOf(paramInt2), paramIntent);
    }
  }
  
  public boolean onUnbind(Intent paramIntent)
  {
    if (paramIntent == null)
    {
      b().b().a("onUnbind called with null intent");
      return true;
    }
    paramIntent = paramIntent.getAction();
    b().z().a("onUnbind called for intent. action", paramIntent);
    return true;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/measurement/AppMeasurementService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */