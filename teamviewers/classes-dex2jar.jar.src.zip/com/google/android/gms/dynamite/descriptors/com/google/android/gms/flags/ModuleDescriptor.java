package com.google.android.gms.dynamite.descriptors.com.google.android.gms.flags;

public class ModuleDescriptor
{
  public static final String MODULE_ID = "com.google.android.gms.flags";
  public static final int MODULE_VERSION = 1;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/google/android/gms/dynamite/descriptors/com/google/android/gms/flags/ModuleDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */