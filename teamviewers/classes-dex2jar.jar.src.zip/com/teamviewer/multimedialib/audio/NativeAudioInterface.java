package com.teamviewer.multimedialib.audio;

import com.teamviewer.corelib.logging.Logging;
import o.bbx;
import o.byv;

public class NativeAudioInterface
{
  @byv
  private void callbackHandleEnableNoiseGate(boolean paramBoolean)
  {
    bbx.a().b(paramBoolean);
  }
  
  @byv
  private void callbackHandleEvent(int paramInt)
  {
    Logging.b("NativeAudio_", "native event triggered: " + paramInt);
  }
  
  @byv
  private void callbackHandleRecordedData(byte[] paramArrayOfByte)
  {
    bbx.a().a(paramArrayOfByte);
  }
  
  public native boolean addAudioSourceToMixedSource(long paramLong1, long paramLong2);
  
  public native boolean createAudioSourceFile(long paramLong, int paramInt1, int paramInt2);
  
  public native boolean createAudioSourceMixed(long paramLong, int paramInt1, int paramInt2);
  
  public native boolean createAudioSourceOpus(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public native boolean createAudioSourcePCM(long paramLong, int paramInt1, int paramInt2);
  
  public native boolean createAudioSourceSpeex(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
  
  public native boolean destroyAudioSource(long paramLong);
  
  public native boolean handleNoiseGate(long paramLong, boolean paramBoolean);
  
  public native boolean initAudioRemoteSound(int paramInt1, int paramInt2, int paramInt3);
  
  public native boolean initAudioVOIP();
  
  public native boolean playAudio(boolean paramBoolean);
  
  public native boolean playRemoteAudio(boolean paramBoolean);
  
  public native boolean recordAudio(boolean paramBoolean);
  
  public native boolean removeAudioSourceFromMixedSource(long paramLong1, long paramLong2);
  
  public native boolean setAudioSourceRemoteSound(long paramLong);
  
  public native boolean setAudioSourceVOIP(long paramLong);
  
  public native boolean shutdownAudio();
  
  public native boolean updateAudioSourceRemoteSound(long paramLong1, long paramLong2);
  
  public native boolean updateAudioSourceVOIP(long paramLong, byte[] paramArrayOfByte);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/multimedialib/audio/NativeAudioInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */