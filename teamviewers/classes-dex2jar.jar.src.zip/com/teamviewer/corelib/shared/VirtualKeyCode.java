package com.teamviewer.corelib.shared;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import o.baq;

public enum VirtualKeyCode
  implements Parcelable
{
  public static final Parcelable.Creator<VirtualKeyCode> CREATOR = new baq();
  private final int aV;
  private final int aW;
  
  static
  {
    A = new VirtualKeyCode("VK_4", 26, 52, 11);
    B = new VirtualKeyCode("VK_5", 27, 53, 12);
    C = new VirtualKeyCode("VK_6", 28, 54, 13);
    D = new VirtualKeyCode("VK_7", 29, 55, 14);
    E = new VirtualKeyCode("VK_8", 30, 56, 15);
    F = new VirtualKeyCode("VK_9", 31, 57, 16);
    G = new VirtualKeyCode("VK_A", 32, 65, 29);
    H = new VirtualKeyCode("VK_B", 33, 66, 30);
    I = new VirtualKeyCode("VK_C", 34, 67, 31);
    J = new VirtualKeyCode("VK_D", 35, 68, 32);
    K = new VirtualKeyCode("VK_E", 36, 69, 33);
    L = new VirtualKeyCode("VK_F", 37, 70, 34);
    M = new VirtualKeyCode("VK_G", 38, 71, 35);
    N = new VirtualKeyCode("VK_H", 39, 72, 36);
    O = new VirtualKeyCode("VK_I", 40, 73, 37);
    P = new VirtualKeyCode("VK_J", 41, 74, 38);
    Q = new VirtualKeyCode("VK_K", 42, 75, 39);
    R = new VirtualKeyCode("VK_L", 43, 76, 40);
    S = new VirtualKeyCode("VK_M", 44, 77, 41);
    T = new VirtualKeyCode("VK_N", 45, 78, 42);
    U = new VirtualKeyCode("VK_O", 46, 79, 43);
    V = new VirtualKeyCode("VK_P", 47, 80, 44);
    W = new VirtualKeyCode("VK_Q", 48, 81, 45);
    X = new VirtualKeyCode("VK_R", 49, 82, 46);
    Y = new VirtualKeyCode("VK_S", 50, 83, 47);
    Z = new VirtualKeyCode("VK_T", 51, 84, 48);
    aa = new VirtualKeyCode("VK_U", 52, 85, 49);
    ab = new VirtualKeyCode("VK_V", 53, 86, 50);
    ac = new VirtualKeyCode("VK_W", 54, 87, 51);
    ad = new VirtualKeyCode("VK_X", 55, 88, 52);
    ae = new VirtualKeyCode("VK_Y", 56, 89, 53);
    af = new VirtualKeyCode("VK_Z", 57, 90, 54);
    ag = new VirtualKeyCode("VK_LWIN", 58, 91, 3);
    ah = new VirtualKeyCode("VK_RWIN", 59, 92, 3);
    ai = new VirtualKeyCode("VK_APPS", 60, 93, 82);
    aj = new VirtualKeyCode("VK_NUMPAD0", 61, 96, 7);
    ak = new VirtualKeyCode("VK_NUMPAD1", 62, 97, 8);
    al = new VirtualKeyCode("VK_NUMPAD2", 63, 98, 9);
    am = new VirtualKeyCode("VK_NUMPAD3", 64, 99, 10);
    an = new VirtualKeyCode("VK_NUMPAD4", 65, 100, 11);
    ao = new VirtualKeyCode("VK_NUMPAD5", 66, 101, 12);
    ap = new VirtualKeyCode("VK_NUMPAD6", 67, 102, 13);
    aq = new VirtualKeyCode("VK_NUMPAD7", 68, 103, 14);
    ar = new VirtualKeyCode("VK_NUMPAD8", 69, 104, 15);
    as = new VirtualKeyCode("VK_NUMPAD9", 70, 105, 16);
    at = new VirtualKeyCode("VK_NUMPAD_MUL", 71, 106, 17);
    au = new VirtualKeyCode("VK_NUMPAD_ADD", 72, 107, 81);
    av = new VirtualKeyCode("VK_NUMPAD_SUB", 73, 109, 69);
    aw = new VirtualKeyCode("VK_NUMPAD_COMMA", 74, 110, 55);
    ax = new VirtualKeyCode("VK_NUMPAD_DIV", 75, 111, 76);
    ay = new VirtualKeyCode("VK_F1", 76, 112, 131);
    az = new VirtualKeyCode("VK_F2", 77, 113, 132);
    aA = new VirtualKeyCode("VK_F3", 78, 114, 133);
    aB = new VirtualKeyCode("VK_F4", 79, 115, 134);
    aC = new VirtualKeyCode("VK_F5", 80, 116, 135);
    aD = new VirtualKeyCode("VK_F6", 81, 117, 136);
    aE = new VirtualKeyCode("VK_F7", 82, 118, 137);
    aF = new VirtualKeyCode("VK_F8", 83, 119, 138);
    aG = new VirtualKeyCode("VK_F9", 84, 120, 139);
    aH = new VirtualKeyCode("VK_F10", 85, 121, 140);
    aI = new VirtualKeyCode("VK_F11", 86, 122, 141);
    aJ = new VirtualKeyCode("VK_F12", 87, 123, 142);
    aK = new VirtualKeyCode("VK_SCROLL", 88, 145, 0);
    aL = new VirtualKeyCode("VK_LSHIFT", 89, 160, 0);
    aM = new VirtualKeyCode("VK_RSHIFT", 90, 161, 0);
    aN = new VirtualKeyCode("VK_LCONTROL", 91, 162, 0);
    aO = new VirtualKeyCode("VK_RCONTROL", 92, 163, 0);
    aP = new VirtualKeyCode("VK_LALT", 93, 164, 0);
    aQ = new VirtualKeyCode("VK_RALT", 94, 165, 0);
    aR = new VirtualKeyCode("VK_MEDIA_NEXT_TRACK", 95, 176, 87);
    aS = new VirtualKeyCode("VK_MEDIA_PREV_TRACK", 96, 177, 88);
    aT = new VirtualKeyCode("VK_MEDIA_STOP", 97, 178, 86);
    aU = new VirtualKeyCode("VK_MEDIA_PLAY_PAUSE", 98, 179, 85);
    aX = new VirtualKeyCode[] { a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, aa, ab, ac, ad, ae, af, ag, ah, ai, aj, ak, al, am, an, ao, ap, aq, ar, as, at, au, av, aw, ax, ay, az, aA, aB, aC, aD, aE, aF, aG, aH, aI, aJ, aK, aL, aM, aN, aO, aP, aQ, aR, aS, aT, aU };
  }
  
  private VirtualKeyCode(int paramInt1, int paramInt2)
  {
    this.aV = paramInt1;
    this.aW = paramInt2;
  }
  
  public static VirtualKeyCode a(int paramInt)
  {
    VirtualKeyCode[] arrayOfVirtualKeyCode = values();
    int i2 = arrayOfVirtualKeyCode.length;
    int i1 = 0;
    while (i1 < i2)
    {
      VirtualKeyCode localVirtualKeyCode = arrayOfVirtualKeyCode[i1];
      if (paramInt == localVirtualKeyCode.a()) {
        return localVirtualKeyCode;
      }
      i1 += 1;
    }
    return null;
  }
  
  public int a()
  {
    return this.aV;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(a());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/corelib/shared/VirtualKeyCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */