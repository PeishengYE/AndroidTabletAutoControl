package com.teamviewer.corelib.logging;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import o.ban;
import o.bao;

public final class Logging
{
  public static final boolean a;
  private static String b = "";
  private static boolean c = true;
  private static boolean d = false;
  
  static
  {
    try
    {
      bao.a(ban.a(), "logging");
      b("Logging", "native logging library loaded");
    }
    catch (Throwable localThrowable)
    {
      for (;;)
      {
        localThrowable.printStackTrace();
        a = false;
      }
    }
    finally
    {
      a = false;
    }
  }
  
  private static native void InitNativeLogging(String paramString1, String paramString2);
  
  private static native void LogNative(int paramInt, String paramString1, String paramString2);
  
  private static native void RotateLogFiles();
  
  private static native void SetNativeLogLevel(int paramInt);
  
  private static native void SetNativeLogOptions(boolean paramBoolean1, boolean paramBoolean2);
  
  private static int a(int paramInt)
  {
    int i = 3;
    if (paramInt >= 3) {
      i = 6;
    }
    do
    {
      return i;
      if (paramInt >= 2) {
        return 5;
      }
    } while (paramInt < 1);
    return 4;
  }
  
  public static void a()
  {
    try
    {
      if (a) {
        RotateLogFiles();
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public static void a(String paramString)
  {
    if (paramString != null) {}
    try
    {
      b = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  private static void a(String paramString1, int paramInt, String paramString2)
  {
    if ((a) && (c) && ((d) || (paramInt >= 1))) {
      LogNative(a(paramInt), paramString1, paramString2);
    }
  }
  
  public static void a(String paramString1, String paramString2)
  {
    try
    {
      a(paramString1, 0, paramString2);
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
  
  public static void a(String paramString1, String paramString2, Object... paramVarArgs)
  {
    try
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Formatter localFormatter = new Formatter(localStringBuilder);
      localFormatter.format(paramString2, paramVarArgs);
      a(paramString1, 1, localStringBuilder.toString());
      localFormatter.close();
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
  
  public static void a(String paramString, Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    d(paramString, localStringWriter.toString());
  }
  
  /* Error */
  public static void a(boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: getstatic 35	com/teamviewer/corelib/logging/Logging:a	Z
    //   6: ifeq +17 -> 23
    //   9: iload_0
    //   10: ifeq +17 -> 27
    //   13: iconst_2
    //   14: istore_1
    //   15: iload_1
    //   16: invokestatic 106	com/teamviewer/corelib/logging/Logging:SetNativeLogLevel	(I)V
    //   19: iload_0
    //   20: putstatic 43	com/teamviewer/corelib/logging/Logging:d	Z
    //   23: ldc 2
    //   25: monitorexit
    //   26: return
    //   27: iconst_1
    //   28: invokestatic 62	com/teamviewer/corelib/logging/Logging:a	(I)I
    //   31: istore_1
    //   32: goto -17 -> 15
    //   35: astore_2
    //   36: ldc 2
    //   38: monitorexit
    //   39: aload_2
    //   40: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	41	0	paramBoolean	boolean
    //   14	18	1	i	int
    //   35	5	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   3	9	35	finally
    //   15	23	35	finally
    //   27	32	35	finally
  }
  
  /* Error */
  public static void a(boolean paramBoolean, android.content.Context paramContext)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: iload_0
    //   4: putstatic 41	com/teamviewer/corelib/logging/Logging:c	Z
    //   7: getstatic 41	com/teamviewer/corelib/logging/Logging:c	Z
    //   10: istore_0
    //   11: iload_0
    //   12: ifeq +76 -> 88
    //   15: iconst_1
    //   16: invokestatic 62	com/teamviewer/corelib/logging/Logging:a	(I)I
    //   19: invokestatic 106	com/teamviewer/corelib/logging/Logging:SetNativeLogLevel	(I)V
    //   22: getstatic 41	com/teamviewer/corelib/logging/Logging:c	Z
    //   25: iconst_0
    //   26: invokestatic 111	com/teamviewer/corelib/logging/Logging:SetNativeLogOptions	(ZZ)V
    //   29: aload_1
    //   30: invokevirtual 117	android/content/Context:getFilesDir	()Ljava/io/File;
    //   33: invokevirtual 122	java/io/File:getPath	()Ljava/lang/String;
    //   36: astore_1
    //   37: new 69	java/lang/StringBuilder
    //   40: dup
    //   41: invokespecial 72	java/lang/StringBuilder:<init>	()V
    //   44: aload_1
    //   45: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: ldc -128
    //   50: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: ldc -126
    //   55: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   61: new 69	java/lang/StringBuilder
    //   64: dup
    //   65: invokespecial 72	java/lang/StringBuilder:<init>	()V
    //   68: aload_1
    //   69: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: ldc -128
    //   74: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: ldc -124
    //   79: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   85: invokestatic 134	com/teamviewer/corelib/logging/Logging:InitNativeLogging	(Ljava/lang/String;Ljava/lang/String;)V
    //   88: ldc 2
    //   90: monitorexit
    //   91: return
    //   92: astore_2
    //   93: aload_2
    //   94: invokevirtual 135	java/lang/UnsatisfiedLinkError:printStackTrace	()V
    //   97: goto -68 -> 29
    //   100: astore_1
    //   101: ldc 2
    //   103: monitorexit
    //   104: aload_1
    //   105: athrow
    //   106: astore_1
    //   107: aload_1
    //   108: invokevirtual 135	java/lang/UnsatisfiedLinkError:printStackTrace	()V
    //   111: goto -23 -> 88
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	114	0	paramBoolean	boolean
    //   0	114	1	paramContext	android.content.Context
    //   92	2	2	localUnsatisfiedLinkError	UnsatisfiedLinkError
    // Exception table:
    //   from	to	target	type
    //   15	29	92	java/lang/UnsatisfiedLinkError
    //   3	11	100	finally
    //   15	29	100	finally
    //   29	37	100	finally
    //   37	88	100	finally
    //   93	97	100	finally
    //   107	111	100	finally
    //   37	88	106	java/lang/UnsatisfiedLinkError
  }
  
  public static String b()
  {
    return "TVLog.html";
  }
  
  public static void b(String paramString1, String paramString2)
  {
    try
    {
      a(paramString1, 1, paramString2);
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
  
  public static List<String> c()
  {
    Object localObject = new ArrayList();
    ArrayList localArrayList = new ArrayList();
    ((List)localObject).add(b + "/" + "TVLog.html");
    ((List)localObject).add(b + "/" + "TVLogOld.html");
    ((List)localObject).add(b + "/" + "TVLog_n.txt");
    ((List)localObject).add(b + "/" + "TVLog_n_old.txt");
    ((List)localObject).add(b + "/" + "TVLog_nr.txt");
    ((List)localObject).add(b + "/" + "TVLog_nr_old.txt");
    ((List)localObject).add(b + "/" + "TVLog_r.html");
    ((List)localObject).add(b + "/" + "TVLog_r_old.html");
    localObject = ((List)localObject).iterator();
    while (((Iterator)localObject).hasNext())
    {
      String str = (String)((Iterator)localObject).next();
      if (new File(str).exists()) {
        localArrayList.add(str);
      }
    }
    return localArrayList;
  }
  
  public static void c(String paramString1, String paramString2)
  {
    try
    {
      a(paramString1, 2, paramString2);
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
  
  public static void d(String paramString1, String paramString2)
  {
    try
    {
      a(paramString1, 3, paramString2);
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
  
  public static void e(String paramString1, String paramString2)
  {
    try
    {
      a(paramString1, 4, paramString2);
      return;
    }
    finally
    {
      paramString1 = finally;
      throw paramString1;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/corelib/logging/Logging.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */