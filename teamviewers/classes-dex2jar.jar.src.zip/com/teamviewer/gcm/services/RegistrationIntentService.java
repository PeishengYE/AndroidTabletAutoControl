package com.teamviewer.gcm.services;

import android.app.IntentService;
import android.content.Intent;
import com.teamviewer.corelib.logging.Logging;
import o.ajg;
import o.bbu;
import o.bbw;

public class RegistrationIntentService
  extends IntentService
{
  public RegistrationIntentService()
  {
    super("RegistrationIntentService");
  }
  
  protected void onHandleIntent(Intent paramIntent)
  {
    Logging.b("RegistrationIntentService", "onHandleIntent");
    try
    {
      paramIntent = ajg.b(this).a(getString(bbu.tv_gcm_sender_id), "GCM", null);
      Logging.b("RegistrationIntentService", "GCM Registration Token: " + paramIntent);
      bbw.a(paramIntent);
      return;
    }
    catch (Exception paramIntent)
    {
      Logging.d("RegistrationIntentService", "Failed to complete token refresh: " + paramIntent);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/gcm/services/RegistrationIntentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */