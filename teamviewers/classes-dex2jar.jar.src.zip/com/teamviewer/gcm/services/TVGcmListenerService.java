package com.teamviewer.gcm.services;

import android.os.Bundle;
import o.aiy;
import o.bbv;
import o.bbw;

public class TVGcmListenerService
  extends aiy
{
  public void a(String paramString, Bundle paramBundle)
  {
    paramString = bbw.c();
    if (paramString != null) {
      paramString.a(paramBundle);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/gcm/services/TVGcmListenerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */