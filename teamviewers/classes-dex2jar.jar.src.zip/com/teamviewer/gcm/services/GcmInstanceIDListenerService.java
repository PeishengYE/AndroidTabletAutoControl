package com.teamviewer.gcm.services;

import android.content.Intent;
import com.teamviewer.corelib.logging.Logging;
import o.ajh;

public class GcmInstanceIDListenerService
  extends ajh
{
  public void b()
  {
    Logging.c("GcmInstanceIDListenerService", "token refresh triggered");
    startService(new Intent(this, RegistrationIntentService.class));
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/gcm/services/GcmInstanceIDListenerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */