package com.teamviewer.gcm.swig;

public class PushNotificationRegistrationWrapper
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PushNotificationRegistrationWrapper()
  {
    this(PushNotificationRegistrationWrapperSWIGJNI.new_PushNotificationRegistrationWrapper(), true);
  }
  
  public PushNotificationRegistrationWrapper(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(PushNotificationRegistrationWrapper paramPushNotificationRegistrationWrapper)
  {
    if (paramPushNotificationRegistrationWrapper == null) {
      return 0L;
    }
    return paramPushNotificationRegistrationWrapper.swigCPtr;
  }
  
  public boolean CreatePushNotificationRegistration(String paramString1, String paramString2)
  {
    return PushNotificationRegistrationWrapperSWIGJNI.PushNotificationRegistrationWrapper_CreatePushNotificationRegistration(this.swigCPtr, this, paramString1, paramString2);
  }
  
  public boolean DestroyPushNotificationRegistration()
  {
    return PushNotificationRegistrationWrapperSWIGJNI.PushNotificationRegistrationWrapper_DestroyPushNotificationRegistration(this.swigCPtr, this);
  }
  
  public boolean RegisterClient(String paramString)
  {
    return PushNotificationRegistrationWrapperSWIGJNI.PushNotificationRegistrationWrapper_RegisterClient(this.swigCPtr, this, paramString);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PushNotificationRegistrationWrapperSWIGJNI.delete_PushNotificationRegistrationWrapper(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/gcm/swig/PushNotificationRegistrationWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */