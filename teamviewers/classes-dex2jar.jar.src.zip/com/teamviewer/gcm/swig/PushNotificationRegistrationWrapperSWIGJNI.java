package com.teamviewer.gcm.swig;

public class PushNotificationRegistrationWrapperSWIGJNI
{
  public static final native boolean PushNotificationRegistrationWrapper_CreatePushNotificationRegistration(long paramLong, PushNotificationRegistrationWrapper paramPushNotificationRegistrationWrapper, String paramString1, String paramString2);
  
  public static final native boolean PushNotificationRegistrationWrapper_DestroyPushNotificationRegistration(long paramLong, PushNotificationRegistrationWrapper paramPushNotificationRegistrationWrapper);
  
  public static final native boolean PushNotificationRegistrationWrapper_RegisterClient(long paramLong, PushNotificationRegistrationWrapper paramPushNotificationRegistrationWrapper, String paramString);
  
  public static final native void delete_PushNotificationRegistrationWrapper(long paramLong);
  
  public static final native long new_PushNotificationRegistrationWrapper();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/gcm/swig/PushNotificationRegistrationWrapperSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */