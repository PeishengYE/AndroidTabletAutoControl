package com.teamviewer.teamviewer.market.mobile.activity;

import com.teamviewer.commonresourcelib.activity.VersionInfoActivity;

public class RCVersionActivity
  extends VersionInfoActivity
{
  protected int g()
  {
    return 2131099648;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewer/market/mobile/activity/RCVersionActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */