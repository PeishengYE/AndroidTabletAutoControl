package com.teamviewer.teamviewer.market.mobile.application;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import com.teamviewer.corelib.logging.Logging;
import java.util.Timer;
import java.util.TimerTask;
import o.ayo;
import o.byc;
import o.byd;
import o.cfx;
import o.ciz;
import o.cli;
import o.clz;
import o.cme;

public final class SessionTimeoutService
  extends Service
{
  private final Timer a = new Timer("Session Timeout");
  private TimerTask b;
  
  private Notification a(String paramString1, String paramString2, String paramString3)
  {
    return cfx.a(paramString1, paramString2, paramString3, 2130837888, false, j(), 5);
  }
  
  private void a()
  {
    Logging.b("SessionTimeoutService", "Schedule disconnection warning");
    this.b = new byc(this);
    this.a.schedule(this.b, 540000L);
  }
  
  private void b()
  {
    Logging.b("SessionTimeoutService", "Schedule disconnection");
    this.b = new byd(this);
    this.a.schedule(this.b, 60000L);
  }
  
  private void c()
  {
    if (this.b != null)
    {
      Logging.b("SessionTimeoutService", "Cancel disconnect timer");
      this.b.cancel();
      this.b = null;
    }
  }
  
  private void d()
  {
    Object localObject = ciz.b();
    if (localObject != null)
    {
      Logging.b("SessionTimeoutService", "End session by user");
      ((cme)localObject).a(cli.c);
      return;
    }
    Logging.b("SessionTimeoutService", "Connection abort");
    localObject = ciz.a();
    ((ciz)localObject).a(((ciz)localObject).g(), clz.d);
  }
  
  private void e()
  {
    Logging.b("SessionTimeoutService", "Session timeout");
    ciz localciz = ciz.a();
    localciz.a(localciz.g(), clz.B);
  }
  
  private void f()
  {
    startForeground(5, h());
  }
  
  private void g()
  {
    startForeground(5, i());
  }
  
  private Notification h()
  {
    return a(getString(2131165671), getString(2131165540), getString(2131165677));
  }
  
  private Notification i()
  {
    return a(getString(2131165671), getString(2131165539), getString(2131165676));
  }
  
  private Intent j()
  {
    Object localObject = ayo.a().g();
    localObject = new Intent(getApplicationContext(), (Class)localObject);
    ((Intent)localObject).addFlags(805306368);
    return (Intent)localObject;
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    Logging.a("SessionTimeoutService", "Stopping");
    c();
    stopForeground(true);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    a();
    f();
    return 2;
  }
  
  public void onTaskRemoved(Intent paramIntent)
  {
    super.onTaskRemoved(paramIntent);
    Logging.a("SessionTimeoutService", "Task removed");
    stopSelf();
    d();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewer/market/mobile/application/SessionTimeoutService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */