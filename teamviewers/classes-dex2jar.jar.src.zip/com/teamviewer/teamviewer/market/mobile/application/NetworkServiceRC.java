package com.teamviewer.teamviewer.market.mobile.application;

import o.ays;
import o.bbw;

public class NetworkServiceRC
  extends ays
{
  protected boolean a()
  {
    return !bbw.a();
  }
  
  protected int b()
  {
    return 55000;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewer/market/mobile/application/NetworkServiceRC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */