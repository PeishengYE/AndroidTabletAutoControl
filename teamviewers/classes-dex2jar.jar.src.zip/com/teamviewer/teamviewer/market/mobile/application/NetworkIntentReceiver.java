package com.teamviewer.teamviewer.market.mobile.application;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import o.bxx;

public class NetworkIntentReceiver
  extends BroadcastReceiver
{
  public static Intent a(Context paramContext)
  {
    paramContext = new Intent(paramContext, NetworkIntentReceiver.class);
    paramContext.putExtra("TYPE", 1);
    return paramContext;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ((paramIntent != null) && (paramIntent.getIntExtra("TYPE", 0) == 1)) {
      bxx.f().g();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewer/market/mobile/application/NetworkIntentReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */