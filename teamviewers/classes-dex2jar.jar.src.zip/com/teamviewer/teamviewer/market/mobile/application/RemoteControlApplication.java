package com.teamviewer.teamviewer.market.mobile.application;

import com.teamviewer.teamviewerlib.swig.tvviewmodel.IIPCMessagesViewModel;
import com.teamviewer.teamviewerlib.swig.tvviewmodel.IPCMessagesSignalsHelper;
import com.teamviewer.teamviewerlib.swig.tvviewmodel.IPCMessagesViewModelLocator;
import o.ave;
import o.ayo;
import o.ayv;
import o.ayz;
import o.azb;
import o.aze;
import o.azh;
import o.bxi;
import o.bxx;
import o.bxz;
import o.bya;
import o.byb;
import o.byg;
import o.bzg;
import o.cjc;

public class RemoteControlApplication
  extends ave
{
  private byb c;
  
  protected IIPCMessagesViewModel a(ayz paramayz)
  {
    this.a = new bxz(this);
    this.b = new bya(this);
    paramayz = IPCMessagesViewModelLocator.GetIIPCMessagesViewModel();
    IPCMessagesSignalsHelper.RegisterForPopUpMessageChangedSlot(paramayz, this.a);
    IPCMessagesSignalsHelper.RegisterForTrayMessageChangedSlot(paramayz, this.b);
    return paramayz;
  }
  
  protected void b()
  {
    ayo localayo = ayo.a();
    this.c = new byb(this, new azh(), new azb(), new aze());
    bxx.a(this, localayo, new azh(), new azb(), new ayv(), new aze());
    localayo.f();
    cjc.a(byg.a());
    cjc.a();
    bzg.a(new bxi());
  }
  
  protected void c() {}
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewer/market/mobile/application/RemoteControlApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */