package com.teamviewer.chatviewlib.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import o.asm;
import o.atc;
import o.ate;
import o.cho;

public class AccountPictureView
  extends FrameLayout
{
  private ate a = ate.a;
  private atc b;
  private ImageView c;
  private int d;
  private int e;
  
  public AccountPictureView(Context paramContext)
  {
    super(paramContext);
    a(paramContext);
  }
  
  public AccountPictureView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramContext);
    setPlaceholder(paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "src", 0));
  }
  
  public AccountPictureView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramContext);
    setPlaceholder(paramAttributeSet.getAttributeResourceValue("http://schemas.android.com/apk/res/android", "src", 0));
  }
  
  private int a(ate paramate)
  {
    switch (o.atd.a[paramate.ordinal()])
    {
    default: 
      return 0;
    case 1: 
      return asm.status_online;
    case 2: 
      return asm.status_online_away;
    case 3: 
      return asm.status_online_busy;
    }
    return asm.status_offline;
  }
  
  private void a(Context paramContext)
  {
    this.c = new ImageView(paramContext);
    this.b = new atc(paramContext, this.c);
    paramContext = new FrameLayout.LayoutParams(-2, -2);
    paramContext.gravity = 51;
    this.b.setLayoutParams(paramContext);
    paramContext = new FrameLayout.LayoutParams(-2, -2);
    paramContext.gravity = 85;
    this.c.setLayoutParams(paramContext);
    this.b.setVisibility(8);
    this.c.setVisibility(8);
    addView(this.b);
    addView(this.c);
  }
  
  private int getImageSizeOfAccountPicture()
  {
    int i = 16;
    while ((i < this.e) && (i < 256)) {
      i *= 2;
    }
    return i;
  }
  
  private void setPlaceholder(int paramInt)
  {
    if ((this.d == paramInt) || (paramInt == 0)) {}
    Drawable localDrawable;
    do
    {
      return;
      this.d = paramInt;
      localDrawable = getResources().getDrawable(this.d);
    } while (localDrawable == null);
    this.e = localDrawable.getIntrinsicHeight();
    this.b.a(localDrawable, this.e);
  }
  
  public void a(String paramString, ate paramate, boolean paramBoolean)
  {
    this.b.setVisibility(0);
    if (cho.h(paramString)) {
      this.b.setImageDrawable(null);
    }
    for (;;)
    {
      setOnlineState(paramate);
      return;
      paramString = paramString.replace("[size]", String.valueOf(getImageSizeOfAccountPicture()));
      this.b.a(paramString, this.e, paramBoolean);
    }
  }
  
  public void setOnlineState(ate paramate)
  {
    if (this.a == paramate) {
      return;
    }
    if (paramate != ate.a) {
      this.c.setImageResource(a(paramate));
    }
    Object localObject;
    if (this.a == ate.a)
    {
      this.c.setVisibility(0);
      localObject = this.c.getDrawable();
      FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)this.b.getLayoutParams();
      localLayoutParams.setMargins(0, 0, ((Drawable)localObject).getIntrinsicWidth() / 2 - 1, ((Drawable)localObject).getIntrinsicHeight() / 2 - 1);
      this.b.setLayoutParams(localLayoutParams);
    }
    for (;;)
    {
      this.a = paramate;
      return;
      if (paramate == ate.a)
      {
        this.c.setVisibility(8);
        localObject = (FrameLayout.LayoutParams)this.b.getLayoutParams();
        ((FrameLayout.LayoutParams)localObject).setMargins(0, 0, 0, 0);
        this.b.setLayoutParams((ViewGroup.LayoutParams)localObject);
      }
    }
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewlib/view/AccountPictureView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */