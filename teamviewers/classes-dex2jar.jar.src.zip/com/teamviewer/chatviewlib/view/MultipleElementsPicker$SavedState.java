package com.teamviewer.chatviewlib.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.view.View.BaseSavedState;
import java.util.LinkedList;
import o.ath;

public class MultipleElementsPicker$SavedState
  extends View.BaseSavedState
{
  public static final Parcelable.Creator<SavedState> CREATOR = new ath();
  private final int a;
  private final LinkedList<CharSequence> b;
  
  private MultipleElementsPicker$SavedState(Parcel paramParcel)
  {
    super(paramParcel);
    this.a = paramParcel.readInt();
    this.b = ((LinkedList)paramParcel.readSerializable());
  }
  
  public MultipleElementsPicker$SavedState(Parcelable paramParcelable, int paramInt, LinkedList<CharSequence> paramLinkedList)
  {
    super(paramParcelable);
    this.a = paramInt;
    this.b = paramLinkedList;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.a);
    paramParcel.writeSerializable(this.b);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewlib/view/MultipleElementsPicker$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */