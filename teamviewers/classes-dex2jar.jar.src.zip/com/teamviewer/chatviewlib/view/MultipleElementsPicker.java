package com.teamviewer.chatviewlib.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.widget.EditText;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import java.util.Iterator;
import java.util.LinkedList;
import o.atg;

@OptionsActivity
public class MultipleElementsPicker
  extends EditText
{
  private static final int a = ", ".length();
  private final LinkedList<CharSequence> b = new LinkedList();
  private atg c = null;
  private boolean d = false;
  private boolean e = false;
  private int f = 0;
  
  public MultipleElementsPicker(Context paramContext)
  {
    super(paramContext);
  }
  
  public MultipleElementsPicker(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public MultipleElementsPicker(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  @TargetApi(21)
  public MultipleElementsPicker(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int a(int paramInt)
  {
    int i = 0;
    if ((this.b.isEmpty()) || (paramInt > this.f)) {
      i = -1;
    }
    while (paramInt == 0) {
      return i;
    }
    Iterator localIterator = this.b.iterator();
    i = 0;
    int j = 0;
    while (localIterator.hasNext())
    {
      j += ((CharSequence)localIterator.next()).length() + a;
      if (paramInt < j) {
        return i;
      }
      i += 1;
    }
    return -1;
  }
  
  private void a()
  {
    b("");
    Object localObject = new StringBuilder();
    Iterator localIterator = this.b.iterator();
    while (localIterator.hasNext())
    {
      ((StringBuilder)localObject).append((CharSequence)localIterator.next());
      ((StringBuilder)localObject).append(", ");
    }
    localObject = ((StringBuilder)localObject).toString();
    this.f = ((String)localObject).length();
    this.d = true;
    setText((CharSequence)localObject);
    this.d = false;
    this.e = true;
    setSelection(this.f);
    this.e = false;
  }
  
  private void b(int paramInt)
  {
    if ((paramInt > this.f) || (this.b == null) || (this.b.isEmpty())) {}
    for (;;)
    {
      return;
      Iterator localIterator = this.b.iterator();
      int j = 0;
      int k;
      for (int i = 0; localIterator.hasNext(); i = k)
      {
        j = ((CharSequence)localIterator.next()).length() + a + j;
        if (paramInt < j)
        {
          this.e = true;
          setSelection(i, j);
          this.e = false;
          return;
        }
        i = j;
        k = j;
        j = i;
      }
    }
  }
  
  private void b(CharSequence paramCharSequence)
  {
    atg localatg = this.c;
    if (localatg != null) {
      localatg.a(paramCharSequence);
    }
  }
  
  private void c(int paramInt)
  {
    this.b.remove(paramInt);
    d(paramInt);
    a();
  }
  
  private void d(int paramInt)
  {
    atg localatg = this.c;
    if (localatg != null) {
      localatg.a(paramInt);
    }
  }
  
  public void a(CharSequence paramCharSequence)
  {
    this.b.add(paramCharSequence);
    a();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof MultipleElementsPicker.SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (MultipleElementsPicker.SavedState)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    this.f = MultipleElementsPicker.SavedState.a(paramParcelable);
    if (MultipleElementsPicker.SavedState.b(paramParcelable) != null)
    {
      this.b.clear();
      this.b.addAll(MultipleElementsPicker.SavedState.b(paramParcelable));
    }
    paramParcelable = getText();
    if (paramParcelable.length() > this.f)
    {
      b(paramParcelable.subSequence(this.f, paramParcelable.length()));
      return;
    }
    b("");
  }
  
  public Parcelable onSaveInstanceState()
  {
    return new MultipleElementsPicker.SavedState(super.onSaveInstanceState(), this.f, this.b);
  }
  
  protected void onSelectionChanged(int paramInt1, int paramInt2)
  {
    super.onSelectionChanged(paramInt1, paramInt2);
    if (!this.e) {
      b(paramInt1);
    }
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.d) {}
    do
    {
      do
      {
        return;
        if (paramInt1 >= this.f)
        {
          b(paramCharSequence.subSequence(this.f, paramCharSequence.length()));
          return;
        }
        if (paramInt2 <= paramInt3) {
          break;
        }
        paramInt1 = a(paramInt1);
      } while (paramInt1 < 0);
      c(paramInt1);
      return;
    } while (paramInt2 >= paramInt3);
  }
  
  public void setListener(atg paramatg)
  {
    this.c = paramatg;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewlib/view/MultipleElementsPicker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */