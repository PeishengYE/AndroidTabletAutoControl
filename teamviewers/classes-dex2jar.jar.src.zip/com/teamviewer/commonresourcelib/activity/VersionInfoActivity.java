package com.teamviewer.commonresourcelib.activity;

import android.os.Bundle;
import android.view.MenuItem;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import o.auv;
import o.auw;
import o.avd;
import o.awd;
import o.ayk;
import o.ayo;
import o.ff;
import o.fp;

@OptionsActivity
public abstract class VersionInfoActivity
  extends awd
{
  public VersionInfoActivity()
  {
    super(new avd());
  }
  
  public abstract int g();
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(auw.activity_options);
    int i = g();
    if (f().a(auv.main) == null) {
      b(ayk.b(i));
    }
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem == null) {
      Logging.b("VersionInfoActivity", "onOptionsItemSelected(): item is null!");
    }
    do
    {
      return false;
      localObject = f();
      if (localObject == null)
      {
        Logging.b("VersionInfoActivity", "onOptionsItemSelected(): FragmentManager is null!");
        return false;
      }
    } while (paramMenuItem.getItemId() != 16908332);
    Object localObject = ((fp)localObject).a(auv.main);
    if (localObject == null)
    {
      Logging.b("VersionInfoActivity", "onOptionsItemSelected(): cannot find fragment");
      return false;
    }
    return ((ff)localObject).a(paramMenuItem);
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/activity/VersionInfoActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */