package com.teamviewer.commonresourcelib.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import o.auv;
import o.auw;
import o.avc;
import o.awd;
import o.ayd;
import o.ayo;

@OptionsActivity
public class ShowEventLogActivity
  extends awd
{
  public ShowEventLogActivity()
  {
    super(new avc());
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(auw.activity_options);
    if (paramBundle == null) {
      b(new ayd());
    }
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 16908332) {
      finish();
    }
    return true;
  }
  
  public void onRestart()
  {
    super.onRestart();
    ((WebView)findViewById(auv.logEventWebView)).reload();
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/activity/ShowEventLogActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */