package com.teamviewer.commonresourcelib.gui;

import android.content.Context;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.util.AttributeSet;
import o.avb;
import o.axx;
import o.cek;

public class TVSpecialKeyboard
  extends KeyboardView
{
  final axx a;
  
  public TVSpecialKeyboard(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setKeyboard(new Keyboard(paramContext, avb.keyboard));
    this.a = new axx();
    setOnKeyboardActionListener(this.a);
  }
  
  public void setKeyboard(cek paramcek)
  {
    this.a.a(paramcek);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/gui/TVSpecialKeyboard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */