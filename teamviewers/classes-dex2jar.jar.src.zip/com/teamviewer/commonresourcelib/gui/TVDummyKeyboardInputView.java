package com.teamviewer.commonresourcelib.gui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.corelib.shared.VirtualKeyCode;
import o.avh;
import o.avt;
import o.axw;
import o.cek;

public class TVDummyKeyboardInputView
  extends AutoCompleteTextView
{
  private axw a;
  private avt b;
  private avh c;
  
  public TVDummyKeyboardInputView(Context paramContext)
  {
    super(paramContext);
    a();
  }
  
  public TVDummyKeyboardInputView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a();
  }
  
  public TVDummyKeyboardInputView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a();
  }
  
  public static int a(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    int j = Math.min(paramCharSequence1.length(), paramCharSequence2.length());
    int i = 0;
    while (i < j)
    {
      if (paramCharSequence1.charAt(i) != paramCharSequence2.charAt(i)) {
        return i;
      }
      i += 1;
    }
    return j;
  }
  
  private void a()
  {
    b();
  }
  
  private void a(cek paramcek, int paramInt)
  {
    int i = 0;
    while (i < paramInt)
    {
      paramcek.a(VirtualKeyCode.b, false);
      paramcek.a(VirtualKeyCode.b, true);
      i += 1;
    }
  }
  
  private void b()
  {
    setText("  ");
    setSelection("  ".length() - 1);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo)
  {
    this.b = new avt(this, this, true);
    paramEditorInfo.inputType = 524289;
    paramEditorInfo.imeOptions = 268435457;
    return this.b;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if (this.a == null)
    {
      Logging.d("TVDummyKeybrdInputView", "client or keylistener is null");
      return false;
    }
    if ((paramInt == 4) || (paramInt == 82)) {
      return super.onKeyDown(paramInt, paramKeyEvent);
    }
    if ((paramInt == 66) && (this.b != null)) {
      this.b.a();
    }
    if (this.a.onKeyDown(paramInt, paramKeyEvent)) {
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyPreIme(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getAction() == 0) && (this.c != null) && (this.c.a_())) {
      return true;
    }
    if ((paramKeyEvent.isAltPressed()) || (paramKeyEvent.isCtrlPressed()) || (paramKeyEvent.isMetaPressed()))
    {
      if (paramKeyEvent.getAction() == 0) {
        return this.a.onKeyDown(paramInt, paramKeyEvent);
      }
      if (paramKeyEvent.getAction() == 1) {
        return this.a.onKeyUp(paramInt, paramKeyEvent);
      }
    }
    return super.onKeyPreIme(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (this.a == null)
    {
      Logging.d("TVDummyKeybrdInputView", "client or keylistener is null");
      return false;
    }
    if ((paramInt == 4) || (paramInt == 82)) {
      return super.onKeyUp(paramInt, paramKeyEvent);
    }
    if (this.a.onKeyUp(paramInt, paramKeyEvent)) {
      return true;
    }
    return super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setKeyboardStateChangeListener(avh paramavh)
  {
    this.c = paramavh;
  }
  
  public void setTVKeyListener(axw paramaxw)
  {
    this.a = paramaxw;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/gui/TVDummyKeyboardInputView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */