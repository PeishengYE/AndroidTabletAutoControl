package com.teamviewer.commonresourcelib.gui.elements;

import android.content.Context;
import android.graphics.Rect;
import android.text.Editable;
import android.util.AttributeSet;
import android.widget.AutoCompleteTextView;

public class InstantAutoComplete
  extends AutoCompleteTextView
{
  private boolean a = false;
  
  public InstantAutoComplete(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public void a()
  {
    if (!this.a)
    {
      showDropDown();
      return;
    }
    dismissDropDown();
  }
  
  public void dismissDropDown()
  {
    super.dismissDropDown();
    this.a = false;
  }
  
  public boolean enoughToFilter()
  {
    return (getText() != null) && (getText().length() > 0);
  }
  
  protected void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect)
  {
    super.onFocusChanged(paramBoolean, paramInt, paramRect);
    if (paramBoolean) {
      performFiltering(getText(), 0);
    }
  }
  
  public void showDropDown()
  {
    super.showDropDown();
    this.a = true;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/gui/elements/InstantAutoComplete.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */