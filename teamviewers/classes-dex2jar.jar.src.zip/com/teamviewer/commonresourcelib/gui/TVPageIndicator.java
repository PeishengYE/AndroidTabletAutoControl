package com.teamviewer.commonresourcelib.gui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import o.auu;
import o.ava;

public class TVPageIndicator
  extends LinearLayout
{
  private int a;
  private int b;
  private ImageView[] c;
  
  public TVPageIndicator(Context paramContext)
  {
    super(paramContext);
    a(paramContext, null);
  }
  
  public TVPageIndicator(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramContext, paramAttributeSet);
  }
  
  public TVPageIndicator(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramContext, paramAttributeSet);
  }
  
  private void a(Context paramContext)
  {
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
    localLayoutParams.setMargins(this.b, this.b, this.b, this.b);
    this.c = new ImageView[this.a];
    int i = 0;
    while (i < this.a)
    {
      ImageView localImageView = new ImageView(paramContext);
      localImageView.setImageResource(auu.page_indicator_inactive);
      addView(localImageView, localLayoutParams);
      this.c[i] = localImageView;
      i += 1;
    }
  }
  
  private void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    if (paramAttributeSet != null)
    {
      paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, ava.PageIndicator);
      this.b = paramAttributeSet.getDimensionPixelSize(ava.PageIndicator_pageIndicatorMargin, 0);
      this.a = paramAttributeSet.getInteger(ava.PageIndicator_pageIndicatorPagesCount, 0);
      paramAttributeSet.recycle();
    }
    for (;;)
    {
      a(paramContext);
      setPageIndex(0);
      return;
      this.b = 0;
      this.a = 0;
    }
  }
  
  public void setPageIndex(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < this.a))
    {
      int i = 0;
      if (i < this.c.length)
      {
        ImageView localImageView = this.c[i];
        if (paramInt == i) {
          localImageView.setImageResource(auu.page_indicator_active);
        }
        for (;;)
        {
          i += 1;
          break;
          localImageView.setImageResource(auu.page_indicator_inactive);
        }
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonresourcelib/gui/TVPageIndicator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */