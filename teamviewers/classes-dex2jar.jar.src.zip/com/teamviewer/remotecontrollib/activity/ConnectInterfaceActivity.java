package com.teamviewer.remotecontrollib.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.teamviewer.corelib.logging.Logging;
import o.ayo;
import o.bvy;
import o.bvz;
import o.bwa;
import o.bwd;
import o.bwf;
import o.bwm;
import o.cho;
import o.ciz;
import o.ckc;

public class ConnectInterfaceActivity
  extends Activity
{
  private Class<? extends Activity> a()
  {
    Object localObject = ayo.a().e();
    if (localObject != null)
    {
      Logging.c("ConnectInterfaceActivity", "A session is already running!");
      return localObject.getClass();
    }
    localObject = ciz.a();
    if (((ciz)localObject).k())
    {
      Logging.c("ConnectInterfaceActivity", "A session is already running!");
      if (((ciz)localObject).e() == ckc.b) {
        return RCClientActivity.class;
      }
      if (((ciz)localObject).e() == ckc.k) {
        return M2MClientActivity.class;
      }
    }
    return MainActivity.class;
  }
  
  private boolean a(Intent paramIntent)
  {
    if (paramIntent == null)
    {
      Logging.d("ConnectInterfaceActivity", "intent is null");
      return false;
    }
    paramIntent = paramIntent.getData();
    if ((paramIntent.getScheme().equals("teamviewer8")) && (paramIntent.getHost().equals("remotecontrol")))
    {
      Logging.b("ConnectInterfaceActivity", "received teamviewer8");
      return a(paramIntent);
    }
    if ((paramIntent.getScheme().equals("tvcontrol1")) && (paramIntent.getHost().equals("control")))
    {
      Logging.b("ConnectInterfaceActivity", "received controlpage");
      return b(paramIntent);
    }
    if (paramIntent.getScheme().equals("file"))
    {
      Logging.b("ConnectInterfaceActivity", "received file");
      return c(paramIntent);
    }
    Logging.b("ConnectInterfaceActivity", "received unknown intent");
    return false;
  }
  
  private boolean a(Uri paramUri)
  {
    if (paramUri == null)
    {
      Logging.d("ConnectInterfaceActivity", "data is null");
      return false;
    }
    String str1 = paramUri.getQueryParameter("connectcc");
    String str2 = paramUri.getQueryParameter("connectsid");
    String str3 = paramUri.getQueryParameter("username");
    String str4 = paramUri.getQueryParameter("logintoken");
    paramUri = paramUri.getQueryParameter("tokenid");
    if (!cho.h(str1))
    {
      bvz.a.a(new bwf(bwm.b, str1, str3, str4, paramUri));
      return true;
    }
    if (!cho.h(str2))
    {
      bvz.a.a(new bwf(bwm.c, str2, str3, str4, paramUri));
      return true;
    }
    Logging.d("ConnectInterfaceActivity", "no id found");
    return false;
  }
  
  private boolean b(Uri paramUri)
  {
    paramUri = bwa.a(paramUri);
    if (paramUri == null) {
      return false;
    }
    bvz.a.a(new bwd(paramUri));
    return true;
  }
  
  private boolean c(Uri paramUri)
  {
    return bvy.a(paramUri.getPath());
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    Logging.b("ConnectInterfaceActivity", "onCreate");
    if (a(getIntent()))
    {
      paramBundle = a();
      Logging.a("ConnectInterfaceActivity", "Starting activity " + paramBundle.getSimpleName());
      paramBundle = new Intent(this, paramBundle);
      paramBundle.setAction("android.intent.action.MAIN");
      paramBundle.addCategory("android.intent.category.LAUNCHER");
      paramBundle.addFlags(268435456);
      paramBundle.addFlags(67108864);
      paramBundle.putExtra("CLOSE_CURRENT_SESSION", true);
      startActivity(paramBundle);
    }
    Logging.b("ConnectInterfaceActivity", "ending connect interface activity");
    finish();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/ConnectInterfaceActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */