package com.teamviewer.remotecontrollib.activity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import com.teamviewer.remotecontrollib.gui.tutorial.TutorialViewPagerTop;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import o.ayo;
import o.bdl;
import o.bdm;
import o.buk;
import o.cjk;

@OptionsActivity
public class TutorialActivity
  extends Activity
{
  private TutorialViewPagerTop a;
  private buk b;
  private final String c = "CurrentPage";
  private int d = 0;
  
  public void a(int paramInt)
  {
    this.d = paramInt;
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    SharedPreferences.Editor localEditor = cjk.a().edit();
    localEditor.putBoolean("TUTORIAL_ON_STARTUP", false);
    localEditor.commit();
    setContentView(bdm.activity_tutorial_main);
    if (paramBundle != null) {
      this.d = paramBundle.getInt("CurrentPage", 0);
    }
    this.b = new buk(this, this.d);
    this.a = ((TutorialViewPagerTop)findViewById(bdl.tutorialpager_top));
    this.a.setAdapter(this.b);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle)
  {
    paramBundle.putInt("CurrentPage", this.d);
    super.onSaveInstanceState(paramBundle);
  }
  
  protected void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  protected void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/TutorialActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */