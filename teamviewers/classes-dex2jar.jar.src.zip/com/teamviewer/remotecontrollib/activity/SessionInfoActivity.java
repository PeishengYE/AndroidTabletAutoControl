package com.teamviewer.remotecontrollib.activity;

import android.os.Bundle;
import android.view.MenuItem;
import o.awd;
import o.ayo;
import o.bdm;
import o.bha;
import o.bom;

public class SessionInfoActivity
  extends awd
{
  public SessionInfoActivity()
  {
    super(new bha());
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(bdm.activity_main);
    if ((paramBundle == null) || (!paramBundle.getBoolean("change"))) {
      b(new bom());
    }
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      return true;
    }
    return false;
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/SessionInfoActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */