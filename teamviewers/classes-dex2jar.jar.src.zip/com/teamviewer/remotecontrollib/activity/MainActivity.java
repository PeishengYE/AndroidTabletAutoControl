package com.teamviewer.remotecontrollib.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel.ChatSignalsHelper;
import com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel.ChatViewModelLocatorAndroid;
import com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel.ErrorMessageSignalCallback;
import com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel.IChatViewModelLocator;
import com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel.IErrorMessageHandler;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.NativeLibTvExt;
import com.teamviewer.teamviewerlib.event.EventHub;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData.Button;
import com.teamviewer.teamviewerlib.settings.Settings;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;
import java.util.Locale;
import o.awd;
import o.awu;
import o.axt;
import o.axv;
import o.ayo;
import o.bbw;
import o.bdg;
import o.bdj;
import o.bdk;
import o.bdl;
import o.bdm;
import o.bdo;
import o.bdp;
import o.bec;
import o.bel;
import o.bem;
import o.ben;
import o.beo;
import o.bep;
import o.ber;
import o.bes;
import o.bet;
import o.beu;
import o.bev;
import o.bew;
import o.bex;
import o.bey;
import o.bih;
import o.blk;
import o.bnw;
import o.bnz;
import o.bsx;
import o.bvz;
import o.bwc;
import o.byt;
import o.cfk;
import o.cfl;
import o.cfu;
import o.cgt;
import o.cgu;
import o.cgv;
import o.chb;
import o.cho;
import o.chr;
import o.chs;
import o.ciz;
import o.cjk;
import o.ckh;
import o.ff;
import o.fp;
import o.gc;

public class MainActivity
  extends awd
  implements bec
{
  private bey m = bey.a;
  private bnw n = null;
  private IErrorMessageHandler o;
  public final cgv onCloseApp = new beo(this);
  public final cgv onContactUs = new bem(this);
  public final cgv onOpenBlackberryMarket = new ben(this);
  private final cfk p = new bet(this);
  private cfk q = new beu(this);
  private cfk r = new bev(this);
  private cfk s = new bew(this);
  private final cfk t = new bex(this);
  private final ErrorMessageSignalCallback u = new bep(this);
  
  public MainActivity()
  {
    super(new bih());
  }
  
  private void a(int paramInt1, int paramInt2)
  {
    chb localchb = cgt.a();
    cgu localcgu = localchb.a();
    localcgu.b(false);
    localcgu.b(paramInt1);
    localcgu.c(paramInt2);
    localcgu.d(bdo.tv_error_startup_button_contact);
    localcgu.e(bdo.tv_error_startup_button_close);
    localchb.a(this, new TVDialogListenerMetaData("onContactUs", localcgu.W(), TVDialogListenerMetaData.Button.b));
    localchb.a(this, new TVDialogListenerMetaData("onCloseApp", localcgu.W(), TVDialogListenerMetaData.Button.c));
    localcgu.a(this);
  }
  
  private void a(Intent paramIntent)
  {
    if ((paramIntent != null) && (paramIntent.getBooleanExtra("SHOW_CHAT", false)) && (!ciz.a().i()) && (!ciz.a().k()))
    {
      cjk.a().edit().putInt("CURRENT_TAB", bnz.c.a()).apply();
      s();
      paramIntent = paramIntent.getStringExtra("CHATROOMID");
      if (paramIntent != null) {
        new Handler(getMainLooper()).post(new ber(this, paramIntent));
      }
    }
  }
  
  private void a(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(12);
    localStringBuilder.append('.');
    localStringBuilder.append(0);
    localStringBuilder.append('.');
    localStringBuilder.append(6394);
    localStringBuilder.append(byt.a());
    String str = "en";
    Locale localLocale = Locale.getDefault();
    if (localLocale != null) {
      str = localLocale.getLanguage();
    }
    for (;;)
    {
      paramString = cho.a(bdo.tv_url_tvconsoleCommentSession, new Object[] { paramString, str, localStringBuilder.toString(), Settings.g() });
      paramString = cgt.a().a(paramString, bdj.tvdialog_comment_session_height);
      paramString.b(true);
      paramString.U();
      return;
      Logging.d("MainActivity", "locale not found");
    }
  }
  
  private boolean t()
  {
    try
    {
      chs.b();
      return true;
    }
    catch (cfu localcfu)
    {
      Logging.d("MainActivity", "IMEI is broken");
    }
    return false;
  }
  
  private void u()
  {
    chb localchb = cgt.a();
    cgu localcgu = localchb.a();
    localcgu.b(false);
    localcgu.b(bdo.tv_error_startup_title_blackberry_apk);
    localcgu.c(bdo.tv_error_startup_message_blackberry_apk);
    localcgu.d(bdo.tv_error_startup_button_blackberry_market);
    localchb.a(this, new TVDialogListenerMetaData("onOpenBlackberryMarket", localcgu.W(), TVDialogListenerMetaData.Button.b));
    localcgu.a(this);
  }
  
  private void v()
  {
    if (!bvz.a.a()) {
      return;
    }
    Logging.a("MainActivity", "checkForScheduledConnect(): there are pending connections!");
    if (!ckh.e())
    {
      Logging.d("MainActivity", "checkForScheduledConnect(): keep alive is in wrong state!");
      return;
    }
    if ((ciz.a().i()) || (ciz.a().k()))
    {
      Logging.d("MainActivity", "checkForScheduledConnect(): a session is already connecting or running");
      return;
    }
    bvz.a.b().a();
  }
  
  public View a()
  {
    return findViewById(bdl.activity_main);
  }
  
  public void a(bey parambey)
  {
    this.m = parambey;
  }
  
  public void a(ff paramff1, ff paramff2, bey parambey)
  {
    if (parambey != null) {
      a(parambey);
    }
    if (findViewById(bdl.filetransfer_main) != null)
    {
      paramff1.o().a().b(bdl.filetransfer_main, paramff2).a();
      return;
    }
    Logging.d("MainActivity", "replaceFTMainFragment: View not found!");
  }
  
  public void a(ff paramff1, ff paramff2, bey parambey, PListGroupID paramPListGroupID)
  {
    Bundle localBundle = new Bundle();
    localBundle.putLong("FTGroupId", paramPListGroupID.GetInternalID());
    paramff2.g(localBundle);
    a(paramff1, paramff2, parambey);
  }
  
  public void b_()
  {
    a().setBackgroundResource(bdk.background);
  }
  
  public void c(ff paramff)
  {
    a(paramff, new bsx(), bey.b);
  }
  
  public bey g()
  {
    return this.m;
  }
  
  public void onBackPressed()
  {
    ff localff = f().a(bdl.main);
    if (((localff instanceof axv)) && (((axv)localff).a())) {
      return;
    }
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle)
  {
    setTheme(bdp.AppTheme);
    super.onCreate(paramBundle);
    Object localObject = getIntent();
    if (localObject != null) {
      if ((((Intent)localObject).getFlags() & 0x400000) != 0) {
        finish();
      }
    }
    label231:
    label378:
    for (;;)
    {
      return;
      new Handler(getMainLooper()).post(new bel(this));
      a((Intent)localObject);
      setContentView(bdm.activity_main);
      Logging.b("MainActivity", "update main activity");
      ayo.a().a(this);
      cgt.a(new blk());
      if ((paramBundle == null) || (!paramBundle.getBoolean("change")))
      {
        localObject = f().a();
        this.n = new bnw();
        ((gc)localObject).b(bdl.navigation, this.n);
        ((gc)localObject).a();
        if ((byt.f) || (!cho.b())) {
          break label231;
        }
        Logging.c("MainActivity", "show dialog: apk cannot be run on blackberry.");
        u();
      }
      for (;;)
      {
        if (paramBundle == null) {
          break label378;
        }
        this.m = ((bey)paramBundle.getSerializable("FTOpenTab"));
        return;
        this.n = ((bnw)f().a(bdl.navigation));
        int i = paramBundle.getInt("visibility");
        findViewById(bdl.navigation).setVisibility(i);
        break;
        if (!chr.a().h())
        {
          Logging.c("MainActivity", "show dialog: no open gl 2.0");
          a(bdo.tv_error_startup_title_no_opengl, bdo.tv_error_startup_message_no_opengl);
        }
        else if (!t())
        {
          Logging.c("MainActivity", "show dialog: no valid imei");
          a(bdo.tv_error_startup_title_invalid_imei, bdo.tv_error_startup_message_invalid_imei);
        }
        else if (!NativeLibTvExt.a())
        {
          Logging.c("MainActivity", "show dialog: no native library");
          a(bdo.tv_error_startup_title_missing_libs, bdo.tv_error_startup_message_missing_libs);
        }
        else
        {
          if ((!bbw.a()) && (bbw.a(this) > 0))
          {
            Logging.c("MainActivity", "gcm error detected");
            if (bbw.b()) {}
          }
          if (cjk.a().getBoolean("TUTORIAL_ON_STARTUP", true)) {
            startActivity(new Intent(this, TutorialActivity.class));
          }
        }
      }
    }
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    ayo.a().a(null);
    this.n = null;
    axt.b((ViewGroup)a());
    Object localObject = findViewById(16908290);
    if (localObject != null)
    {
      ((View)localObject).destroyDrawingCache();
      localObject = ((View)localObject).getBackground();
      if (localObject != null) {
        ((Drawable)localObject).setCallback(null);
      }
      return;
    }
    Logging.d("MainActivity", "onDestroy: content not found");
  }
  
  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    v();
    a(paramIntent);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    ff localff = f().a(bdl.main);
    boolean bool1;
    boolean bool2;
    if (localff != null)
    {
      bool1 = localff.a(paramMenuItem);
      bool2 = bool1;
      if (!bool1)
      {
        bool2 = bool1;
        if (paramMenuItem.getItemId() == 16908332)
        {
          paramMenuItem = h();
          if (paramMenuItem == null) {
            break label94;
          }
          if (l())
          {
            getWindow().setSoftInputMode(3);
            paramMenuItem.c(this);
          }
        }
      }
    }
    for (;;)
    {
      bool2 = true;
      return bool2;
      bool1 = false;
      Logging.d("MainActivity", "onOptionsItemSelected(): fragment is NULL");
      break;
      label94:
      Logging.d("MainActivity", "onOptionsItemSelected: helper or backstack is null");
    }
  }
  
  public void onPause()
  {
    super.onPause();
    EventHub.a().a(this.p);
    EventHub.a().a(this.q);
    EventHub.a().a(this.r);
    EventHub.a().a(this.s);
    EventHub.a().a(this.t);
  }
  
  public void onResume()
  {
    super.onResume();
    ayo.a().b(this);
    ayo.a().a(this);
    EventHub.a().a(this.p, cfl.aQ);
    EventHub.a().a(this.q, cfl.am);
    EventHub.a().a(this.r, cfl.at);
    EventHub.a().a(this.s, cfl.al);
    EventHub.a().a(this.t, cfl.aR);
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    try
    {
      super.onSaveInstanceState(paramBundle);
      paramBundle.putBoolean("change", true);
      paramBundle.putInt("visibility", findViewById(bdl.navigation).getVisibility());
      paramBundle.putSerializable("FTOpenTab", this.m);
      return;
    }
    catch (IllegalStateException localIllegalStateException)
    {
      for (;;)
      {
        Logging.d("MainActivity", "onSaveInstanceState: " + localIllegalStateException.getMessage());
      }
    }
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
    this.o = ChatViewModelLocatorAndroid.GetChatViewModelLocator().GetErrorMessageHandler();
    ChatSignalsHelper.RegisterErrorMessagesChangedSlot(this.o, this.u);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
    this.u.disconnect();
    this.o = null;
  }
  
  public void q()
  {
    findViewById(bdl.navigation).setVisibility(8);
  }
  
  public void r()
  {
    View localView = findViewById(bdl.navigation);
    if (localView.getVisibility() == 8)
    {
      Animation localAnimation = AnimationUtils.loadAnimation(this, bdg.slide_up_slow);
      localAnimation.setAnimationListener(new bes(this, localView));
      localView.setAnimation(localAnimation);
    }
  }
  
  public void s()
  {
    if (this.n != null) {
      this.n.a(bnz.c);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */