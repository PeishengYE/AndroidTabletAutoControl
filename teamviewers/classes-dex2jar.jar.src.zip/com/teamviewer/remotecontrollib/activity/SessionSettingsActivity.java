package com.teamviewer.remotecontrollib.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.event.EventHub;
import o.awd;
import o.ayo;
import o.bdk;
import o.bdl;
import o.bdm;
import o.bhb;
import o.bhc;
import o.bhe;
import o.bnt;
import o.bod;
import o.cfk;
import o.cfl;
import o.ciz;

public class SessionSettingsActivity
  extends awd
{
  private final cfk m = new bhc(this);
  private final cfk n = new bhe(this);
  
  public SessionSettingsActivity()
  {
    super(new bhb());
  }
  
  public void onCreate(Bundle paramBundle)
  {
    int i = 0;
    super.onCreate(paramBundle);
    setContentView(bdm.activity_main);
    findViewById(bdl.activity_main).setBackgroundResource(bdk.options_background);
    if (paramBundle == null)
    {
      paramBundle = getIntent();
      if (paramBundle != null) {
        i = paramBundle.getIntExtra("extra_settings_type", 0);
      }
    }
    switch (i)
    {
    default: 
      Logging.d("SessionSettingsActivity", "Got invalid settings type: " + i);
      return;
    case 1: 
      b(new bod());
      return;
    }
    b(bnt.a(paramBundle.getBooleanExtra("extra_disable_instructions", true)));
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 16908332)
    {
      finish();
      return true;
    }
    return false;
  }
  
  public void onPause()
  {
    super.onPause();
    if (!EventHub.a().a(this.n)) {
      Logging.d("SessionSettingsActivity", "unregister OnLowMemory event failed");
    }
    if (!EventHub.a().a(this.m)) {
      Logging.d("SessionSettingsActivity", "unregister m_OnSessionEnd event failed");
    }
  }
  
  public void onResume()
  {
    super.onResume();
    if (!ciz.a().k()) {
      this.m.a(null, null);
    }
    if (!EventHub.a().a(this.n, cfl.ag)) {
      Logging.d("SessionSettingsActivity", "register OnLowMemory event failed");
    }
    if (!EventHub.a().a(this.m, cfl.aP)) {
      Logging.d("SessionSettingsActivity", "register OnSessionEnd event failed");
    }
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/SessionSettingsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */