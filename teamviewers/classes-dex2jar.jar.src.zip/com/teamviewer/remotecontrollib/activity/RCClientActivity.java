package com.teamviewer.remotecontrollib.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.GestureDetector;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import com.teamviewer.commonresourcelib.gui.TVDummyKeyboardInputView;
import com.teamviewer.commonresourcelib.gui.TVSpecialKeyboard;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.event.EventHub;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData.Button;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
import o.axt;
import o.axw;
import o.axy;
import o.ayo;
import o.bdg;
import o.bdk;
import o.bdl;
import o.bdm;
import o.bdo;
import o.bds;
import o.bez;
import o.bfa;
import o.bfb;
import o.bfc;
import o.bfd;
import o.bfe;
import o.bff;
import o.bfg;
import o.bfh;
import o.bfi;
import o.bfj;
import o.bfl;
import o.bfm;
import o.bfn;
import o.bfo;
import o.bfp;
import o.bfq;
import o.bfr;
import o.bfy;
import o.bfz;
import o.bgh;
import o.bgi;
import o.bgj;
import o.bgk;
import o.bgl;
import o.bgm;
import o.bgn;
import o.bgo;
import o.bgq;
import o.bgs;
import o.bgt;
import o.bgu;
import o.bgv;
import o.bgw;
import o.bgx;
import o.bgy;
import o.bgz;
import o.biz;
import o.bkb;
import o.bkc;
import o.bkd;
import o.bke;
import o.bkf;
import o.bkg;
import o.bkv;
import o.bkz;
import o.bld;
import o.bot;
import o.cek;
import o.ceu;
import o.cfk;
import o.cfl;
import o.cgt;
import o.cgu;
import o.cgv;
import o.chb;
import o.chc;
import o.chp;
import o.chr;
import o.chu;
import o.ciz;
import o.cjk;
import o.cls;
import o.cme;
import o.cmp;
import o.cmq;
import o.cms;
import o.cmz;
import o.cnb;
import o.cnd;
import o.fp;
import o.gc;

public class RCClientActivity
  extends bds
  implements biz
{
  public boolean B = true;
  private boolean C = false;
  private GestureDetector D = null;
  private Animation.AnimationListener E = new bfl(this);
  private Animation.AnimationListener F = new bgj(this);
  private Animation.AnimationListener G = new bgs(this);
  private Animation.AnimationListener H = new bgt(this);
  private Animation.AnimationListener I = new bgu(this);
  private Animation.AnimationListener J = new bgv(this);
  private Animation.AnimationListener K = new bgw(this);
  private Animation.AnimationListener L = new bgx(this);
  private Animation.AnimationListener M = new bfa(this);
  private View.OnClickListener N = new bfb(this);
  private View.OnClickListener O = new bfc(this);
  private View.OnClickListener P = new bfd(this);
  private View.OnClickListener Q = new bfe(this);
  private View.OnClickListener R = new bff(this);
  private View.OnClickListener S = new bfg(this);
  private View.OnTouchListener T = new bfh(this);
  private View.OnClickListener U = new bfi(this);
  private View.OnClickListener V = new bfm(this);
  private View.OnClickListener W = new bfn(this);
  private View.OnClickListener X = new bfo(this);
  private View.OnClickListener Y = new bfp(this);
  private View.OnClickListener Z = new bfq(this);
  private View.OnClickListener aa = new bfr(this);
  private View.OnClickListener ab = new bfy(this);
  private View.OnClickListener ac = new bfz(this);
  private View.OnClickListener ad = new bgi(this);
  private final cfk ae = new bgk(this);
  private final cfk af = new bgl(this);
  private final cfk ag = new bgm(this);
  private final cfk ah = new bgn(this);
  private final cfk ai = new bgo(this);
  public final cgv onLowMemoryDialogPositive = new bgq(this);
  public final cgv overrideRebootDialogPositive = new bgh(this);
  
  private void A()
  {
    if (Build.VERSION.SDK_INT < 19) {
      findViewById(bdl.clientlayout).setSystemUiVisibility(0);
    }
  }
  
  private void B()
  {
    this.r = ((InputMethodManager)getSystemService("input_method")).showSoftInput(findViewById(bdl.DummyKeyboardEdit), 2);
    this.y = 100L;
  }
  
  private boolean C()
  {
    return findViewById(bdl.specialKeyboard).getVisibility() == 0;
  }
  
  private boolean D()
  {
    return findViewById(bdl.extraKeyboardLayout).getVisibility() == 0;
  }
  
  private boolean E()
  {
    return findViewById(bdl.toolbar_default).getVisibility() == 8;
  }
  
  private int F()
  {
    int i = 0;
    int j = getResources().getIdentifier("status_bar_height", "dimen", "android");
    if (j > 0) {
      i = getResources().getDimensionPixelSize(j);
    }
    return i;
  }
  
  private void G()
  {
    if (this.s.m) {
      this.t.j();
    }
  }
  
  private void H()
  {
    chb localchb = cgt.a();
    cgu localcgu = localchb.a();
    localcgu.b(true);
    localcgu.b(bdo.tv_message_RemoteRebootConfirmation_Title);
    localcgu.c(bdo.tv_message_RemoteRebootConfirmation);
    localcgu.d(bdo.tv_yes);
    localcgu.e(bdo.tv_no);
    localchb.a(this, new TVDialogListenerMetaData("overrideRebootDialogPositive", localcgu.W(), TVDialogListenerMetaData.Button.b));
    localchb.b(localcgu.W());
    localcgu.U();
  }
  
  private boolean I()
  {
    return (!this.s.f) && (!this.s.h) && (!this.s.m) && (!this.s.e);
  }
  
  private void a(int paramInt1, View.OnClickListener paramOnClickListener, bgy parambgy, int paramInt2)
  {
    View localView = findViewById(paramInt1);
    localView.setOnClickListener(paramOnClickListener);
    localView.setOnLongClickListener(parambgy);
    parambgy.a(paramInt1, paramInt2);
  }
  
  private void c(boolean paramBoolean)
  {
    int i = F();
    View localView = findViewById(bdl.extraKeyboardLayout);
    if (paramBoolean) {
      i = -i;
    }
    for (int j = 0;; j = -i)
    {
      TranslateAnimation localTranslateAnimation = new TranslateAnimation(0, 0.0F, 0, 0.0F, 0, i, 0, 0);
      localTranslateAnimation.setDuration(500L);
      localView.startAnimation(localTranslateAnimation);
      localView.setY(j);
      return;
    }
  }
  
  private void z()
  {
    if (Build.VERSION.SDK_INT < 19) {
      findViewById(bdl.clientlayout).setSystemUiVisibility(1);
    }
  }
  
  protected void a(Configuration paramConfiguration)
  {
    p();
  }
  
  protected void a(Observable paramObservable, Object paramObject) {}
  
  protected void a(cls paramcls)
  {
    this.n = new axy(this.q, paramcls.e());
  }
  
  protected void b(cls paramcls)
  {
    ((TVSpecialKeyboard)findViewById(bdl.specialKeyboard)).setKeyboard(paramcls.f());
    this.o = new axw(paramcls, this.q);
    j();
    a(paramcls);
  }
  
  protected void c(cls paramcls)
  {
    cmz localcmz = paramcls.w();
    paramcls = paramcls.v();
    if ((paramcls.r() == ceu.b) && (localcmz.a()) && (localcmz.D))
    {
      this.u = new bkd(paramcls, this);
      this.v = new bkg();
      this.m = new bld();
      this.w = false;
      this.x = true;
      Logging.b("RCClientActivity", "setMouseAndZoomListeners(): setup ControlMode: TouchToTouch");
      return;
    }
    if ((paramcls.r() == ceu.b) && (localcmz.D))
    {
      this.u = new bkb(paramcls);
      this.v = new bke();
      this.m = new bkv();
      this.x = true;
      Logging.b("RCClientActivity", "setMouseAndZoomListeners(): setup ControlMode: DirectTouch");
      return;
    }
    this.u = new bkc(paramcls);
    this.v = new bkf();
    this.m = new bkz();
    this.x = false;
    Logging.b("RCClientActivity", "setMouseAndZoomListeners(): setup ControlMode: Mouse");
  }
  
  public void g()
  {
    int i = 0;
    ImageView localImageView = (ImageView)findViewById(bdl.client_button_close);
    View localView1 = findViewById(bdl.client_button_keyboard);
    View localView2 = findViewById(bdl.client_button_requestControl);
    View localView3 = findViewById(bdl.client_button_settings);
    View localView4 = findViewById(bdl.client_button_win_ui_control);
    View localView5 = findViewById(bdl.client_button_options);
    View localView6 = findViewById(bdl.client_button_hidetoolbar);
    Object localObject1 = (ImageView)findViewById(bdl.client_button_input_method);
    View localView7 = findViewById(bdl.client_button_ctrl_alt_del);
    View localView8 = findViewById(bdl.client_button_next_monitor);
    Object localObject2 = ciz.b();
    if (localObject2 != null)
    {
      localObject2 = ((cme)localObject2).u().a(cms.c);
      if (localObject2 == null) {
        Logging.d("RCClientActivity", "updateToolbarInternal(): missing data");
      }
    }
    else
    {
      return;
    }
    if (this.t.q()) {
      localImageView.setImageResource(bdk.stoolbar_close_lock);
    }
    label192:
    label263:
    label299:
    int k;
    switch (o.bgr.b[localObject2.ordinal()])
    {
    default: 
      if (I())
      {
        Logging.a("RCClientActivity", "updateToolbarInternal(): hiding button settings because no actions available");
        localView3.setVisibility(8);
      }
      if (this.s.B != 0) {
        i = 1;
      }
      if ((i != 0) && ((localObject2 == cmq.a) || ((localObject2 == cmq.b) && (this.t.a()))))
      {
        localView4.setVisibility(0);
        if ((chr.a().c()) && (this.s.D))
        {
          if (this.t.r() != ceu.b) {
            break label692;
          }
          i = bdk.stoolbar_im_mouse;
          ((ImageView)localObject1).setImageResource(i);
          ((ImageView)localObject1).setVisibility(0);
        }
        localObject1 = new DisplayMetrics();
        localObject2 = getWindowManager();
        if (localObject2 == null) {
          break label709;
        }
        localObject2 = ((WindowManager)localObject2).getDefaultDisplay();
        if (localObject2 == null) {
          break label699;
        }
        ((Display)localObject2).getMetrics((DisplayMetrics)localObject1);
        k = (int)(((DisplayMetrics)localObject1).widthPixels / ((DisplayMetrics)localObject1).xdpi * 160.0F);
        if (localImageView.getVisibility() == 8) {
          break label719;
        }
      }
      break;
    }
    label692:
    label699:
    label709:
    label719:
    for (int j = 1;; j = 0)
    {
      i = j;
      if (localView1.getVisibility() != 8) {
        i = j + 1;
      }
      j = i;
      if (localView2.getVisibility() != 8) {
        j = i + 1;
      }
      i = j;
      if (localView3.getVisibility() != 8) {
        i = j + 1;
      }
      j = i;
      if (localView4.getVisibility() != 8) {
        j = i + 1;
      }
      i = j;
      if (localView5.getVisibility() != 8) {
        i = j + 1;
      }
      j = i;
      if (localView6.getVisibility() != 8) {
        j = i + 1;
      }
      localView7.setVisibility(8);
      localView8.setVisibility(8);
      i = j;
      if ((j + 1) * 49 < k)
      {
        i = j;
        if (this.s.f) {
          if (this.s.H.b() != chp.c)
          {
            i = j;
            if (this.s.H.a() != chp.b) {}
          }
          else
          {
            localView7.setVisibility(0);
            i = j + 1;
          }
        }
      }
      if (((i + 1) * 49 >= k) || (this.t.e() <= 1)) {
        break;
      }
      localView8.setVisibility(0);
      return;
      localView1.setVisibility(0);
      localView3.setVisibility(0);
      localView2.setVisibility(8);
      break label192;
      if (this.t.a())
      {
        localView1.setVisibility(0);
        localView3.setVisibility(0);
      }
      for (;;)
      {
        localView2.setVisibility(0);
        break;
        localView1.setVisibility(8);
        localView3.setVisibility(8);
      }
      localView1.setVisibility(8);
      localView3.setVisibility(8);
      localView2.setVisibility(8);
      break label192;
      localView4.setVisibility(8);
      break label263;
      i = bdk.stoolbar_im_touch;
      break label299;
      Logging.d("RCClientActivity", "updateToolbarInternal(): display is null");
      return;
      Logging.d("RCClientActivity", "updateToolbarInternal(): wm is null");
      return;
    }
  }
  
  protected void h()
  {
    if (this.s.b >= 4096) {
      ((ImageButton)findViewById(bdl.extraKeyboard_WinKey)).setImageResource(bdk.key_extra_apple);
    }
  }
  
  public void i()
  {
    runOnUiThread(new bez(this));
  }
  
  protected void j()
  {
    ((TVDummyKeyboardInputView)findViewById(bdl.DummyKeyboardEdit)).setTVKeyListener(this.o);
  }
  
  protected void k()
  {
    setContentView(bdm.activity_client);
    Logging.b("RCClientActivity", "onActivityCreated(): setContentView ok");
    chc.a().b();
    cme localcme = ciz.b();
    if ((localcme == null) || (!ciz.a().k()))
    {
      Logging.d("RCClientActivity", "onActivityCreated(): no session running!");
      finish();
    }
    do
    {
      return;
      cls localcls = (cls)localcme;
      ayo.a().c(this);
      if (axt.b())
      {
        q();
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(new bfj(this));
        localObject = findViewById(bdl.extraKeyboardLayout);
        int i = F();
        ((View)localObject).setPadding(0, i, 0, 0);
        ((View)localObject).setY(-i);
      }
      Object localObject = new bgy(this);
      a(bdl.client_button_close, this.ab, (bgy)localObject, bdo.tv_session_toolbar_info_button_close);
      a(bdl.client_button_ctrl_alt_del, this.ad, (bgy)localObject, bdo.tv_session_toolbar_info_button_ctrl_alt_del);
      a(bdl.client_button_next_monitor, this.W, (bgy)localObject, bdo.tv_session_toolbar_info_button_next_monitor);
      a(bdl.client_button_keyboard, this.X, (bgy)localObject, bdo.tv_session_toolbar_info_button_keyboard);
      a(bdl.client_button_input_method, this.Y, (bgy)localObject, bdo.tv_session_toolbar_info_button_input_method);
      a(bdl.client_button_requestControl, this.Z, (bgy)localObject, bdo.tv_session_toolbar_info_button_requestControl);
      a(bdl.client_button_settings, this.aa, (bgy)localObject, bdo.tv_session_toolbar_info_button_settings);
      a(bdl.client_button_win_ui_control, this.ac, (bgy)localObject, bdo.tv_session_toolbar_info_button_win_ui_control);
      a(bdl.client_button_options, this.V, (bgy)localObject, bdo.tv_session_toolbar_info_button_options);
      a(bdl.client_button_hidetoolbar, this.S, (bgy)localObject, bdo.tv_session_toolbar_info_button_hidetoolbar);
      this.D = new GestureDetector(this, new bgz(this, null));
      findViewById(bdl.extraKeyboard_close).setOnClickListener(this.U);
      findViewById(bdl.extraKeyboard_Shift).setOnClickListener(this.N);
      findViewById(bdl.extraKeyboard_Ctrl).setOnClickListener(this.O);
      findViewById(bdl.extraKeyboard_Alt).setOnClickListener(this.P);
      findViewById(bdl.extraKeyboard_WinKey).setOnClickListener(this.Q);
      findViewById(bdl.extraKeyboard_Keyboard).setOnClickListener(this.R);
      findViewById(bdl.session_showtoolbar).setOnTouchListener(this.T);
      this.s = localcme.w();
      this.t = localcme.v();
      this.p = localcls.f();
      this.p.a(this.A);
      localcme.u().addObserver(this);
      this.s.addObserver(this);
      localcls.a(this);
      localcls.a(this);
      this.B = cjk.a().getBoolean("HELP_ON_STARTUP_ROCKHOPPER", true);
      if (localcls.k()) {
        b(false);
      }
      setVolumeControlStream(3);
      Logging.b("RCClientActivity", "init done");
      chu.a().b();
      chu.a().a(true);
    } while (EventHub.a().a(this.z, cfl.aY));
    Logging.d("RCClientActivity", "onActivityCreated(): register InputChanged event failed");
  }
  
  protected void l()
  {
    EventHub localEventHub = EventHub.a();
    if (!localEventHub.a(this.ae, cfl.az)) {
      Logging.d("RCClientActivity", "onActivityStart(): register RemoteWindowsSessionInfoReceived event failed");
    }
    if (!localEventHub.a(this.af, cfl.ah)) {
      Logging.d("RCClientActivity", "onActivityStart(): register InputDisabled event failed");
    }
    if (!localEventHub.a(this.ah, cfl.aw)) {
      Logging.d("RCClientActivity", "onActivityStart(): register SoftkeyboardShown event failed");
    }
    if (!localEventHub.a(this.ag, cfl.av)) {
      Logging.d("RCClientActivity", "onActivityStart(): register SoftkeyboardHidden event failed");
    }
  }
  
  protected void m()
  {
    View localView = findViewById(bdl.DummyKeyboardEdit);
    localView.setFocusable(true);
    localView.setFocusableInTouchMode(true);
    localView.requestFocus();
    if (!EventHub.a().a(this.ai, cfl.ag)) {
      Logging.d("RCClientActivity", "register OnLowMemory event failed");
    }
  }
  
  protected void n()
  {
    EventHub localEventHub = EventHub.a();
    if (!localEventHub.a(this.ae)) {
      Logging.d("RCClientActivity", "unregister RemoteWindowsSessionInfoReceived event failed");
    }
    if (!localEventHub.a(this.af)) {
      Logging.d("RCClientActivity", "unregister InputDisabled event failed");
    }
    if (!localEventHub.a(this.ag)) {
      Logging.d("RCClientActivity", "unregister SoftkeyboardHidden event failed");
    }
    if (!localEventHub.a(this.ah)) {
      Logging.d("RCClientActivity", "unregister SoftKeyboardShown event failed");
    }
    p();
  }
  
  protected void o()
  {
    Object localObject1 = new ArrayList(14);
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_close));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_ctrl_alt_del));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_next_monitor));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_keyboard));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_requestControl));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_settings));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_win_ui_control));
    ((List)localObject1).add(Integer.valueOf(bdl.client_button_options));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_Shift));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_Ctrl));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_Alt));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_WinKey));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_Keyboard));
    ((List)localObject1).add(Integer.valueOf(bdl.extraKeyboard_close));
    localObject1 = ((List)localObject1).iterator();
    while (((Iterator)localObject1).hasNext())
    {
      Object localObject2 = (ImageButton)findViewById(((Integer)((Iterator)localObject1).next()).intValue());
      ((ImageButton)localObject2).setOnClickListener(null);
      ((ImageButton)localObject2).setOnLongClickListener(null);
      localObject2 = ((ImageButton)localObject2).getDrawable();
      if (localObject2 != null) {
        ((Drawable)localObject2).setCallback(null);
      }
    }
    this.ad = null;
    this.W = null;
    this.X = null;
    this.Z = null;
    this.aa = null;
    this.V = null;
    this.U = null;
    this.N = null;
    this.O = null;
    this.P = null;
    this.Q = null;
    this.R = null;
    this.S = null;
    this.T = null;
    this.D = null;
    this.E = null;
    this.F = null;
    this.K = null;
    this.M = null;
    this.L = null;
    this.J = null;
    ((TVSpecialKeyboard)findViewById(bdl.specialKeyboard)).setKeyboard((cek)null);
  }
  
  public void onBackPressed()
  {
    if (C())
    {
      if (!this.C)
      {
        localObject = AnimationUtils.loadAnimation(this, bdg.slide_down);
        ((Animation)localObject).setAnimationListener(this.I);
        findViewById(bdl.specialKeyboard).startAnimation((Animation)localObject);
        return;
      }
      localObject = AnimationUtils.loadAnimation(this, bdg.slide_extra_toolbar_up);
      ((Animation)localObject).setAnimationListener(this.F);
      findViewById(bdl.extraKeyboardLayout).startAnimation((Animation)localObject);
      localObject = AnimationUtils.loadAnimation(this, bdg.slide_down);
      ((Animation)localObject).setAnimationListener(this.I);
      findViewById(bdl.specialKeyboard).startAnimation((Animation)localObject);
      return;
    }
    Object localObject = (bot)f().a(bdl.startup_help);
    if ((localObject != null) && (((bot)localObject).s()))
    {
      ((bot)localObject).b();
      return;
    }
    w();
  }
  
  public void p()
  {
    ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(bdl.DummyKeyboardEdit).getWindowToken(), 0);
    this.r = false;
  }
  
  public void q()
  {
    getWindow().getDecorView().setSystemUiVisibility(3846);
  }
  
  public void r()
  {
    Intent localIntent = new Intent(this, SessionSettingsActivity.class);
    localIntent.putExtra("extra_settings_type", 1);
    startActivity(localIntent);
  }
  
  protected void s()
  {
    if (!EventHub.a().a(this.ai)) {
      Logging.d("RCClientActivity", "unregister OnLowMemory event failed");
    }
  }
  
  protected void t()
  {
    super.t();
    if (this.B) {
      x();
    }
  }
  
  public void x()
  {
    if (this.r) {
      p();
    }
    gc localgc = f().a();
    localgc.a(bdl.startup_help, bot.a(false, true));
    localgc.a();
  }
  
  public boolean y()
  {
    return (D()) || (C());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/RCClientActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */