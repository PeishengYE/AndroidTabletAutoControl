package com.teamviewer.remotecontrollib.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;
import com.teamviewer.commonresourcelib.gui.TVDummyKeyboardInputView;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.remotecontrollib.gui.view.InstructionsOverlayView;
import com.teamviewer.remotecontrollib.gui.view.M2MControlView;
import com.teamviewer.remotecontrollib.gui.view.M2MSpecialKeyboard;
import com.teamviewer.remotecontrollib.gui.view.M2MZoomView;
import com.teamviewer.teamviewerlib.event.EventHub;
import com.teamviewer.teamviewerlib.statistics.AndroidM2MStatistics;
import java.util.Observable;
import o.avh;
import o.axt;
import o.axw;
import o.ayo;
import o.bdl;
import o.bdm;
import o.bdo;
import o.bds;
import o.bed;
import o.bef;
import o.beg;
import o.beh;
import o.bei;
import o.bej;
import o.bek;
import o.bki;
import o.bkj;
import o.bkk;
import o.bkq;
import o.bot;
import o.bvp;
import o.bvv;
import o.bvw;
import o.cfl;
import o.cfw;
import o.cgh;
import o.cgi;
import o.chc;
import o.chu;
import o.cif;
import o.ciz;
import o.cjk;
import o.cls;
import o.cme;
import o.cmp;
import o.cmv;
import o.cmz;
import o.cnb;
import o.fp;

public class M2MClientActivity
  extends bds
  implements avh, bkj, bvp, bvv
{
  private Handler B;
  private boolean C = false;
  private int D = -1;
  private View E;
  private M2MZoomView F;
  private InstructionsOverlayView G;
  private boolean H = false;
  private boolean I = false;
  
  private boolean D()
  {
    return ((bki)this.u).o();
  }
  
  private void E()
  {
    Rect localRect = new Rect();
    View localView = getWindow().getDecorView();
    localView.getWindowVisibleDisplayFrame(localRect);
    int i = localView.getHeight() - localRect.height() - localRect.top;
    if (i != this.D)
    {
      ((RelativeLayout.LayoutParams)this.E.getLayoutParams()).setMargins(0, 0, 0, i);
      this.E.requestLayout();
      this.D = i;
    }
  }
  
  private void F()
  {
    boolean bool = D();
    Logging.b("M2MClientActivity", "Update zoom: enabled=" + bool);
    bkq localbkq = (bkq)this.m;
    if (bool) {
      if (this.C)
      {
        localbkq.a(true);
        this.F.setZoomState(bvw.b);
        this.F.setVisibility(0);
      }
    }
    for (;;)
    {
      d(bool);
      c(bool);
      return;
      localbkq.a(false);
      this.F.setZoomState(bvw.a);
      break;
      localbkq.a(true);
      this.F.setVisibility(8);
    }
  }
  
  private void G()
  {
    this.F.a();
    this.F.c();
    this.F.d();
    this.F.setOnTouchListener(new bei(this));
    findViewById(bdl.instructions_got_it_button).setOnClickListener(new bej(this));
    this.G.setVisibility(0);
    this.H = true;
    this.I = true;
  }
  
  private void H()
  {
    if (!this.C) {}
    for (boolean bool = true;; bool = false)
    {
      this.C = bool;
      ((bkq)this.m).a(this.C);
      return;
    }
  }
  
  private boolean I()
  {
    ((InputMethodManager)getSystemService("input_method")).hideSoftInputFromWindow(findViewById(bdl.DummyKeyboardEdit).getWindowToken(), 0);
    this.E.setVisibility(8);
    this.r = false;
    return true;
  }
  
  private void J()
  {
    TVDummyKeyboardInputView localTVDummyKeyboardInputView = (TVDummyKeyboardInputView)findViewById(bdl.DummyKeyboardEdit);
    localTVDummyKeyboardInputView.setVisibility(0);
    localTVDummyKeyboardInputView.setFocusable(true);
    localTVDummyKeyboardInputView.requestFocus();
    ((InputMethodManager)getSystemService("input_method")).toggleSoftInput(2, 0);
    this.E.setVisibility(0);
    this.r = true;
  }
  
  private void c(boolean paramBoolean)
  {
    float f = this.t.g() / 100.0F;
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    int i = this.t.i().a;
    int j = this.t.i().b;
    AndroidM2MStatistics.a(paramBoolean, localDisplayMetrics.widthPixels, localDisplayMetrics.heightPixels, (int)((bki)this.u).d(), i, j, (int)(f * 160.0F));
  }
  
  private void d(boolean paramBoolean)
  {
    int i = cjk.a().getInt("ZOOM_HELP_ON_STARTUP_COUNT", 0);
    if ((paramBoolean) && (i <= 2) && (!this.I)) {
      G();
    }
    while ((paramBoolean) || (!this.H)) {
      return;
    }
    e(false);
  }
  
  private void e(boolean paramBoolean)
  {
    if (paramBoolean) {
      this.G.animate().alpha(0.0F).setDuration(350L).setListener(new bek(this));
    }
    for (;;)
    {
      this.H = false;
      this.F.setOnTouchListener(null);
      this.F.d();
      this.F.b();
      int i = cjk.a().getInt("ZOOM_HELP_ON_STARTUP_COUNT", 0);
      cjk.a().edit().putInt("ZOOM_HELP_ON_STARTUP_COUNT", i + 1).commit();
      return;
      this.G.setVisibility(8);
    }
  }
  
  public void A()
  {
    w();
  }
  
  public void B() {}
  
  public void C()
  {
    int i = cjk.a().getInt("MAX_ZOOM_TRIALS_COUNT", 0);
    if (i < 1)
    {
      cjk.a().edit().putInt("MAX_ZOOM_TRIALS_COUNT", i + 1).commit();
      G();
    }
  }
  
  protected void a(Configuration paramConfiguration) {}
  
  protected void a(Observable paramObservable, Object paramObject)
  {
    if (((paramObservable instanceof cgh)) || ((paramObservable instanceof cgi))) {
      cif.a.a(new beg(this));
    }
  }
  
  protected void a(cls paramcls) {}
  
  public boolean a_()
  {
    return I();
  }
  
  protected void b(cls paramcls)
  {
    ((M2MSpecialKeyboard)findViewById(bdl.specialKeyboard)).setKeyboardListeners(paramcls.f());
    this.o = new axw(paramcls, this.q);
    paramcls = (TVDummyKeyboardInputView)findViewById(bdl.DummyKeyboardEdit);
    paramcls.setTVKeyListener(this.o);
    paramcls.setKeyboardStateChangeListener(this);
  }
  
  protected void c(cls paramcls)
  {
    this.u = new bki(paramcls.v());
    ((bki)this.u).a(this);
    this.v = new bkk();
    this.m = new bkq(this);
    this.w = true;
    this.x = true;
    Logging.b("M2MClientActivity", "setMouseAndZoomListeners(): setup ControlMode: M2MTouchToTouch");
  }
  
  protected void g() {}
  
  protected void h() {}
  
  protected void i() {}
  
  protected void j()
  {
    TVDummyKeyboardInputView localTVDummyKeyboardInputView = (TVDummyKeyboardInputView)findViewById(bdl.DummyKeyboardEdit);
    localTVDummyKeyboardInputView.setTVKeyListener(this.o);
    localTVDummyKeyboardInputView.setKeyboardStateChangeListener(this);
  }
  
  protected void k()
  {
    this.B = new Handler();
    if (axt.b()) {
      getWindow().setSoftInputMode(18);
    }
    setContentView(bdm.m2m_activity_client);
    this.G = ((InstructionsOverlayView)findViewById(bdl.m2m_instructions_overlay));
    this.F = ((M2MZoomView)findViewById(bdl.m2m_zoomview));
    this.F.setTouchInterceptor(this);
    M2MControlView localM2MControlView = (M2MControlView)findViewById(bdl.m2m_controlview);
    localM2MControlView.setTouchInterceptor(this);
    chc.a().b();
    Object localObject = ciz.b();
    if ((localObject == null) || (!ciz.a().k()))
    {
      Logging.d("M2MClientActivity", "onActivityCreated: no session running!");
      finish();
      return;
    }
    ayo.a().c(this);
    if (axt.b())
    {
      q();
      getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(new bed(this));
    }
    this.t = ((cme)localObject).v();
    this.s = ((cme)localObject).w();
    this.s.addObserver(this);
    ((cme)localObject).u().addObserver(this);
    localObject = (cls)localObject;
    ((cls)localObject).a(this);
    ((cls)localObject).a(this);
    this.p = ((cls)localObject).f();
    if (this.p != null) {}
    for (boolean bool = true;; bool = false)
    {
      localM2MControlView.setMiddleButtonEnabled(bool);
      this.E = findViewById(bdl.specialKeyboardContainer);
      if (((cls)localObject).k()) {
        b(false);
      }
      chu.a().b();
      chu.a().a(true);
      if (!EventHub.a().a(this.z, cfl.aY)) {
        Logging.d("M2MClientActivity", "onActivityCreated(): register InputChanged event failed");
      }
      findViewById(bdl.clientlayout).getViewTreeObserver().addOnGlobalLayoutListener(new bef(this));
      Logging.b("M2MClientActivity", "init done");
      return;
    }
  }
  
  protected void l() {}
  
  protected void m()
  {
    ayo.a().b(this);
    this.q.getDimensionView().addObserver(this);
    this.q.getDimensionBitmap().addObserver(this);
  }
  
  protected void n() {}
  
  protected void o()
  {
    ((M2MSpecialKeyboard)findViewById(bdl.specialKeyboard)).setKeyboardListeners(null);
  }
  
  public void onBackPressed()
  {
    if (this.r)
    {
      I();
      return;
    }
    bot localbot = (bot)f().a(bdl.startup_help);
    if ((localbot != null) && (localbot.s()))
    {
      localbot.b();
      return;
    }
    w();
  }
  
  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    if ((paramIntent.getBooleanExtra("extra_show_instructions_view", false)) && (D())) {
      G();
    }
  }
  
  public void onWindowFocusChanged(boolean paramBoolean)
  {
    if ((axt.b()) && (paramBoolean)) {
      this.B.postDelayed(new beh(this), 100L);
    }
  }
  
  protected void p()
  {
    I();
  }
  
  public void q()
  {
    getWindow().getDecorView().setSystemUiVisibility(5894);
  }
  
  protected void r() {}
  
  protected void s()
  {
    I();
    this.q.getDimensionView().deleteObserver(this);
    this.q.getDimensionBitmap().deleteObserver(this);
  }
  
  public void x()
  {
    H();
  }
  
  public void y()
  {
    if (this.p != null)
    {
      J();
      return;
    }
    Toast.makeText(this, bdo.tv_remote_input_not_supported, 0).show();
  }
  
  public void z()
  {
    I();
    boolean bool = D();
    Intent localIntent = new Intent(this, SessionSettingsActivity.class);
    localIntent.putExtra("extra_settings_type", 2);
    if (!bool) {}
    for (bool = true;; bool = false)
    {
      localIntent.putExtra("extra_disable_instructions", bool);
      startActivity(localIntent);
      return;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/M2MClientActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */