package com.teamviewer.remotecontrollib.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.teamviewer.corelib.logging.Logging;
import o.ayo;
import o.ciz;

public class NotificationHandlerActivity
  extends Activity
{
  private boolean a()
  {
    if (ayo.a().e() != null)
    {
      Logging.c("NotificationHandlerActivity", "A session is already running!");
      return false;
    }
    ciz localciz = ciz.a();
    if ((localciz.k()) || (localciz.i()))
    {
      Logging.c("NotificationHandlerActivity", "A session is already running!");
      return false;
    }
    return true;
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    Logging.b("NotificationHandlerActivity", "onCreate");
    paramBundle = getIntent();
    if ((paramBundle != null) && (paramBundle.getExtras().getBoolean("SHOW_CHAT", false)) && (a()))
    {
      Intent localIntent = new Intent(this, MainActivity.class);
      localIntent.setAction("android.intent.action.MAIN");
      localIntent.addCategory("android.intent.category.LAUNCHER");
      localIntent.addFlags(268435456);
      localIntent.addFlags(67108864);
      if ((paramBundle.getFlags() & 0x100000) != 1048576)
      {
        localIntent.putExtra("SHOW_CHAT", true);
        localIntent.putExtra("CHATROOMID", paramBundle.getExtras().getString("CHATROOMID"));
      }
      startActivity(localIntent);
    }
    Logging.b("NotificationHandlerActivity", "ending chat notification handler activity");
    finish();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/NotificationHandlerActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */