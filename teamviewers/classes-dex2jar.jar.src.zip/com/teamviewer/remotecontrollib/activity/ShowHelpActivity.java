package com.teamviewer.remotecontrollib.activity;

import android.os.Bundle;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import com.teamviewer.teamviewerlib.event.EventHub;
import o.ayo;
import o.bhg;
import o.bot;
import o.cfk;
import o.cfl;
import o.ciz;
import o.fi;
import o.fp;
import o.gc;

@OptionsActivity
public class ShowHelpActivity
  extends fi
{
  private boolean m = true;
  private final cfk n = new bhg(this);
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    if (paramBundle == null)
    {
      paramBundle = f().a();
      paramBundle.a(16908290, bot.a(true, false));
      paramBundle.a();
    }
    if (ciz.b() == null) {
      this.m = false;
    }
  }
  
  protected void onPause()
  {
    super.onPause();
    if ((this.m) && (!EventHub.a().a(this.n))) {
      Logging.d("ShowHelpActivity", "unregister m_OnSessionEnd event failed");
    }
  }
  
  protected void onResume()
  {
    super.onResume();
    if (this.m)
    {
      if (ciz.b() != null) {
        break label36;
      }
      Logging.b("ShowHelpActivity", "no session in onresume, finish activity");
      this.n.a(null, null);
    }
    label36:
    while (EventHub.a().a(this.n, cfl.aP)) {
      return;
    }
    Logging.d("ShowHelpActivity", "register OnSessionEnd event failed");
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/activity/ShowHelpActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */