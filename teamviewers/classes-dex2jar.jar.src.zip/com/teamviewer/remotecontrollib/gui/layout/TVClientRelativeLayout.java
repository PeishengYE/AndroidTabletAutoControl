package com.teamviewer.remotecontrollib.gui.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.RelativeLayout;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.event.EventHub;
import o.cfl;

public class TVClientRelativeLayout
  extends RelativeLayout
{
  private boolean a = false;
  
  public TVClientRelativeLayout(Context paramContext)
  {
    super(paramContext);
  }
  
  public TVClientRelativeLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt2);
    int j = getHeight();
    if (j > i)
    {
      EventHub.a().a(cfl.aw);
      Logging.b("TVClientRelativeLayout", "onMeasure(): softkeyboardShown triggered");
    }
    for (this.a = true;; this.a = false)
    {
      do
      {
        super.onMeasure(paramInt1, paramInt2);
        return;
      } while ((!this.a) || (j >= i));
      EventHub.a().a(cfl.av);
      Logging.b("TVClientRelativeLayout", "onMeasure(): softkeyboardHidden triggered");
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/layout/TVClientRelativeLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */