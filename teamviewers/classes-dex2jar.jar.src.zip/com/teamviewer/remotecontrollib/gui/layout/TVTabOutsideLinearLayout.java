package com.teamviewer.remotecontrollib.gui.layout;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import o.axt;

public class TVTabOutsideLinearLayout
  extends LinearLayout
{
  private final Rect a = new Rect();
  
  public TVTabOutsideLinearLayout(Context paramContext)
  {
    super(paramContext);
  }
  
  public TVTabOutsideLinearLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  private boolean a(ViewGroup paramViewGroup, MotionEvent paramMotionEvent)
  {
    int i = 0;
    boolean bool2 = true;
    for (;;)
    {
      boolean bool1 = bool2;
      View localView;
      if (i < paramViewGroup.getChildCount())
      {
        localView = paramViewGroup.getChildAt(i);
        if (!(localView instanceof EditText)) {
          break label68;
        }
        localView.getGlobalVisibleRect(this.a);
        if (!this.a.contains((int)paramMotionEvent.getRawX(), (int)paramMotionEvent.getRawY())) {
          break label97;
        }
        bool1 = false;
      }
      label68:
      do
      {
        return bool1;
        if (!(localView instanceof ViewGroup)) {
          break;
        }
        bool2 = a((ViewGroup)localView, paramMotionEvent);
        bool1 = bool2;
      } while (!bool2);
      label97:
      i += 1;
    }
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    switch (paramMotionEvent.getAction())
    {
    }
    for (;;)
    {
      return super.onInterceptTouchEvent(paramMotionEvent);
      if (a(this, paramMotionEvent)) {
        axt.a(this);
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/layout/TVTabOutsideLinearLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */