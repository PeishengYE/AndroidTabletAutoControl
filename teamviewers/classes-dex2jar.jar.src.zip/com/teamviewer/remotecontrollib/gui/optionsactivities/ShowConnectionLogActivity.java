package com.teamviewer.remotecontrollib.gui.optionsactivities;

import android.os.Bundle;
import android.view.MenuItem;
import com.teamviewer.teamviewerlib.annotations.OptionsActivity;
import o.awd;
import o.ayo;
import o.bdm;
import o.btm;
import o.btn;

@OptionsActivity
public class ShowConnectionLogActivity
  extends awd
{
  public ShowConnectionLogActivity()
  {
    super(new btm());
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(bdm.activity_options);
    if ((paramBundle == null) || (!paramBundle.getBoolean("change"))) {
      b(new btn());
    }
  }
  
  public void onDestroy()
  {
    super.onDestroy();
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 16908332) {
      finish();
    }
    return true;
  }
  
  public void onPause()
  {
    super.onPause();
  }
  
  public void onRestart()
  {
    super.onRestart();
  }
  
  public void onRestoreInstanceState(Bundle paramBundle)
  {
    super.onRestoreInstanceState(paramBundle);
  }
  
  public void onResume()
  {
    super.onResume();
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
  }
  
  public void onStart()
  {
    super.onStart();
    ayo.a().d(this);
  }
  
  public void onStop()
  {
    super.onStop();
    ayo.a().e(this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/optionsactivities/ShowConnectionLogActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */