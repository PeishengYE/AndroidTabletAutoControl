package com.teamviewer.remotecontrollib.gui.tutorial;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import o.bui;
import o.buo;
import o.bup;
import o.buq;
import o.bur;
import o.bus;
import o.but;
import o.buu;
import o.buv;
import o.nf;
import o.oj;
import o.oz;
import o.pe;
import o.qc;
import o.tp;

public class TutorialViewPagerBottom
  extends ViewGroup
{
  private static final int[] a = { 16842931 };
  private static final Comparator<bur> b = new buo();
  private static final Interpolator c = new bup();
  private float A;
  private float B;
  private int C = -1;
  private VelocityTracker D;
  private int E;
  private int F;
  private int G;
  private boolean H;
  private tp I;
  private tp J;
  private boolean K = true;
  private boolean L;
  private int M;
  private buu N;
  private buu O;
  private but P;
  private int Q = 0;
  private boolean R = true;
  private final ArrayList<bur> d = new ArrayList();
  private bui e;
  private int f;
  private int g = -1;
  private Parcelable h = null;
  private ClassLoader i = null;
  private Scroller j;
  private buv k;
  private int l;
  private Drawable m;
  private int n;
  private int o;
  private int p;
  private int q;
  private boolean r;
  private boolean s;
  private boolean t;
  private boolean u;
  private int v = 1;
  private boolean w;
  private boolean x;
  private int y;
  private float z;
  
  public TutorialViewPagerBottom(Context paramContext)
  {
    super(paramContext);
    a();
  }
  
  public TutorialViewPagerBottom(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a();
  }
  
  private int a(int paramInt1, float paramFloat, int paramInt2, int paramInt3)
  {
    if ((Math.abs(paramInt3) > this.G) && (Math.abs(paramInt2) > this.E))
    {
      if (paramInt2 > 0) {
        return paramInt1;
      }
      return paramInt1 + 1;
    }
    return (int)(paramInt1 + paramFloat + 0.5F);
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt1 += paramInt3;
    if (paramInt2 > 0)
    {
      paramInt3 = getScrollX();
      paramInt2 += paramInt4;
      paramInt4 = paramInt3 / paramInt2;
      paramInt2 = (int)((paramInt3 % paramInt2 / paramInt2 + paramInt4) * paramInt1);
      scrollTo(paramInt2, getScrollY());
      if (!this.j.isFinished())
      {
        paramInt3 = this.j.getDuration();
        paramInt4 = this.j.timePassed();
        this.j.startScroll(paramInt2, 0, paramInt1 * this.f, 0, paramInt3 - paramInt4);
      }
    }
    do
    {
      return;
      paramInt1 = this.f * paramInt1;
    } while (paramInt1 == getScrollX());
    h();
    scrollTo(paramInt1, getScrollY());
  }
  
  private void a(MotionEvent paramMotionEvent)
  {
    int i1 = oj.b(paramMotionEvent);
    if (oj.b(paramMotionEvent, i1) == this.C) {
      if (i1 != 0) {
        break label56;
      }
    }
    label56:
    for (i1 = 1;; i1 = 0)
    {
      this.A = oj.c(paramMotionEvent, i1);
      this.C = oj.b(paramMotionEvent, i1);
      if (this.D != null) {
        this.D.clear();
      }
      return;
    }
  }
  
  private void b(int paramInt)
  {
    int i1 = getWidth() + this.l;
    int i2 = paramInt / i1;
    paramInt %= i1;
    float f1 = paramInt / i1;
    this.L = false;
    a(i2, f1, paramInt);
    if (!this.L) {
      throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }
  }
  
  private void g()
  {
    int i2;
    for (int i1 = 0; i1 < getChildCount(); i1 = i2 + 1)
    {
      i2 = i1;
      if (!((bus)getChildAt(i1).getLayoutParams()).a)
      {
        removeViewAt(i1);
        i2 = i1 - 1;
      }
    }
  }
  
  private void h()
  {
    boolean bool = this.u;
    if (bool)
    {
      setScrollingCacheEnabled(false);
      this.j.abortAnimation();
      i1 = getScrollX();
      int i2 = getScrollY();
      int i3 = this.j.getCurrX();
      int i4 = this.j.getCurrY();
      if ((i1 != i3) || (i2 != i4)) {
        scrollTo(i3, i4);
      }
      setScrollState(0);
    }
    this.t = false;
    this.u = false;
    int i1 = 0;
    while (i1 < this.d.size())
    {
      bur localbur = (bur)this.d.get(i1);
      if (localbur.c)
      {
        bool = true;
        localbur.c = false;
      }
      i1 += 1;
    }
    if (bool) {
      c();
    }
  }
  
  private void i()
  {
    this.w = false;
    this.x = false;
    if (this.D != null)
    {
      this.D.recycle();
      this.D = null;
    }
  }
  
  private void setScrollState(int paramInt)
  {
    if (this.Q == paramInt) {}
    do
    {
      return;
      this.Q = paramInt;
    } while (this.N == null);
    this.N.b(paramInt);
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean)
  {
    if (this.s != paramBoolean) {
      this.s = paramBoolean;
    }
  }
  
  float a(float paramFloat)
  {
    return (float)Math.sin((float)((paramFloat - 0.5F) * 0.4712389167638204D));
  }
  
  bur a(View paramView)
  {
    int i1 = 0;
    while (i1 < this.d.size())
    {
      bur localbur = (bur)this.d.get(i1);
      if (this.e.a(paramView, localbur.a)) {
        return localbur;
      }
      i1 += 1;
    }
    return null;
  }
  
  void a()
  {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context localContext = getContext();
    this.j = new Scroller(localContext, c);
    ViewConfiguration localViewConfiguration = ViewConfiguration.get(localContext);
    this.y = qc.a(localViewConfiguration);
    this.E = localViewConfiguration.getScaledMinimumFlingVelocity();
    this.F = localViewConfiguration.getScaledMaximumFlingVelocity();
    this.I = new tp(localContext);
    this.J = new tp(localContext);
    this.G = ((int)(localContext.getResources().getDisplayMetrics().density * 25.0F));
  }
  
  protected void a(int paramInt1, float paramFloat, int paramInt2)
  {
    if (this.M > 0)
    {
      int i6 = getScrollX();
      int i1 = getPaddingLeft();
      int i2 = getPaddingRight();
      int i7 = getWidth();
      int i8 = getChildCount();
      int i5 = 0;
      while (i5 < i8)
      {
        View localView = getChildAt(i5);
        bus localbus = (bus)localView.getLayoutParams();
        int i4;
        int i3;
        if (!localbus.a)
        {
          i4 = i1;
          i3 = i2;
          i5 += 1;
          i1 = i4;
          i2 = i3;
        }
        else
        {
          switch (localbus.b & 0x7)
          {
          case 2: 
          case 4: 
          default: 
            i3 = i1;
            i4 = i2;
            i2 = i1;
            i1 = i4;
          }
          for (;;)
          {
            int i9 = i3 + i6 - localView.getLeft();
            i3 = i1;
            i4 = i2;
            if (i9 == 0) {
              break;
            }
            localView.offsetLeftAndRight(i9);
            i3 = i1;
            i4 = i2;
            break;
            i3 = localView.getWidth();
            i4 = i3 + i1;
            i3 = i1;
            i1 = i2;
            i2 = i4;
            continue;
            i3 = Math.max((i7 - localView.getMeasuredWidth()) / 2, i1);
            i4 = i1;
            i1 = i2;
            i2 = i4;
            continue;
            i3 = i7 - i2 - localView.getMeasuredWidth();
            i9 = localView.getMeasuredWidth();
            i4 = i1;
            i1 = i2 + i9;
            i2 = i4;
          }
        }
      }
    }
    if (this.N != null) {
      this.N.a(paramInt1, paramFloat, paramInt2);
    }
    if (this.O != null) {
      this.O.a(paramInt1, paramFloat, paramInt2);
    }
    this.L = true;
  }
  
  void a(int paramInt1, int paramInt2)
  {
    bur localbur = new bur();
    localbur.b = paramInt1;
    localbur.a = this.e.a(this, paramInt1);
    if (paramInt2 < 0)
    {
      this.d.add(localbur);
      return;
    }
    this.d.add(paramInt2, localbur);
  }
  
  void a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (getChildCount() == 0)
    {
      setScrollingCacheEnabled(false);
      return;
    }
    paramInt3 = getScrollX();
    int i1 = getScrollY();
    int i2 = paramInt1 - paramInt3;
    paramInt2 -= i1;
    if ((i2 == 0) && (paramInt2 == 0))
    {
      h();
      setScrollState(0);
      return;
    }
    setScrollingCacheEnabled(true);
    this.u = true;
    setScrollState(2);
    paramInt1 = getWidth();
    int i3 = paramInt1 / 2;
    float f3 = Math.min(1.0F, Math.abs(i2) * 1.0F / paramInt1);
    float f1 = i3;
    float f2 = i3;
    f3 = a(f3);
    i3 = Math.abs(1);
    if (i3 > 0) {}
    for (paramInt1 = Math.round(1000.0F * Math.abs((f2 * f3 + f1) / i3)) * 4;; paramInt1 = (int)((Math.abs(i2) / (paramInt1 + this.l) + 1.0F) * 100.0F))
    {
      paramInt1 = Math.min(paramInt1, 600);
      this.j.startScroll(paramInt3, i1, i2, paramInt2, paramInt1 * 3);
      invalidate();
      return;
    }
  }
  
  public void a(int paramInt, boolean paramBoolean)
  {
    this.t = false;
    a(paramInt, paramBoolean, false);
  }
  
  void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    a(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  void a(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
  {
    if ((this.e == null) || (this.e.a() <= 0))
    {
      setScrollingCacheEnabled(false);
      return;
    }
    if ((!paramBoolean2) && (this.f == paramInt1) && (this.d.size() != 0))
    {
      setScrollingCacheEnabled(false);
      return;
    }
    int i1;
    if (paramInt1 < 0) {
      i1 = 0;
    }
    for (;;)
    {
      paramInt1 = this.v;
      if ((i1 <= this.f + paramInt1) && (i1 >= this.f - paramInt1)) {
        break;
      }
      paramInt1 = 0;
      while (paramInt1 < this.d.size())
      {
        ((bur)this.d.get(paramInt1)).c = true;
        paramInt1 += 1;
      }
      i1 = paramInt1;
      if (paramInt1 >= this.e.a()) {
        i1 = this.e.a() - 1;
      }
    }
    if (this.f != i1) {}
    int i2;
    for (paramInt1 = 1;; paramInt1 = 0)
    {
      this.f = i1;
      c();
      i2 = (getWidth() + this.l) * i1;
      if (!paramBoolean1) {
        break label246;
      }
      a(i2, 0, paramInt2);
      if ((paramInt1 != 0) && (this.N != null)) {
        this.N.a(i1);
      }
      if ((paramInt1 == 0) || (this.O == null)) {
        break;
      }
      this.O.a(i1);
      return;
    }
    label246:
    if ((paramInt1 != 0) && (this.N != null)) {
      this.N.a(i1);
    }
    if ((paramInt1 != 0) && (this.O != null)) {
      this.O.a(i1);
    }
    h();
    scrollTo(i2, 0);
  }
  
  public boolean a(int paramInt)
  {
    View localView2 = findFocus();
    View localView1 = localView2;
    if (localView2 == this) {
      localView1 = null;
    }
    localView2 = FocusFinder.getInstance().findNextFocus(this, localView1, paramInt);
    boolean bool;
    if ((localView2 != null) && (localView2 != localView1)) {
      if (paramInt == 17) {
        if ((localView1 != null) && (localView2.getLeft() >= localView1.getLeft())) {
          bool = d();
        }
      }
    }
    for (;;)
    {
      if (bool) {
        playSoundEffect(SoundEffectConstants.getContantForFocusDirection(paramInt));
      }
      return bool;
      bool = localView2.requestFocus();
      continue;
      if (paramInt == 66)
      {
        if ((localView1 != null) && (localView2.getLeft() <= localView1.getLeft()))
        {
          bool = e();
          continue;
        }
        bool = localView2.requestFocus();
        continue;
        if ((paramInt == 17) || (paramInt == 1))
        {
          bool = d();
          continue;
        }
        if ((paramInt == 66) || (paramInt == 2))
        {
          bool = e();
          continue;
        }
      }
      bool = false;
    }
  }
  
  public boolean a(KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getAction() == 0) {
      switch (paramKeyEvent.getKeyCode())
      {
      }
    }
    do
    {
      return false;
      return a(17);
      return a(66);
      if (nf.a(paramKeyEvent)) {
        return a(2);
      }
    } while (!nf.a(paramKeyEvent, 1));
    return a(1);
  }
  
  protected boolean a(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3)
  {
    int i1;
    if ((paramView instanceof ViewGroup))
    {
      ViewGroup localViewGroup = (ViewGroup)paramView;
      int i2 = paramView.getScrollX();
      int i3 = paramView.getScrollY();
      i1 = localViewGroup.getChildCount() - 1;
      if (i1 >= 0)
      {
        localView = localViewGroup.getChildAt(i1);
        if ((paramInt2 + i2 < localView.getLeft()) || (paramInt2 + i2 >= localView.getRight()) || (paramInt3 + i3 < localView.getTop()) || (paramInt3 + i3 >= localView.getBottom()) || (!a(localView, true, paramInt1, paramInt2 + i2 - localView.getLeft(), paramInt3 + i3 - localView.getTop()))) {}
      }
    }
    while ((paramBoolean) && (pe.a(paramView, -paramInt1)))
    {
      View localView;
      return true;
      i1 -= 1;
      break;
    }
    return false;
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2)
  {
    int i2 = paramArrayList.size();
    int i3 = getDescendantFocusability();
    if (i3 != 393216)
    {
      int i1 = 0;
      while (i1 < getChildCount())
      {
        View localView = getChildAt(i1);
        if (localView.getVisibility() == 0)
        {
          bur localbur = a(localView);
          if ((localbur != null) && (localbur.b == this.f)) {
            localView.addFocusables(paramArrayList, paramInt1, paramInt2);
          }
        }
        i1 += 1;
      }
    }
    if (((i3 == 262144) && (i2 != paramArrayList.size())) || (!isFocusable())) {}
    while (((paramInt2 & 0x1) == 1) && (isInTouchMode()) && (!isFocusableInTouchMode())) {
      return;
    }
    paramArrayList.add(this);
  }
  
  public void addTouchables(ArrayList<View> paramArrayList)
  {
    int i1 = 0;
    while (i1 < getChildCount())
    {
      View localView = getChildAt(i1);
      if (localView.getVisibility() == 0)
      {
        bur localbur = a(localView);
        if ((localbur != null) && (localbur.b == this.f)) {
          localView.addTouchables(paramArrayList);
        }
      }
      i1 += 1;
    }
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    if (!checkLayoutParams(paramLayoutParams)) {
      paramLayoutParams = generateLayoutParams(paramLayoutParams);
    }
    for (;;)
    {
      bus localbus = (bus)paramLayoutParams;
      localbus.a |= paramView instanceof buq;
      if (this.r)
      {
        if (localbus.a) {
          throw new IllegalStateException("Cannot add pager decor view during layout");
        }
        addViewInLayout(paramView, paramInt, paramLayoutParams);
        paramView.measure(this.p, this.q);
        return;
      }
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    }
  }
  
  bur b(View paramView)
  {
    for (;;)
    {
      ViewParent localViewParent = paramView.getParent();
      if (localViewParent == this) {
        break;
      }
      if ((localViewParent == null) || (!(localViewParent instanceof View))) {
        return null;
      }
      paramView = (View)localViewParent;
    }
    return a(paramView);
  }
  
  public void b()
  {
    int i6 = 1;
    int i1;
    int i4;
    int i2;
    int i5;
    int i3;
    label46:
    bur localbur;
    if ((this.d.size() < 3) && (this.d.size() < this.e.a()))
    {
      i1 = 1;
      i4 = 0;
      i2 = 0;
      i5 = -1;
      i3 = i1;
      i1 = i5;
      if (i4 >= this.d.size()) {
        break label266;
      }
      localbur = (bur)this.d.get(i4);
      i5 = this.e.a(localbur.a);
      if (i5 != -1) {
        break label122;
      }
      i5 = i2;
      i2 = i1;
      i1 = i5;
    }
    for (;;)
    {
      i5 = i2;
      i4 += 1;
      i2 = i1;
      i1 = i5;
      break label46;
      i1 = 0;
      break;
      label122:
      if (i5 == -2)
      {
        this.d.remove(i4);
        i4 -= 1;
        i3 = i2;
        if (i2 == 0)
        {
          this.e.a(this);
          i3 = 1;
        }
        this.e.a(this, localbur.b, localbur.a);
        if (this.f == localbur.b)
        {
          i2 = Math.max(0, Math.min(this.f, this.e.a() - 1));
          i1 = i3;
          i3 = 1;
        }
      }
      else
      {
        if (localbur.b != i5)
        {
          if (localbur.b == this.f) {
            i1 = i5;
          }
          localbur.b = i5;
          i3 = i1;
          i5 = 1;
          i1 = i2;
          i2 = i3;
          i3 = i5;
          continue;
          label266:
          if (i2 != 0) {
            this.e.b(this);
          }
          Collections.sort(this.d, b);
          if (i1 >= 0) {
            a(i1, false, true);
          }
          for (i1 = i6;; i1 = i3)
          {
            if (i1 != 0)
            {
              c();
              requestLayout();
            }
            return;
          }
        }
        i5 = i1;
        i1 = i2;
        i2 = i5;
        continue;
      }
      i2 = i1;
      i5 = 1;
      i1 = i3;
      i3 = i5;
    }
  }
  
  void c()
  {
    bur localbur = null;
    int i6 = 0;
    if (this.e == null)
    {
      break label13;
      break label13;
    }
    label13:
    while ((this.t) || (getWindowToken() == null)) {
      return;
    }
    this.e.a(this);
    int i1 = this.v;
    int i5 = Math.max(0, this.f - i1);
    int i7 = Math.min(this.e.a() - 1, i1 + this.f);
    i1 = 0;
    int i2 = -1;
    label77:
    Object localObject1;
    if (i1 < this.d.size())
    {
      localObject1 = (bur)this.d.get(i1);
      if (((((bur)localObject1).b < i5) || (((bur)localObject1).b > i7)) && (!((bur)localObject1).c))
      {
        this.d.remove(i1);
        this.e.a(this, ((bur)localObject1).b, ((bur)localObject1).a);
        i1 -= 1;
      }
    }
    for (;;)
    {
      i2 = ((bur)localObject1).b;
      i1 += 1;
      break label77;
      int i4 = i1;
      if (i2 < i7)
      {
        i4 = i1;
        if (((bur)localObject1).b > i5)
        {
          i4 = i2 + 1;
          i2 = i1;
          int i3 = i4;
          if (i4 < i5)
          {
            i3 = i5;
            i2 = i1;
          }
          for (;;)
          {
            i4 = i2;
            if (i3 > i7) {
              break;
            }
            i4 = i2;
            if (i3 >= ((bur)localObject1).b) {
              break;
            }
            a(i3, i2);
            i3 += 1;
            i2 += 1;
          }
          if (this.d.size() > 0)
          {
            i1 = ((bur)this.d.get(this.d.size() - 1)).b;
            if (i1 >= i7) {
              break label334;
            }
            i1 += 1;
            if (i1 <= i5) {
              break label328;
            }
          }
          for (;;)
          {
            if (i1 > i7) {
              break label334;
            }
            a(i1, -1);
            i1 += 1;
            continue;
            i1 = -1;
            break;
            label328:
            i1 = i5;
          }
          label334:
          i1 = 0;
          label336:
          if (i1 < this.d.size()) {
            if (((bur)this.d.get(i1)).b != this.f) {}
          }
          for (localObject1 = (bur)this.d.get(i1);; localObject1 = null)
          {
            Object localObject2 = this.e;
            i1 = this.f;
            if (localObject1 != null) {}
            for (localObject1 = ((bur)localObject1).a;; localObject1 = null)
            {
              ((bui)localObject2).b(this, i1, localObject1);
              this.e.b(this);
              if (!hasFocus()) {
                break;
              }
              localObject2 = findFocus();
              localObject1 = localbur;
              if (localObject2 != null) {
                localObject1 = b((View)localObject2);
              }
              i1 = i6;
              if (localObject1 != null)
              {
                if (((bur)localObject1).b == this.f) {
                  break;
                }
                i1 = i6;
              }
              for (;;)
              {
                if (i1 >= getChildCount()) {
                  break label528;
                }
                localObject1 = getChildAt(i1);
                localbur = a((View)localObject1);
                if ((localbur != null) && (localbur.b == this.f) && (((View)localObject1).requestFocus(2))) {
                  break;
                }
                i1 += 1;
              }
              label528:
              break label13;
              i1 += 1;
              break label336;
            }
          }
        }
      }
      i1 = i4;
    }
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof bus)) && (super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll()
  {
    if ((!this.j.isFinished()) && (this.j.computeScrollOffset()))
    {
      int i1 = getScrollX();
      int i2 = getScrollY();
      int i3 = this.j.getCurrX();
      int i4 = this.j.getCurrY();
      if ((i1 != i3) || (i2 != i4))
      {
        scrollTo(i3, i4);
        b(i3);
      }
      invalidate();
      return;
    }
    h();
  }
  
  boolean d()
  {
    if (this.f > 0)
    {
      a(this.f - 1, true);
      return true;
    }
    return false;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    return (super.dispatchKeyEvent(paramKeyEvent)) || (a(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    boolean bool2 = false;
    int i2 = getChildCount();
    int i1 = 0;
    for (;;)
    {
      boolean bool1 = bool2;
      if (i1 < i2)
      {
        View localView = getChildAt(i1);
        if (localView.getVisibility() == 0)
        {
          bur localbur = a(localView);
          if ((localbur != null) && (localbur.b == this.f) && (localView.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))) {
            bool1 = true;
          }
        }
      }
      else
      {
        return bool1;
      }
      i1 += 1;
    }
  }
  
  public void draw(Canvas paramCanvas)
  {
    int i4 = 1;
    super.draw(paramCanvas);
    int i3 = 0;
    int i1 = 0;
    int i5 = pe.a(this);
    boolean bool;
    if ((i5 == 0) || ((i5 == 1) && (this.e != null) && (this.e.a() > 1)))
    {
      int i2;
      if (!this.I.a())
      {
        i3 = paramCanvas.save();
        i1 = getHeight() - getPaddingTop() - getPaddingBottom();
        paramCanvas.rotate(270.0F);
        paramCanvas.translate(-i1 + getPaddingTop(), 0.0F);
        this.I.a(i1, getWidth());
        i2 = false | this.I.a(paramCanvas);
        paramCanvas.restoreToCount(i3);
      }
      i3 = i2;
      if (!this.J.a())
      {
        i5 = paramCanvas.save();
        int i6 = getWidth();
        int i7 = getHeight();
        int i8 = getPaddingTop();
        int i9 = getPaddingBottom();
        i3 = i4;
        if (this.e != null) {
          i3 = this.e.a();
        }
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-getPaddingTop(), -i3 * (this.l + i6) + this.l);
        this.J.a(i7 - i8 - i9, i6);
        bool = i2 | this.J.a(paramCanvas);
        paramCanvas.restoreToCount(i5);
      }
    }
    for (;;)
    {
      if (bool) {
        invalidate();
      }
      return;
      this.I.b();
      this.J.b();
    }
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    Drawable localDrawable = this.m;
    if ((localDrawable != null) && (localDrawable.isStateful())) {
      localDrawable.setState(getDrawableState());
    }
  }
  
  boolean e()
  {
    if ((this.e != null) && (this.f < this.e.a() - 1))
    {
      a(this.f + 1, true);
      return true;
    }
    return false;
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    return new bus();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new bus(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return generateDefaultLayoutParams();
  }
  
  public bui getAdapter()
  {
    return this.e;
  }
  
  public int getCurrentItem()
  {
    return this.f;
  }
  
  public int getOffscreenPageLimit()
  {
    return this.v;
  }
  
  public int getPageMargin()
  {
    return this.l;
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.K = true;
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((this.l > 0) && (this.m != null))
    {
      int i1 = getScrollX();
      int i2 = getWidth();
      int i3 = i1 % (this.l + i2);
      if (i3 != 0)
      {
        i1 = i1 - i3 + i2;
        this.m.setBounds(i1, this.n, this.l + i1, this.o);
        this.m.draw(paramCanvas);
      }
    }
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i1;
    if (this.R)
    {
      i1 = paramMotionEvent.getAction() & 0xFF;
      if ((i1 != 3) && (i1 != 1)) {
        break label65;
      }
      this.w = false;
      this.x = false;
      this.C = -1;
      if (this.D != null)
      {
        this.D.recycle();
        this.D = null;
      }
    }
    label65:
    do
    {
      return false;
      if (i1 == 0) {
        break;
      }
      if (this.w) {
        return true;
      }
    } while (this.x);
    switch (i1)
    {
    }
    for (;;)
    {
      if (!this.w)
      {
        if (this.D == null) {
          this.D = VelocityTracker.obtain();
        }
        this.D.addMovement(paramMotionEvent);
      }
      return this.w;
      i1 = this.C;
      if (i1 != -1)
      {
        i1 = oj.a(paramMotionEvent, i1);
        float f1 = oj.c(paramMotionEvent, i1);
        float f2 = f1 - this.A;
        float f3 = Math.abs(f2);
        float f4 = oj.d(paramMotionEvent, i1);
        float f5 = Math.abs(f4 - this.B);
        if (a(this, false, (int)f2, (int)f1, (int)f4))
        {
          this.A = f1;
          this.z = f1;
          this.B = f4;
          return false;
        }
        if ((f3 > this.y) && (f3 > f5))
        {
          this.w = true;
          setScrollState(1);
          this.A = f1;
          setScrollingCacheEnabled(true);
        }
        else if (f5 > this.y)
        {
          this.x = true;
          continue;
          f1 = paramMotionEvent.getX();
          this.z = f1;
          this.A = f1;
          this.B = paramMotionEvent.getY();
          this.C = oj.b(paramMotionEvent, 0);
          if (this.Q == 2)
          {
            this.w = true;
            this.x = false;
            setScrollState(1);
          }
          else
          {
            h();
            this.w = false;
            this.x = false;
            continue;
            a(paramMotionEvent);
          }
        }
      }
    }
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.r = true;
    c();
    this.r = false;
    int i6 = getChildCount();
    int i7 = paramInt3 - paramInt1;
    int i8 = paramInt4 - paramInt2;
    paramInt2 = getPaddingLeft();
    paramInt1 = getPaddingTop();
    int i1 = getPaddingRight();
    paramInt3 = getPaddingBottom();
    int i9 = getScrollX();
    int i2 = 0;
    int i4 = 0;
    if (i4 < i6)
    {
      View localView = getChildAt(i4);
      Object localObject;
      int i10;
      int i3;
      label170:
      int i5;
      if (localView.getVisibility() != 8)
      {
        localObject = (bus)localView.getLayoutParams();
        if (((bus)localObject).a)
        {
          paramInt4 = ((bus)localObject).b;
          i10 = ((bus)localObject).b;
          switch (paramInt4 & 0x7)
          {
          case 2: 
          case 4: 
          default: 
            paramInt4 = paramInt2;
            i3 = paramInt2;
            switch (i10 & 0x70)
            {
            default: 
              i5 = paramInt1;
              paramInt2 = paramInt1;
              paramInt1 = paramInt3;
              paramInt3 = i5;
              label220:
              paramInt4 += i9;
              localView.layout(paramInt4, paramInt3, localView.getMeasuredWidth() + paramInt4, localView.getMeasuredHeight() + paramInt3);
              i2 += 1;
              paramInt4 = i1;
              paramInt3 = i3;
              i1 = paramInt1;
              paramInt1 = i2;
            }
            break;
          }
        }
      }
      for (;;)
      {
        i4 += 1;
        i3 = paramInt3;
        i2 = paramInt1;
        paramInt1 = paramInt2;
        paramInt3 = i1;
        i1 = paramInt4;
        paramInt2 = i3;
        break;
        i3 = localView.getMeasuredWidth();
        paramInt4 = paramInt2;
        i3 += paramInt2;
        break label170;
        paramInt4 = Math.max((i7 - localView.getMeasuredWidth()) / 2, paramInt2);
        i3 = paramInt2;
        break label170;
        i3 = localView.getMeasuredWidth();
        paramInt4 = i1 + localView.getMeasuredWidth();
        i5 = i7 - i1 - i3;
        i1 = paramInt4;
        i3 = paramInt2;
        paramInt4 = i5;
        break label170;
        i5 = localView.getMeasuredHeight();
        paramInt2 = paramInt3;
        i5 += paramInt1;
        paramInt3 = paramInt1;
        paramInt1 = paramInt2;
        paramInt2 = i5;
        break label220;
        i5 = Math.max((i8 - localView.getMeasuredHeight()) / 2, paramInt1);
        paramInt2 = paramInt1;
        paramInt1 = paramInt3;
        paramInt3 = i5;
        break label220;
        i5 = i8 - paramInt3 - localView.getMeasuredHeight();
        i10 = localView.getMeasuredHeight();
        paramInt2 = paramInt1;
        paramInt1 = paramInt3 + i10;
        paramInt3 = i5;
        break label220;
        localObject = a(localView);
        if (localObject != null)
        {
          paramInt4 = this.l;
          paramInt4 = ((bur)localObject).b * (paramInt4 + i7) + paramInt2;
          localView.layout(paramInt4, paramInt1, localView.getMeasuredWidth() + paramInt4, localView.getMeasuredHeight() + paramInt1);
        }
        paramInt4 = i2;
        i2 = paramInt1;
        i3 = paramInt2;
        paramInt1 = paramInt4;
        paramInt4 = i1;
        i1 = paramInt3;
        paramInt2 = i2;
        paramInt3 = i3;
      }
    }
    this.n = paramInt1;
    this.o = (i8 - paramInt3);
    this.M = i2;
    this.K = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(getDefaultSize(0, paramInt1), getDefaultSize(0, paramInt2));
    paramInt1 = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
    paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    int i7 = getChildCount();
    int i1 = 0;
    View localView;
    bus localbus;
    int i3;
    int i2;
    int i6;
    int i5;
    label198:
    label213:
    int i4;
    if (i1 < i7)
    {
      localView = getChildAt(i1);
      if (localView.getVisibility() == 8) {
        break label440;
      }
      localbus = (bus)localView.getLayoutParams();
      if ((localbus == null) || (!localbus.a)) {
        break label440;
      }
      i3 = localbus.b & 0x7;
      i2 = localbus.b & 0x70;
      Log.d("ViewPager", "gravity: " + localbus.b + " hgrav: " + i3 + " vgrav: " + i2);
      i6 = Integer.MIN_VALUE;
      i5 = Integer.MIN_VALUE;
      if ((i2 == 48) || (i2 == 80))
      {
        i2 = 1;
        if ((i3 != 3) && (i3 != 5)) {
          break label282;
        }
        i3 = 1;
        if (i2 == 0) {
          break label288;
        }
        i4 = 1073741824;
        label223:
        localView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, i4), View.MeasureSpec.makeMeasureSpec(paramInt2, i5));
        if (i2 == 0) {
          break label309;
        }
        i2 = paramInt2 - localView.getMeasuredHeight();
        paramInt2 = paramInt1;
        paramInt1 = i2;
      }
    }
    for (;;)
    {
      i2 = i1 + 1;
      i1 = paramInt2;
      paramInt2 = paramInt1;
      paramInt1 = i1;
      i1 = i2;
      break;
      i2 = 0;
      break label198;
      label282:
      i3 = 0;
      break label213;
      label288:
      i4 = i6;
      if (i3 == 0) {
        break label223;
      }
      i5 = 1073741824;
      i4 = i6;
      break label223;
      label309:
      if (i3 != 0)
      {
        i2 = paramInt1 - localView.getMeasuredWidth();
        paramInt1 = paramInt2;
        paramInt2 = i2;
        continue;
        this.p = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
        this.q = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
        this.r = true;
        c();
        this.r = false;
        paramInt2 = getChildCount();
        paramInt1 = 0;
        while (paramInt1 < paramInt2)
        {
          localView = getChildAt(paramInt1);
          if (localView.getVisibility() != 8)
          {
            localbus = (bus)localView.getLayoutParams();
            if ((localbus == null) || (!localbus.a)) {
              localView.measure(this.p, this.q);
            }
          }
          paramInt1 += 1;
        }
      }
      else
      {
        label440:
        i2 = paramInt1;
        paramInt1 = paramInt2;
        paramInt2 = i2;
      }
    }
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect)
  {
    int i3 = -1;
    int i2 = getChildCount();
    int i1;
    if ((paramInt & 0x2) != 0)
    {
      i3 = 1;
      i1 = 0;
    }
    while (i1 != i2)
    {
      View localView = getChildAt(i1);
      if (localView.getVisibility() == 0)
      {
        bur localbur = a(localView);
        if ((localbur != null) && (localbur.b == this.f) && (localView.requestFocus(paramInt, paramRect)))
        {
          return true;
          i1 = i2 - 1;
          i2 = -1;
          continue;
        }
      }
      i1 += i3;
    }
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof TutorialViewPagerBottom.SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (TutorialViewPagerBottom.SavedState)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    if (this.e != null)
    {
      this.e.a(paramParcelable.b, paramParcelable.c);
      a(paramParcelable.a, false, true);
      return;
    }
    this.g = paramParcelable.a;
    this.h = paramParcelable.b;
    this.i = paramParcelable.c;
  }
  
  public Parcelable onSaveInstanceState()
  {
    TutorialViewPagerBottom.SavedState localSavedState = new TutorialViewPagerBottom.SavedState(super.onSaveInstanceState());
    localSavedState.a = this.f;
    if (this.e != null) {
      localSavedState.b = this.e.b();
    }
    return localSavedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3) {
      a(paramInt1, paramInt3, this.l, this.l);
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    if (this.H) {
      bool1 = true;
    }
    do
    {
      do
      {
        do
        {
          return bool1;
          if (paramMotionEvent.getAction() != 0) {
            break;
          }
          bool1 = bool5;
        } while (paramMotionEvent.getEdgeFlags() != 0);
        bool1 = bool5;
      } while (this.e == null);
      bool1 = bool5;
    } while (this.e.a() == 0);
    if (this.D == null) {
      this.D = VelocityTracker.obtain();
    }
    this.D.addMovement(paramMotionEvent);
    int i1 = paramMotionEvent.getAction();
    if ((getCurrentItem() == 2) && (this.R)) {}
    boolean bool1 = bool2;
    float f1;
    float f2;
    float f3;
    int i2;
    int i3;
    switch (i1 & 0xFF)
    {
    default: 
      bool1 = bool2;
    case 4: 
    case 0: 
    case 2: 
      do
      {
        for (;;)
        {
          if (bool1) {
            invalidate();
          }
          return true;
          h();
          f1 = paramMotionEvent.getX();
          this.z = f1;
          this.A = f1;
          this.C = oj.b(paramMotionEvent, 0);
          bool1 = bool2;
        }
        if (!this.w)
        {
          f1 = paramMotionEvent.getX();
          f2 = Math.abs(f1 - this.A);
          f3 = Math.abs(paramMotionEvent.getY() - this.B);
          if ((f2 > this.y) && (f2 > f3))
          {
            this.w = true;
            this.A = f1;
            setScrollState(1);
            setScrollingCacheEnabled(true);
          }
        }
        bool1 = bool2;
      } while (!this.w);
      f1 = paramMotionEvent.getX();
      f2 = this.A;
      this.A = f1;
      f2 = getScrollX() + (f2 - f1);
      i1 = getWidth();
      i2 = i1 + this.l;
      i3 = this.e.a() - 1;
      f1 = Math.max(0, (this.f - 1) * i2);
      f3 = Math.min(this.f + 1, i3) * i2;
      if (f2 < f1)
      {
        bool1 = bool3;
        if (f1 == 0.0F)
        {
          f2 = -f2;
          bool1 = this.I.a(f2 / i1);
        }
      }
      break;
    }
    for (;;)
    {
      this.A += f1 - (int)f1;
      scrollTo((int)f1, getScrollY());
      b((int)f1);
      break;
      if (f2 > f3)
      {
        bool1 = bool4;
        if (f3 == i3 * i2) {
          bool1 = this.J.a((f2 - f3) / i1);
        }
        f1 = f3;
        continue;
        bool1 = bool2;
        if (!this.w) {
          break;
        }
        VelocityTracker localVelocityTracker = this.D;
        localVelocityTracker.computeCurrentVelocity(1000, this.F);
        i1 = (int)oz.a(localVelocityTracker, this.C);
        this.t = true;
        i2 = getWidth() + this.l;
        i3 = getScrollX();
        a(a(i3 / i2, i3 % i2 / i2, i1, (int)(paramMotionEvent.getX() - this.z)), true, true, i1);
        this.C = -1;
        i();
        bool1 = this.I.c() | this.J.c();
        break;
        bool1 = bool2;
        if (!this.w) {
          break;
        }
        a(this.f, true, true);
        this.C = -1;
        i();
        bool1 = this.I.c() | this.J.c();
        break;
        i1 = oj.b(paramMotionEvent);
        this.A = oj.c(paramMotionEvent, i1);
        this.C = oj.b(paramMotionEvent, i1);
        bool1 = bool2;
        break;
        a(paramMotionEvent);
        this.A = oj.c(paramMotionEvent, oj.a(paramMotionEvent, this.C));
        bool1 = bool2;
        break;
      }
      bool1 = false;
      f1 = f2;
    }
  }
  
  public void setAdapter(bui parambui)
  {
    if (this.e != null)
    {
      this.e.b(this.k);
      this.e.a(this);
      int i1 = 0;
      while (i1 < this.d.size())
      {
        localObject = (bur)this.d.get(i1);
        this.e.a(this, ((bur)localObject).b, ((bur)localObject).a);
        i1 += 1;
      }
      this.e.b(this);
      this.d.clear();
      g();
      this.f = 0;
      scrollTo(0, 0);
    }
    Object localObject = this.e;
    this.e = parambui;
    if (this.e != null)
    {
      if (this.k == null) {
        this.k = new buv(this, null);
      }
      this.e.a(this.k);
      this.t = false;
      if (this.g < 0) {
        break label228;
      }
      this.e.a(this.h, this.i);
      a(this.g, false, true);
      this.g = -1;
      this.h = null;
      this.i = null;
    }
    for (;;)
    {
      if ((this.P != null) && (localObject != parambui)) {
        this.P.a((bui)localObject, parambui);
      }
      return;
      label228:
      c();
    }
  }
  
  public void setCurrentItem(int paramInt)
  {
    this.t = false;
    if (!this.K) {}
    for (boolean bool = true;; bool = false)
    {
      a(paramInt, bool, false);
      return;
    }
  }
  
  public void setOffscreenPageLimit(int paramInt)
  {
    int i1 = paramInt;
    if (paramInt < 1)
    {
      Log.w("ViewPager", "Requested offscreen page limit " + paramInt + " too small; defaulting to " + 1);
      i1 = 1;
    }
    if (i1 != this.v)
    {
      this.v = i1;
      c();
    }
  }
  
  void setOnAdapterChangeListener(but parambut)
  {
    this.P = parambut;
  }
  
  public void setOnPageChangeListener(buu parambuu)
  {
    this.N = parambuu;
  }
  
  public void setPageMargin(int paramInt)
  {
    int i1 = this.l;
    this.l = paramInt;
    int i2 = getWidth();
    a(i2, i2, paramInt, i1);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt)
  {
    setPageMarginDrawable(getContext().getResources().getDrawable(paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable)
  {
    this.m = paramDrawable;
    if (paramDrawable != null) {
      refreshDrawableState();
    }
    if (paramDrawable == null) {}
    for (boolean bool = true;; bool = false)
    {
      setWillNotDraw(bool);
      invalidate();
      return;
    }
  }
  
  public void setPagingEnabled(boolean paramBoolean)
  {
    this.R = paramBoolean;
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable)
  {
    return (super.verifyDrawable(paramDrawable)) || (paramDrawable == this.m);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/tutorial/TutorialViewPagerBottom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */