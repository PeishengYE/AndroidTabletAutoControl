package com.teamviewer.remotecontrollib.gui.view;

import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import o.bvj;
import o.bvk;
import o.bvl;
import o.bvn;
import o.bvo;
import o.bvp;
import o.bvq;
import o.oj;

public class M2MControlView
  extends View
  implements View.OnLayoutChangeListener
{
  private float a;
  private int b;
  private final int c;
  private final int d;
  private int e;
  private final Rect f = new Rect();
  private final int g;
  private final int h;
  private int i;
  private int j;
  private float k;
  private boolean l = false;
  private boolean m = false;
  private final Paint n;
  private final Paint o;
  private final Paint p;
  private final RectF q = new RectF();
  private final Path r = new Path();
  private final PointF s = new PointF();
  private final int t;
  private boolean u;
  private float v = 1.0F;
  private bvq w = bvq.b;
  private GestureDetector x = null;
  private bvp y;
  
  public M2MControlView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    c();
    float f1 = getResources().getDisplayMetrics().density;
    this.c = ((int)(75.0F * f1));
    this.d = ((int)(35.0F * f1));
    if (this.w == bvq.a) {
      bool = true;
    }
    this.u = bool;
    if (bool) {}
    for (int i1 = this.c;; i1 = this.d)
    {
      this.e = i1;
      a();
      this.t = ((int)(20.0F * f1));
      this.g = this.t;
      this.h = this.t;
      b();
      i1 = this.g + this.c - this.d;
      int i2 = this.h + this.c - this.d;
      int i3 = this.d;
      int i4 = this.d;
      this.f.set(i1, i2, i3 * 2 + i1, i4 * 2 + i2);
      this.a = getResources().getDisplayMetrics().density;
      this.n = new Paint();
      this.n.setColor(-1);
      this.n.setAntiAlias(true);
      this.n.setStyle(Paint.Style.STROKE);
      this.n.setStrokeWidth(this.a);
      this.o = new Paint();
      this.o.setColor(-16777216);
      this.o.setAntiAlias(true);
      this.o.setStyle(Paint.Style.FILL);
      this.p = new Paint();
      this.p.setAntiAlias(true);
      this.x = new GestureDetector(getContext(), new bvo(this));
      return;
    }
  }
  
  private int a(float paramFloat)
  {
    int i1 = this.b;
    int i2;
    int i4;
    int i3;
    if (this.w == bvq.b)
    {
      i2 = this.d;
      i1 -= this.d;
      i4 = Math.round(this.v * (i1 - i2) + i2 + paramFloat);
      if (i4 <= i1) {
        break label87;
      }
      i3 = i1;
    }
    for (;;)
    {
      this.v = ((i3 - i2) / (i1 - i2));
      return i3;
      i2 = this.c;
      i1 -= this.c;
      break;
      label87:
      i3 = i4;
      if (i4 < i2) {
        i3 = i2;
      }
    }
  }
  
  private bvn a(int paramInt1, int paramInt2)
  {
    int i3 = this.t;
    int i4 = this.c;
    int i1 = this.t;
    int i2 = this.c;
    paramInt1 -= i3 + i4;
    paramInt2 -= i1 + i2;
    float f1 = (float)Math.sqrt(paramInt1 * paramInt1 + paramInt2 * paramInt2);
    if (this.w == bvq.b)
    {
      if (f1 > this.d) {
        return bvn.e;
      }
      return bvn.a;
    }
    if (f1 < this.d) {
      return bvn.a;
    }
    if ((f1 >= this.d) && (f1 < this.c))
    {
      float f2 = (float)Math.toDegrees(Math.atan(paramInt2 / paramInt1));
      f1 = f2;
      if (f2 > 0.0F) {
        f1 = f2 - 180.0F;
      }
      if ((f1 <= bvn.b.b()) && (f1 > bvn.b.c())) {
        return bvn.b;
      }
      if ((f1 <= bvn.c.b()) && (f1 > bvn.c.c())) {
        return bvn.c;
      }
      if ((f1 <= bvn.d.b()) && (f1 > bvn.d.c())) {
        return bvn.d;
      }
      return bvn.e;
    }
    return bvn.e;
  }
  
  private void a()
  {
    if (this.w == bvq.a) {}
    for (boolean bool = true;; bool = false)
    {
      bvn.a.a(bool);
      return;
    }
  }
  
  private void a(Canvas paramCanvas, bvn parambvn)
  {
    if (parambvn == bvn.a)
    {
      this.q.set(this.f);
      this.o.setAlpha(255);
      paramCanvas.drawArc(this.q, 0.0F, -180.0F, true, this.o);
      this.r.reset();
      this.r.addArc(this.q, 0.0F, -180.0F);
      paramCanvas.drawPath(this.r, this.n);
    }
    if (parambvn == bvn.a) {
      this.s.set(this.i + this.e, this.j + this.e - (this.d - this.a) / 2.0F);
    }
    for (;;)
    {
      parambvn = parambvn.a();
      if (parambvn != null)
      {
        float f1 = parambvn.getWidth();
        float f2 = parambvn.getHeight();
        paramCanvas.drawBitmap(parambvn, this.s.x - f1 / 2.0F, this.s.y - f2 / 2.0F, this.p);
      }
      return;
      double d3 = Math.toRadians(bvn.a(parambvn) + bvn.b(parambvn)) / 2.0D;
      double d1 = this.e - this.a - (this.c - this.a - this.d) / 2.0F;
      double d2 = Math.cos(d3);
      d3 = Math.sin(d3);
      this.s.set((float)(d2 * d1) + this.i + this.e, (float)(d3 * d1) + this.j + this.e);
    }
  }
  
  private boolean a(bvn parambvn)
  {
    if ((parambvn == bvn.e) || ((this.w == bvq.b) && (parambvn != bvn.a))) {
      return false;
    }
    if (this.y != null) {
      switch (o.bvm.a[parambvn.ordinal()])
      {
      }
    }
    for (;;)
    {
      e();
      return true;
      this.y.y();
      continue;
      this.y.z();
      continue;
      this.y.A();
      continue;
      this.y.B();
    }
  }
  
  private void b()
  {
    this.i = (this.g + (this.c - this.e));
    this.j = (this.h + (this.c - this.e));
  }
  
  private void c()
  {
    bvn.b.a(getResources());
    bvn.d.a(getResources());
    bvn.c.a(getResources());
    bvn.a.a(getResources());
  }
  
  private void d()
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)getLayoutParams();
    int i1 = a(0.0F);
    localMarginLayoutParams.rightMargin = (this.b - (i1 + this.c + this.t));
    setLayoutParams(localMarginLayoutParams);
  }
  
  private void e()
  {
    AnimatorSet localAnimatorSet = new AnimatorSet();
    ValueAnimator localValueAnimator1 = g();
    ValueAnimator localValueAnimator2 = h();
    if (localValueAnimator2 != null) {
      localAnimatorSet.play(localValueAnimator2).with(localValueAnimator1);
    }
    for (;;)
    {
      localAnimatorSet.start();
      f();
      a();
      return;
      localAnimatorSet.play(localValueAnimator1);
    }
  }
  
  private void f()
  {
    if (this.w == bvq.b)
    {
      this.w = bvq.a;
      return;
    }
    this.w = bvq.b;
  }
  
  private ValueAnimator g()
  {
    if (this.w == bvq.a) {}
    for (ValueAnimator localValueAnimator = ValueAnimator.ofFloat(new float[] { this.c, this.d });; localValueAnimator = ValueAnimator.ofFloat(new float[] { this.d, this.c }))
    {
      localValueAnimator.setDuration(500L);
      localValueAnimator.setInterpolator(new OvershootInterpolator());
      localValueAnimator.addUpdateListener(new bvj(this));
      localValueAnimator.addListener(new bvk(this));
      return localValueAnimator;
    }
  }
  
  private ValueAnimator h()
  {
    if (this.w != bvq.b) {
      return null;
    }
    int i1 = this.b;
    int i2 = this.c;
    int i4 = this.d;
    int i3 = i1 - this.c;
    int i5 = this.d;
    float f1 = this.v;
    float f2 = i1 - i5 - i4;
    i4 = Math.round(i4 + f2 * f1);
    if (i4 > i3) {}
    for (ValueAnimator localValueAnimator = ValueAnimator.ofFloat(new float[] { i4, i3 });; localValueAnimator = ValueAnimator.ofFloat(new float[] { i4, i2 }))
    {
      localValueAnimator.setDuration(500L);
      localValueAnimator.setInterpolator(new DecelerateInterpolator());
      localValueAnimator.addUpdateListener(new bvl(this, i1, i2, i3));
      return localValueAnimator;
      if (i4 >= i2) {
        break;
      }
    }
  }
  
  private void i()
  {
    int i1 = this.b;
    int i4;
    int i3;
    int i2;
    if (this.w == bvq.b)
    {
      i4 = this.c;
      i3 = this.d;
      i2 = i1 - this.c;
      i1 -= this.d;
    }
    for (;;)
    {
      float f1 = this.v;
      this.v = ((Math.round((i1 - i3) * f1 + i3) - i4) / (i2 - i4));
      return;
      i4 = this.d;
      i3 = this.c;
      i2 = i1 - this.d;
      i1 -= this.c;
    }
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    ViewGroup localViewGroup = (ViewGroup)getParent();
    if (localViewGroup != null) {
      localViewGroup.addOnLayoutChangeListener(this);
    }
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    c();
    this.a = getResources().getDisplayMetrics().density;
    this.n.setStrokeWidth(this.a);
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    ViewGroup localViewGroup = (ViewGroup)getParent();
    if (localViewGroup != null) {
      localViewGroup.removeOnLayoutChangeListener(this);
    }
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    if (this.u)
    {
      this.q.set(this.i, this.j, this.i + this.e * 2, this.j + this.e * 2);
      this.o.setAlpha(191);
      paramCanvas.drawArc(this.q, 0.0F, -180.0F, true, this.o);
      this.r.reset();
      this.r.addArc(this.q, 0.0F, -180.0F);
      paramCanvas.drawPath(this.r, this.n);
      a(paramCanvas, bvn.b);
      a(paramCanvas, bvn.c);
      a(paramCanvas, bvn.d);
    }
    a(paramCanvas, bvn.a);
  }
  
  public void onLayoutChange(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if ((paramInt1 != paramInt5) || (paramInt2 != paramInt6) || (paramInt3 != paramInt7) || (paramInt4 != paramInt8))
    {
      this.b = (paramInt3 - paramInt1);
      d();
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension((this.c + this.t) * 2, this.c + this.t);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool = false;
    if (this.x.onTouchEvent(paramMotionEvent)) {
      performClick();
    }
    int i1 = oj.a(paramMotionEvent);
    Object localObject = a((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    switch (i1)
    {
    }
    for (;;)
    {
      bool = true;
      do
      {
        do
        {
          return bool;
        } while ((this.w == bvq.b) && (localObject != bvn.a));
        this.l = true;
        this.k = paramMotionEvent.getRawX();
        break;
      } while (((!this.l) || (!this.m)) && (this.w == bvq.b) && (localObject != bvn.a));
      this.m = true;
      i1 = a(paramMotionEvent.getRawX() - this.k);
      localObject = (ViewGroup.MarginLayoutParams)getLayoutParams();
      ((ViewGroup.MarginLayoutParams)localObject).rightMargin = (this.b - (i1 + this.c + this.t));
      setLayoutParams((ViewGroup.LayoutParams)localObject);
      invalidate();
      this.k = paramMotionEvent.getRawX();
      continue;
      this.l = false;
      this.m = true;
      continue;
      this.k = paramMotionEvent.getRawX();
    }
  }
  
  public void setMiddleButtonEnabled(boolean paramBoolean)
  {
    bvn.c.a(paramBoolean);
  }
  
  public void setTouchInterceptor(bvp parambvp)
  {
    this.y = parambvp;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/view/M2MControlView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */