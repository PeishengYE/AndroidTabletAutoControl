package com.teamviewer.remotecontrollib.gui.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import o.bvr;
import o.bvs;
import o.bvt;
import o.bvu;
import o.bvv;
import o.bvw;
import o.oj;

public class M2MZoomView
  extends ImageView
  implements View.OnLayoutChangeListener
{
  private int a;
  private float b = 0.0F;
  private float c = 0.25F;
  private bvw d = bvw.a;
  private bvv e;
  private GestureDetector f = null;
  private final Runnable g = new bvs(this);
  private final Runnable h = new bvt(this);
  
  public M2MZoomView(Context paramContext)
  {
    super(paramContext);
    e();
  }
  
  public M2MZoomView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    e();
  }
  
  public M2MZoomView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    e();
  }
  
  private void e()
  {
    this.f = new GestureDetector(getContext(), new bvu(this));
  }
  
  private void f()
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)getLayoutParams();
    int j = (int)(this.c * (this.a - getHeight()));
    int i;
    if (j < 0) {
      i = 0;
    }
    for (;;)
    {
      localMarginLayoutParams.setMargins(localMarginLayoutParams.leftMargin, i, localMarginLayoutParams.rightMargin, localMarginLayoutParams.bottomMargin);
      setLayoutParams(localMarginLayoutParams);
      return;
      i = j;
      if (getHeight() + j > this.a) {
        i = this.a - getHeight();
      }
    }
  }
  
  public void a()
  {
    if (this.c != 0.25F)
    {
      this.c = 0.25F;
      int i = (int)(this.c * (this.a - getHeight()));
      ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)getLayoutParams();
      ValueAnimator localValueAnimator = ValueAnimator.ofFloat(new float[] { localMarginLayoutParams.topMargin, i });
      localValueAnimator.setDuration(350L);
      localValueAnimator.setInterpolator(new DecelerateInterpolator());
      localValueAnimator.addUpdateListener(new bvr(this, localMarginLayoutParams));
      localValueAnimator.start();
    }
  }
  
  public void b()
  {
    postDelayed(this.h, 10000L);
  }
  
  public void c()
  {
    removeCallbacks(this.h);
  }
  
  public void d()
  {
    setAlpha(1.0F);
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    ViewGroup localViewGroup = (ViewGroup)getParent();
    if (localViewGroup != null) {
      localViewGroup.addOnLayoutChangeListener(this);
    }
    d();
    b();
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    ViewGroup localViewGroup = (ViewGroup)getParent();
    if (localViewGroup != null) {
      localViewGroup.removeOnLayoutChangeListener(this);
    }
    c();
  }
  
  public void onLayoutChange(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if ((paramInt1 != paramInt5) || (paramInt2 != paramInt6) || (paramInt3 != paramInt7) || (paramInt4 != paramInt8))
    {
      this.a = (paramInt4 - paramInt2);
      post(this.g);
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    c();
    d();
    b();
    if (this.f.onTouchEvent(paramMotionEvent))
    {
      performClick();
      return true;
    }
    switch (oj.a(paramMotionEvent))
    {
    default: 
      return false;
    case 0: 
      this.b = paramMotionEvent.getRawY();
      return true;
    case 2: 
      float f1 = paramMotionEvent.getRawY();
      float f2 = this.b;
      this.b = f1;
      this.c = (Math.round(((ViewGroup.MarginLayoutParams)getLayoutParams()).topMargin + (f1 - f2)) / (this.a - getHeight()));
      f();
      return true;
    }
    this.b = paramMotionEvent.getRawY();
    return true;
  }
  
  public boolean performClick()
  {
    if (this.d == bvw.b) {
      setZoomState(bvw.a);
    }
    for (;;)
    {
      if (this.e != null) {
        this.e.x();
      }
      return true;
      setZoomState(bvw.b);
    }
  }
  
  public void setTouchInterceptor(bvv parambvv)
  {
    this.e = parambvv;
  }
  
  public void setZoomState(bvw parambvw)
  {
    this.d = parambvw;
    if (parambvw == bvw.b)
    {
      setActivated(true);
      return;
    }
    setActivated(false);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/view/M2MZoomView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */