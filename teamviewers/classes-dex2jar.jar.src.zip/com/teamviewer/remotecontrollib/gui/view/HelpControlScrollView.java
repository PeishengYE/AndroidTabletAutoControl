package com.teamviewer.remotecontrollib.gui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.widget.ScrollView;
import o.bdl;
import o.bot;
import o.bvg;
import o.bvh;

public class HelpControlScrollView
  extends ScrollView
{
  private final ViewTreeObserver.OnPreDrawListener a = new bvg(this);
  
  public HelpControlScrollView(Context paramContext)
  {
    super(paramContext);
  }
  
  public HelpControlScrollView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public HelpControlScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  private float a(View paramView1, View paramView2)
  {
    int i = paramView2.getWidth();
    int j = paramView2.getHeight();
    float f1 = i / paramView1.getWidth();
    float f2 = j / paramView1.getHeight();
    if ((f1 > 1.0F) && (f2 > 1.0F)) {
      return 1.0F;
    }
    return Math.min(f1, f2);
  }
  
  private void a(View paramView)
  {
    if (paramView == null) {
      return;
    }
    paramView.setOnTouchListener(new bvh(this));
  }
  
  private void b(View paramView1, View paramView2)
  {
    if ((paramView1 == null) || (paramView2 == null)) {
      return;
    }
    float f = a(paramView1, paramView2);
    paramView1.setPivotX(0.5F * paramView1.getWidth() * f);
    paramView1.setPivotY(0.0F);
    paramView1.setScaleX(f);
    paramView1.setScaleY(f);
    a(paramView2);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    if (bot.a())
    {
      View localView = findViewById(bdl.help_zoom_container);
      if (localView != null) {
        localView.getViewTreeObserver().addOnPreDrawListener(this.a);
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/view/HelpControlScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */