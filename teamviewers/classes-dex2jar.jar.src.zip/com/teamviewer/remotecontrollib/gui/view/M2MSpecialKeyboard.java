package com.teamviewer.remotecontrollib.gui.view;

import android.content.Context;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.util.AttributeSet;
import o.axx;
import o.bdr;
import o.cek;

public class M2MSpecialKeyboard
  extends KeyboardView
{
  private axx a;
  
  public M2MSpecialKeyboard(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setPreviewEnabled(false);
    setKeyboard(new Keyboard(paramContext, bdr.m2m_keyboard));
  }
  
  public void setKeyboardListeners(cek paramcek)
  {
    this.a = new axx();
    this.a.a(paramcek);
    setOnKeyboardActionListener(this.a);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/view/M2MSpecialKeyboard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */