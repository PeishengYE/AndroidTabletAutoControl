package com.teamviewer.remotecontrollib.gui.view;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import o.bdi;
import o.bdj;
import o.bdk;
import o.bdl;
import o.bdq;
import o.bvi;
import o.il;

public class InstructionsOverlayView
  extends RelativeLayout
  implements View.OnLayoutChangeListener
{
  private final PointF a = new PointF();
  private int b;
  private Paint c;
  private float d = 0.0F;
  private Bitmap e;
  private Canvas f;
  private View g = null;
  private int h = 0;
  private TextView i;
  
  public InstructionsOverlayView(Context paramContext)
  {
    this(paramContext, null, 0);
  }
  
  public InstructionsOverlayView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public InstructionsOverlayView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramContext, paramAttributeSet);
  }
  
  private void a()
  {
    int k;
    int j;
    if (this.g != null)
    {
      k = this.g.getTop();
      j = this.g.getWidth();
      if (getResources().getConfiguration().orientation != 2) {
        break label142;
      }
      this.i.setCompoundDrawablesWithIntrinsicBounds(0, 0, bdk.m2m_instructions_right_arrow, 0);
      int i1 = (this.g.getHeight() - this.i.getHeight()) / 2;
      int m = getResources().getDimensionPixelSize(bdj.m2m_instructions_arrow_hole_margin);
      int n = this.g.getWidth() / 2;
      k += i1;
      j += m + n;
    }
    for (;;)
    {
      RelativeLayout.LayoutParams localLayoutParams = (RelativeLayout.LayoutParams)this.i.getLayoutParams();
      localLayoutParams.setMargins(localLayoutParams.leftMargin, k, j, localLayoutParams.bottomMargin);
      this.i.setLayoutParams(localLayoutParams);
      return;
      label142:
      this.i.setCompoundDrawablesWithIntrinsicBounds(0, 0, bdk.m2m_instructions_up_arrow, 0);
      k += (int)(this.g.getHeight() * 1.5F);
    }
  }
  
  private void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    if (paramAttributeSet != null)
    {
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, bdq.InstructionsOverlayView);
      this.h = paramContext.getResourceId(bdq.InstructionsOverlayView_instruction_target_view, 0);
      paramContext.recycle();
    }
    setWillNotDraw(false);
    this.b = il.b(getContext(), bdi.m2m_instructions_background);
    this.c = new Paint();
    this.c.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
  }
  
  private void b()
  {
    if (this.g != null)
    {
      int j = this.g.getLeft();
      int k = this.g.getTop();
      int m = this.g.getWidth();
      int n = this.g.getHeight();
      this.a.set(j + m / 2.0F, k + n / 2.0F);
    }
  }
  
  private void c()
  {
    if (this.g != null) {
      this.d = Math.max(this.g.getWidth(), this.g.getHeight());
    }
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.i = ((TextView)findViewById(bdl.instructions_text));
    ViewParent localViewParent = getParent();
    if (((localViewParent instanceof ViewGroup)) && (this.h != 0))
    {
      this.g = ((ViewGroup)localViewParent).findViewById(this.h);
      this.g.addOnLayoutChangeListener(this);
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.g != null) {
      this.g.removeOnLayoutChangeListener(this);
    }
    if (this.f != null)
    {
      this.f.setBitmap(null);
      this.f = null;
    }
    if (this.e != null)
    {
      this.e.recycle();
      this.e = null;
    }
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    this.e.eraseColor(0);
    this.f.drawColor(this.b);
    this.f.drawCircle(this.a.x, this.a.y, this.d, this.c);
    paramCanvas.drawBitmap(this.e, 0.0F, 0.0F, null);
  }
  
  public void onLayoutChange(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if ((paramInt1 != paramInt5) || (paramInt2 != paramInt6) || (paramInt3 != paramInt7) || (paramInt4 != paramInt8)) {
      post(new bvi(this));
    }
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.e != null) {
      this.e.recycle();
    }
    this.e = Bitmap.createBitmap(paramInt1, paramInt2, Bitmap.Config.ARGB_8888);
    this.f = new Canvas(this.e);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/gui/view/InstructionsOverlayView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */