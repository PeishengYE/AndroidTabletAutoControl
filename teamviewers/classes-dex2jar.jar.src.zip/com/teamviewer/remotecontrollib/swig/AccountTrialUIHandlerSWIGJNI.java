package com.teamviewer.remotecontrollib.swig;

import com.teamviewer.commonviewmodel.swig.ISimpleResultCallback;
import o.bxw;

public class AccountTrialUIHandlerSWIGJNI
{
  public static final native void AccountTrialUIHandler_AccountTrialRequest(long paramLong1, bxw parambxw, long paramLong2, ISimpleResultCallback paramISimpleResultCallback);
  
  public static final native void delete_AccountTrialUIHandler(long paramLong);
  
  public static final native long new_AccountTrialUIHandler();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/remotecontrollib/swig/AccountTrialUIHandlerSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */