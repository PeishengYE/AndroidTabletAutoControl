package com.teamviewer.filetransferlib.filetransfer;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.io.File;
import java.net.URLConnection;
import o.bbf;

public class TVFile
  implements Parcelable
{
  public static final Parcelable.Creator<TVFile> CREATOR = new bbf();
  private String a = "";
  private TVFile.FileType b;
  private String c = "";
  private TVFile.Source d = TVFile.Source.c;
  private String e = "";
  private long f = 0L;
  private long g = 0L;
  private boolean h = false;
  private int i = 0;
  
  private TVFile(Parcel paramParcel)
  {
    this.a = paramParcel.readString();
    this.c = paramParcel.readString();
    this.e = paramParcel.readString();
    this.f = paramParcel.readLong();
    this.g = paramParcel.readLong();
    this.b = ((TVFile.FileType)paramParcel.readParcelable(getClass().getClassLoader()));
    this.d = ((TVFile.Source)paramParcel.readParcelable(getClass().getClassLoader()));
  }
  
  public TVFile(File paramFile)
  {
    this(paramFile.getName(), paramFile.getAbsolutePath());
  }
  
  public TVFile(String paramString1, String paramString2)
  {
    this(paramString1, paramString2, TVFile.FileType.b, TVFile.Source.a, 0);
  }
  
  public TVFile(String paramString1, String paramString2, TVFile.FileType paramFileType)
  {
    this(paramString1, paramString2, paramFileType, TVFile.Source.a, 0);
  }
  
  public TVFile(String paramString1, String paramString2, TVFile.FileType paramFileType, TVFile.Source paramSource, int paramInt)
  {
    this.a = paramString1;
    this.c = paramString2;
    this.b = paramFileType;
    this.d = paramSource;
    try
    {
      this.e = URLConnection.guessContentTypeFromName(this.a);
      this.h = false;
      this.i = paramInt;
      paramString1 = new File(paramString2);
      if (paramString1.isDirectory()) {
        this.b = TVFile.FileType.a;
      }
      this.g = paramString1.lastModified();
      this.f = paramString1.length();
      return;
    }
    catch (StringIndexOutOfBoundsException paramString1)
    {
      for (;;)
      {
        this.e = "application/unknown";
      }
    }
  }
  
  public String a()
  {
    return this.a;
  }
  
  public void a(TVFile.FileType paramFileType)
  {
    this.b = paramFileType;
  }
  
  public void a(TVFile.Source paramSource)
  {
    this.d = paramSource;
  }
  
  public void a(String paramString)
  {
    this.a = paramString;
  }
  
  public void a(boolean paramBoolean)
  {
    this.h = paramBoolean;
  }
  
  public TVFile.FileType b()
  {
    return this.b;
  }
  
  public String c()
  {
    return this.c;
  }
  
  public String d()
  {
    return this.e;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean e()
  {
    return this.h;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    do
    {
      return true;
      if (!(paramObject instanceof TVFile)) {
        return false;
      }
      paramObject = (TVFile)paramObject;
    } while ((((TVFile)paramObject).a.equals(this.a)) && (((TVFile)paramObject).c.equals(this.c)) && (((TVFile)paramObject).b.equals(this.b)) && (((TVFile)paramObject).d.equals(this.d)));
    return false;
  }
  
  public boolean f()
  {
    return (this.i & 0x2) == 2;
  }
  
  public long g()
  {
    return (this.g + 11644473600000L) * 10000L;
  }
  
  public int hashCode()
  {
    int k = 0;
    int j;
    if (this.a == null)
    {
      j = 0;
      if (this.c != null) {
        break label61;
      }
    }
    for (;;)
    {
      return (((j + 31) * 31 + k) * 31 + this.b.hashCode()) * 31 + this.d.hashCode();
      j = this.a.hashCode();
      break;
      label61:
      k = this.c.hashCode();
    }
  }
  
  public String toString()
  {
    return "Name: " + this.a + " - " + this.b + " - " + this.i;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.a);
    paramParcel.writeString(this.c);
    paramParcel.writeString(this.e);
    paramParcel.writeLong(this.f);
    paramParcel.writeLong(this.g);
    paramParcel.writeParcelable(this.b, paramInt);
    paramParcel.writeParcelable(this.d, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/filetransferlib/filetransfer/TVFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */