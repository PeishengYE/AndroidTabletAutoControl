package com.teamviewer.filetransferlib.filetransfer;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import o.bbg;

public enum TVFile$FileType
  implements Parcelable
{
  public static final Parcelable.Creator<FileType> CREATOR = new bbg();
  
  private TVFile$FileType() {}
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(ordinal());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/filetransferlib/filetransfer/TVFile$FileType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */