package com.teamviewer.commonviewmodel.swig;

public class ErrorCodeSWIGJNI
{
  public static final native long ErrorCode_Assignment(long paramLong1, ErrorCode paramErrorCode1, long paramLong2, ErrorCode paramErrorCode2);
  
  public static final native boolean ErrorCode_Equal(long paramLong1, ErrorCode paramErrorCode1, long paramLong2, ErrorCode paramErrorCode2);
  
  public static final native int ErrorCode_GetErrorCategory(long paramLong, ErrorCode paramErrorCode);
  
  public static final native int ErrorCode_GetErrorId(long paramLong, ErrorCode paramErrorCode);
  
  public static final native String ErrorCode_GetMessage(long paramLong, ErrorCode paramErrorCode);
  
  public static final native boolean ErrorCode_NotEqual(long paramLong1, ErrorCode paramErrorCode1, long paramLong2, ErrorCode paramErrorCode2);
  
  public static final native void delete_ErrorCode(long paramLong);
  
  public static final native long new_ErrorCode__SWIG_0(long paramLong, ErrorCode paramErrorCode);
  
  public static final native long new_ErrorCode__SWIG_1(int paramInt1, int paramInt2);
  
  public static final native long new_ErrorCode__SWIG_2(int paramInt1, int paramInt2, String paramString);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ErrorCodeSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */