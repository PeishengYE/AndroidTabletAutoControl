package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class GenericSignalCallback
  extends IGenericSignalCallback
{
  private transient long swigCPtr;
  
  public GenericSignalCallback()
  {
    this(GenericSignalCallbackSWIGJNI.new_GenericSignalCallback(), true);
    GenericSignalCallbackSWIGJNI.GenericSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public GenericSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(GenericSignalCallbackSWIGJNI.GenericSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(GenericSignalCallback paramGenericSignalCallback)
  {
    if (paramGenericSignalCallback == null) {
      return 0L;
    }
    return paramGenericSignalCallback.swigCPtr;
  }
  
  public abstract void OnCallback();
  
  public void PerformCallback()
  {
    try
    {
      OnCallback();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("GenericSignalCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GenericSignalCallbackSWIGJNI.delete_GenericSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    GenericSignalCallbackSWIGJNI.GenericSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    GenericSignalCallbackSWIGJNI.GenericSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/GenericSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */