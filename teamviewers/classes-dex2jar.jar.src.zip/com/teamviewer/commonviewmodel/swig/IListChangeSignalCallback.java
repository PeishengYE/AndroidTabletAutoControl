package com.teamviewer.commonviewmodel.swig;

public class IListChangeSignalCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public IListChangeSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(IListChangeSignalCallbackSWIGJNI.IListChangeSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IListChangeSignalCallback paramIListChangeSignalCallback)
  {
    if (paramIListChangeSignalCallback == null) {
      return 0L;
    }
    return paramIListChangeSignalCallback.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IListChangeSignalCallbackSWIGJNI.delete_IListChangeSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IListChangeSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */