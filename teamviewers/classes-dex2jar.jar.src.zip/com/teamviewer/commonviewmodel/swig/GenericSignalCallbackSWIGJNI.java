package com.teamviewer.commonviewmodel.swig;

public class GenericSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void GenericSignalCallback_PerformCallback(long paramLong, GenericSignalCallback paramGenericSignalCallback);
  
  public static final native long GenericSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void GenericSignalCallback_change_ownership(GenericSignalCallback paramGenericSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void GenericSignalCallback_director_connect(GenericSignalCallback paramGenericSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_GenericSignalCallback_PerformCallback(GenericSignalCallback paramGenericSignalCallback)
  {
    paramGenericSignalCallback.PerformCallback();
  }
  
  public static final native void delete_GenericSignalCallback(long paramLong);
  
  public static final native long new_GenericSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/GenericSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */