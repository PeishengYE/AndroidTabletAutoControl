package com.teamviewer.commonviewmodel.swig;

public class ListChangeSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void ListChangeSignalCallback_PerformListChanged(long paramLong1, ListChangeSignalCallback paramListChangeSignalCallback, long paramLong2, ListChangeArgs paramListChangeArgs);
  
  public static final native long ListChangeSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void ListChangeSignalCallback_change_ownership(ListChangeSignalCallback paramListChangeSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void ListChangeSignalCallback_director_connect(ListChangeSignalCallback paramListChangeSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_ListChangeSignalCallback_PerformListChanged(ListChangeSignalCallback paramListChangeSignalCallback, long paramLong)
  {
    paramListChangeSignalCallback.PerformListChanged(new ListChangeArgs(paramLong, false));
  }
  
  public static final native void delete_ListChangeSignalCallback(long paramLong);
  
  public static final native long new_ListChangeSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ListChangeSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */