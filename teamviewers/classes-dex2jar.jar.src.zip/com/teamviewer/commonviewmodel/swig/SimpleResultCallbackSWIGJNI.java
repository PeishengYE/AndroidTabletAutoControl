package com.teamviewer.commonviewmodel.swig;

public class SimpleResultCallbackSWIGJNI
{
  static {}
  
  public static final native void SimpleResultCallback_PerformError(long paramLong, SimpleResultCallback paramSimpleResultCallback);
  
  public static final native void SimpleResultCallback_PerformSuccess(long paramLong, SimpleResultCallback paramSimpleResultCallback);
  
  public static final native long SimpleResultCallback_SWIGUpcast(long paramLong);
  
  public static final native void SimpleResultCallback_change_ownership(SimpleResultCallback paramSimpleResultCallback, long paramLong, boolean paramBoolean);
  
  public static final native void SimpleResultCallback_director_connect(SimpleResultCallback paramSimpleResultCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_SimpleResultCallback_PerformError(SimpleResultCallback paramSimpleResultCallback)
  {
    paramSimpleResultCallback.PerformError();
  }
  
  public static void SwigDirector_SimpleResultCallback_PerformSuccess(SimpleResultCallback paramSimpleResultCallback)
  {
    paramSimpleResultCallback.PerformSuccess();
  }
  
  public static final native void delete_SimpleResultCallback(long paramLong);
  
  public static final native long new_SimpleResultCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SimpleResultCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */