package com.teamviewer.commonviewmodel.swig;

public class IIntSignalCallbackSWIGJNI
{
  public static final native long IIntSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void delete_IIntSignalCallback(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IIntSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */