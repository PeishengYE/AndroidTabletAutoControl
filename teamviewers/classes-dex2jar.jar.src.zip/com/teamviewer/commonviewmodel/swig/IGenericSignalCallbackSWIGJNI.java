package com.teamviewer.commonviewmodel.swig;

public class IGenericSignalCallbackSWIGJNI
{
  public static final native long IGenericSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void delete_IGenericSignalCallback(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IGenericSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */