package com.teamviewer.commonviewmodel.swig;

public class IErrorMessageCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public IErrorMessageCallback(long paramLong, boolean paramBoolean)
  {
    super(IErrorMessageCallbackSWIGJNI.IErrorMessageCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IErrorMessageCallback paramIErrorMessageCallback)
  {
    if (paramIErrorMessageCallback == null) {
      return 0L;
    }
    return paramIErrorMessageCallback.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IErrorMessageCallbackSWIGJNI.delete_IErrorMessageCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IErrorMessageCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */