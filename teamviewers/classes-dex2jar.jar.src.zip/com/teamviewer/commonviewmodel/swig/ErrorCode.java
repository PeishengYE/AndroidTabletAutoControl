package com.teamviewer.commonviewmodel.swig;

public class ErrorCode
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ErrorCode(int paramInt, ErrorCategory paramErrorCategory)
  {
    this(ErrorCodeSWIGJNI.new_ErrorCode__SWIG_1(paramInt, paramErrorCategory.swigValue()), true);
  }
  
  public ErrorCode(int paramInt, ErrorCategory paramErrorCategory, String paramString)
  {
    this(ErrorCodeSWIGJNI.new_ErrorCode__SWIG_2(paramInt, paramErrorCategory.swigValue(), paramString), true);
  }
  
  public ErrorCode(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public ErrorCode(ErrorCode paramErrorCode)
  {
    this(ErrorCodeSWIGJNI.new_ErrorCode__SWIG_0(getCPtr(paramErrorCode), paramErrorCode), true);
  }
  
  public static long getCPtr(ErrorCode paramErrorCode)
  {
    if (paramErrorCode == null) {
      return 0L;
    }
    return paramErrorCode.swigCPtr;
  }
  
  public ErrorCode Assignment(ErrorCode paramErrorCode)
  {
    return new ErrorCode(ErrorCodeSWIGJNI.ErrorCode_Assignment(this.swigCPtr, this, getCPtr(paramErrorCode), paramErrorCode), false);
  }
  
  public boolean Equal(ErrorCode paramErrorCode)
  {
    return ErrorCodeSWIGJNI.ErrorCode_Equal(this.swigCPtr, this, getCPtr(paramErrorCode), paramErrorCode);
  }
  
  public ErrorCategory GetErrorCategory()
  {
    return ErrorCategory.swigToEnum(ErrorCodeSWIGJNI.ErrorCode_GetErrorCategory(this.swigCPtr, this));
  }
  
  public int GetErrorId()
  {
    return ErrorCodeSWIGJNI.ErrorCode_GetErrorId(this.swigCPtr, this);
  }
  
  public String GetMessage()
  {
    return ErrorCodeSWIGJNI.ErrorCode_GetMessage(this.swigCPtr, this);
  }
  
  public boolean NotEqual(ErrorCode paramErrorCode)
  {
    return ErrorCodeSWIGJNI.ErrorCode_NotEqual(this.swigCPtr, this, getCPtr(paramErrorCode), paramErrorCode);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ErrorCodeSWIGJNI.delete_ErrorCode(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ErrorCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */