package com.teamviewer.commonviewmodel.swig;

public class IIntSignalCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public IIntSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(IIntSignalCallbackSWIGJNI.IIntSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IIntSignalCallback paramIIntSignalCallback)
  {
    if (paramIIntSignalCallback == null) {
      return 0L;
    }
    return paramIIntSignalCallback.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IIntSignalCallbackSWIGJNI.delete_IIntSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IIntSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */