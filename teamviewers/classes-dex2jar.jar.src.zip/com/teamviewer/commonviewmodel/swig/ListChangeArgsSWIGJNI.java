package com.teamviewer.commonviewmodel.swig;

public class ListChangeArgsSWIGJNI
{
  public static final native int ListChangeArgs_GetListChangeType(long paramLong, ListChangeArgs paramListChangeArgs);
  
  public static final native long ListChangeArgs_GetNewPositions(long paramLong, ListChangeArgs paramListChangeArgs);
  
  public static final native long ListChangeArgs_GetOldPositions(long paramLong, ListChangeArgs paramListChangeArgs);
  
  public static final native void SizeTVector_add(long paramLong1, SizeTVector paramSizeTVector, long paramLong2);
  
  public static final native long SizeTVector_capacity(long paramLong, SizeTVector paramSizeTVector);
  
  public static final native void SizeTVector_clear(long paramLong, SizeTVector paramSizeTVector);
  
  public static final native long SizeTVector_get(long paramLong, SizeTVector paramSizeTVector, int paramInt);
  
  public static final native boolean SizeTVector_isEmpty(long paramLong, SizeTVector paramSizeTVector);
  
  public static final native void SizeTVector_reserve(long paramLong1, SizeTVector paramSizeTVector, long paramLong2);
  
  public static final native void SizeTVector_set(long paramLong1, SizeTVector paramSizeTVector, int paramInt, long paramLong2);
  
  public static final native long SizeTVector_size(long paramLong, SizeTVector paramSizeTVector);
  
  public static final native void delete_ListChangeArgs(long paramLong);
  
  public static final native void delete_SizeTVector(long paramLong);
  
  public static final native long new_SizeTVector__SWIG_0();
  
  public static final native long new_SizeTVector__SWIG_1(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ListChangeArgsSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */