package com.teamviewer.commonviewmodel.swig;

public class SingleErrorResultCallbackSWIGJNI
{
  static {}
  
  public static final native void SingleErrorResultCallback_PerformError(long paramLong1, SingleErrorResultCallback paramSingleErrorResultCallback, long paramLong2, ErrorCode paramErrorCode);
  
  public static final native void SingleErrorResultCallback_PerformSuccess(long paramLong, SingleErrorResultCallback paramSingleErrorResultCallback);
  
  public static final native long SingleErrorResultCallback_SWIGUpcast(long paramLong);
  
  public static final native void SingleErrorResultCallback_change_ownership(SingleErrorResultCallback paramSingleErrorResultCallback, long paramLong, boolean paramBoolean);
  
  public static final native void SingleErrorResultCallback_director_connect(SingleErrorResultCallback paramSingleErrorResultCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_SingleErrorResultCallback_PerformError(SingleErrorResultCallback paramSingleErrorResultCallback, long paramLong)
  {
    paramSingleErrorResultCallback.PerformError(new ErrorCode(paramLong, false));
  }
  
  public static void SwigDirector_SingleErrorResultCallback_PerformSuccess(SingleErrorResultCallback paramSingleErrorResultCallback)
  {
    paramSingleErrorResultCallback.PerformSuccess();
  }
  
  public static final native void delete_SingleErrorResultCallback(long paramLong);
  
  public static final native long new_SingleErrorResultCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SingleErrorResultCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */