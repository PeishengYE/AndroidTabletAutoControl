package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class SingleErrorResultCallback
  extends ISingleErrorResultCallback
{
  private transient long swigCPtr;
  
  public SingleErrorResultCallback()
  {
    this(SingleErrorResultCallbackSWIGJNI.new_SingleErrorResultCallback(), true);
    SingleErrorResultCallbackSWIGJNI.SingleErrorResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public SingleErrorResultCallback(long paramLong, boolean paramBoolean)
  {
    super(SingleErrorResultCallbackSWIGJNI.SingleErrorResultCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(SingleErrorResultCallback paramSingleErrorResultCallback)
  {
    if (paramSingleErrorResultCallback == null) {
      return 0L;
    }
    return paramSingleErrorResultCallback.swigCPtr;
  }
  
  public abstract void OnError(ErrorCode paramErrorCode);
  
  public abstract void OnSuccess();
  
  public void PerformError(ErrorCode paramErrorCode)
  {
    try
    {
      OnError(paramErrorCode);
      return;
    }
    catch (Throwable paramErrorCode)
    {
      Logging.a("SingleErrorResultCallback", paramErrorCode);
      throw paramErrorCode;
    }
  }
  
  public void PerformSuccess()
  {
    try
    {
      OnSuccess();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("SingleErrorResultCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          SingleErrorResultCallbackSWIGJNI.delete_SingleErrorResultCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    SingleErrorResultCallbackSWIGJNI.SingleErrorResultCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    SingleErrorResultCallbackSWIGJNI.SingleErrorResultCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SingleErrorResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */