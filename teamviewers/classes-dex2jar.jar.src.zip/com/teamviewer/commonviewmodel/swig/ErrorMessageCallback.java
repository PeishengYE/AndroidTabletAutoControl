package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class ErrorMessageCallback
  extends IErrorMessageCallback
{
  private transient long swigCPtr;
  
  public ErrorMessageCallback()
  {
    this(ErrorMessageCallbackSWIGJNI.new_ErrorMessageCallback(), true);
    ErrorMessageCallbackSWIGJNI.ErrorMessageCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public ErrorMessageCallback(long paramLong, boolean paramBoolean)
  {
    super(ErrorMessageCallbackSWIGJNI.ErrorMessageCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ErrorMessageCallback paramErrorMessageCallback)
  {
    if (paramErrorMessageCallback == null) {
      return 0L;
    }
    return paramErrorMessageCallback.swigCPtr;
  }
  
  public abstract void OnShowMessage(String paramString1, String paramString2, boolean paramBoolean);
  
  public void PerformShowMessage(String paramString1, String paramString2, boolean paramBoolean)
  {
    try
    {
      OnShowMessage(paramString1, paramString2, paramBoolean);
      return;
    }
    catch (Throwable paramString1)
    {
      Logging.a("ErrorMessageCallback", paramString1);
      throw paramString1;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ErrorMessageCallbackSWIGJNI.delete_ErrorMessageCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    ErrorMessageCallbackSWIGJNI.ErrorMessageCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    ErrorMessageCallbackSWIGJNI.ErrorMessageCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ErrorMessageCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */