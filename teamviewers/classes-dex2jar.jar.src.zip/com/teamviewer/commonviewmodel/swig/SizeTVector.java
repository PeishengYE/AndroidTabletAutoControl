package com.teamviewer.commonviewmodel.swig;

public class SizeTVector
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public SizeTVector()
  {
    this(ListChangeArgsSWIGJNI.new_SizeTVector__SWIG_0(), true);
  }
  
  public SizeTVector(long paramLong)
  {
    this(ListChangeArgsSWIGJNI.new_SizeTVector__SWIG_1(paramLong), true);
  }
  
  public SizeTVector(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(SizeTVector paramSizeTVector)
  {
    if (paramSizeTVector == null) {
      return 0L;
    }
    return paramSizeTVector.swigCPtr;
  }
  
  public void add(long paramLong)
  {
    ListChangeArgsSWIGJNI.SizeTVector_add(this.swigCPtr, this, paramLong);
  }
  
  public long capacity()
  {
    return ListChangeArgsSWIGJNI.SizeTVector_capacity(this.swigCPtr, this);
  }
  
  public void clear()
  {
    ListChangeArgsSWIGJNI.SizeTVector_clear(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ListChangeArgsSWIGJNI.delete_SizeTVector(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long get(int paramInt)
  {
    return ListChangeArgsSWIGJNI.SizeTVector_get(this.swigCPtr, this, paramInt);
  }
  
  public boolean isEmpty()
  {
    return ListChangeArgsSWIGJNI.SizeTVector_isEmpty(this.swigCPtr, this);
  }
  
  public void reserve(long paramLong)
  {
    ListChangeArgsSWIGJNI.SizeTVector_reserve(this.swigCPtr, this, paramLong);
  }
  
  public void set(int paramInt, long paramLong)
  {
    ListChangeArgsSWIGJNI.SizeTVector_set(this.swigCPtr, this, paramInt, paramLong);
  }
  
  public long size()
  {
    return ListChangeArgsSWIGJNI.SizeTVector_size(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SizeTVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */