package com.teamviewer.commonviewmodel.swig;

public class StringErrorResultCallbackSWIGJNI
{
  static {}
  
  public static final native void StringErrorResultCallback_PerformError(long paramLong, StringErrorResultCallback paramStringErrorResultCallback, String paramString);
  
  public static final native void StringErrorResultCallback_PerformSuccess(long paramLong, StringErrorResultCallback paramStringErrorResultCallback);
  
  public static final native long StringErrorResultCallback_SWIGUpcast(long paramLong);
  
  public static final native void StringErrorResultCallback_change_ownership(StringErrorResultCallback paramStringErrorResultCallback, long paramLong, boolean paramBoolean);
  
  public static final native void StringErrorResultCallback_director_connect(StringErrorResultCallback paramStringErrorResultCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_StringErrorResultCallback_PerformError(StringErrorResultCallback paramStringErrorResultCallback, String paramString)
  {
    paramStringErrorResultCallback.PerformError(paramString);
  }
  
  public static void SwigDirector_StringErrorResultCallback_PerformSuccess(StringErrorResultCallback paramStringErrorResultCallback)
  {
    paramStringErrorResultCallback.PerformSuccess();
  }
  
  public static final native void delete_StringErrorResultCallback(long paramLong);
  
  public static final native long new_StringErrorResultCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/StringErrorResultCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */