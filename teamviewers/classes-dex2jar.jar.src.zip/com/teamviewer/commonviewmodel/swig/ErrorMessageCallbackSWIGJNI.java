package com.teamviewer.commonviewmodel.swig;

public class ErrorMessageCallbackSWIGJNI
{
  static {}
  
  public static final native void ErrorMessageCallback_PerformShowMessage(long paramLong, ErrorMessageCallback paramErrorMessageCallback, String paramString1, String paramString2, boolean paramBoolean);
  
  public static final native long ErrorMessageCallback_SWIGUpcast(long paramLong);
  
  public static final native void ErrorMessageCallback_change_ownership(ErrorMessageCallback paramErrorMessageCallback, long paramLong, boolean paramBoolean);
  
  public static final native void ErrorMessageCallback_director_connect(ErrorMessageCallback paramErrorMessageCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_ErrorMessageCallback_PerformShowMessage(ErrorMessageCallback paramErrorMessageCallback, String paramString1, String paramString2, boolean paramBoolean)
  {
    paramErrorMessageCallback.PerformShowMessage(paramString1, paramString2, paramBoolean);
  }
  
  public static final native void delete_ErrorMessageCallback(long paramLong);
  
  public static final native long new_ErrorMessageCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ErrorMessageCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */