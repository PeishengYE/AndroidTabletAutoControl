package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class StringErrorResultCallback
  extends IStringErrorResultCallback
{
  private transient long swigCPtr;
  
  public StringErrorResultCallback()
  {
    this(StringErrorResultCallbackSWIGJNI.new_StringErrorResultCallback(), true);
    StringErrorResultCallbackSWIGJNI.StringErrorResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public StringErrorResultCallback(long paramLong, boolean paramBoolean)
  {
    super(StringErrorResultCallbackSWIGJNI.StringErrorResultCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(StringErrorResultCallback paramStringErrorResultCallback)
  {
    if (paramStringErrorResultCallback == null) {
      return 0L;
    }
    return paramStringErrorResultCallback.swigCPtr;
  }
  
  public abstract void OnError(String paramString);
  
  public abstract void OnSuccess();
  
  public void PerformError(String paramString)
  {
    try
    {
      OnError(paramString);
      return;
    }
    catch (Throwable paramString)
    {
      Logging.a("StringErrorResultCallback", paramString);
      throw paramString;
    }
  }
  
  public void PerformSuccess()
  {
    try
    {
      OnSuccess();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("StringErrorResultCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          StringErrorResultCallbackSWIGJNI.delete_StringErrorResultCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    StringErrorResultCallbackSWIGJNI.StringErrorResultCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    StringErrorResultCallbackSWIGJNI.StringErrorResultCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/StringErrorResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */