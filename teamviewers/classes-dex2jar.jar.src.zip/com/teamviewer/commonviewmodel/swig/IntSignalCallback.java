package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class IntSignalCallback
  extends IIntSignalCallback
{
  private transient long swigCPtr;
  
  public IntSignalCallback()
  {
    this(IntSignalCallbackSWIGJNI.new_IntSignalCallback(), true);
    IntSignalCallbackSWIGJNI.IntSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public IntSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(IntSignalCallbackSWIGJNI.IntSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IntSignalCallback paramIntSignalCallback)
  {
    if (paramIntSignalCallback == null) {
      return 0L;
    }
    return paramIntSignalCallback.swigCPtr;
  }
  
  public abstract void OnCallback(int paramInt);
  
  public void PerformCallback(int paramInt)
  {
    try
    {
      OnCallback(paramInt);
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("IntSignalCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IntSignalCallbackSWIGJNI.delete_IntSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    IntSignalCallbackSWIGJNI.IntSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    IntSignalCallbackSWIGJNI.IntSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IntSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */