package com.teamviewer.commonviewmodel.swig;

public class SignalCallbackBaseSWIGJNI
{
  public static final native void SignalCallbackBase_disconnect(long paramLong, SignalCallbackBase paramSignalCallbackBase);
  
  public static final native boolean SignalCallbackBase_isConnected(long paramLong, SignalCallbackBase paramSignalCallbackBase);
  
  public static final native void delete_SignalCallbackBase(long paramLong);
  
  public static final native long new_SignalCallbackBase();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SignalCallbackBaseSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */