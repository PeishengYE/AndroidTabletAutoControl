package com.teamviewer.commonviewmodel.swig;

public class ListChangeArgs
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ListChangeArgs(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ListChangeArgs paramListChangeArgs)
  {
    if (paramListChangeArgs == null) {
      return 0L;
    }
    return paramListChangeArgs.swigCPtr;
  }
  
  public ListChangeArgs.ListChangeType GetListChangeType()
  {
    return ListChangeArgs.ListChangeType.swigToEnum(ListChangeArgsSWIGJNI.ListChangeArgs_GetListChangeType(this.swigCPtr, this));
  }
  
  public SizeTVector GetNewPositions()
  {
    return new SizeTVector(ListChangeArgsSWIGJNI.ListChangeArgs_GetNewPositions(this.swigCPtr, this), true);
  }
  
  public SizeTVector GetOldPositions()
  {
    return new SizeTVector(ListChangeArgsSWIGJNI.ListChangeArgs_GetOldPositions(this.swigCPtr, this), true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ListChangeArgsSWIGJNI.delete_ListChangeArgs(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ListChangeArgs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */