package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class SimpleResultCallback
  extends ISimpleResultCallback
{
  private transient long swigCPtr;
  
  public SimpleResultCallback()
  {
    this(SimpleResultCallbackSWIGJNI.new_SimpleResultCallback(), true);
    SimpleResultCallbackSWIGJNI.SimpleResultCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public SimpleResultCallback(long paramLong, boolean paramBoolean)
  {
    super(SimpleResultCallbackSWIGJNI.SimpleResultCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(SimpleResultCallback paramSimpleResultCallback)
  {
    if (paramSimpleResultCallback == null) {
      return 0L;
    }
    return paramSimpleResultCallback.swigCPtr;
  }
  
  public abstract void OnError();
  
  public abstract void OnSuccess();
  
  public void PerformError()
  {
    try
    {
      OnError();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("SimpleResultCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void PerformSuccess()
  {
    try
    {
      OnSuccess();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("SimpleResultCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          SimpleResultCallbackSWIGJNI.delete_SimpleResultCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    SimpleResultCallbackSWIGJNI.SimpleResultCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    SimpleResultCallbackSWIGJNI.SimpleResultCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/SimpleResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */