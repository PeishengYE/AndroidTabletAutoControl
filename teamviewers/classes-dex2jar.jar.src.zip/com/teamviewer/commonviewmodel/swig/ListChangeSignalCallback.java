package com.teamviewer.commonviewmodel.swig;

import com.teamviewer.corelib.logging.Logging;

public abstract class ListChangeSignalCallback
  extends IListChangeSignalCallback
{
  private transient long swigCPtr;
  
  public ListChangeSignalCallback()
  {
    this(ListChangeSignalCallbackSWIGJNI.new_ListChangeSignalCallback(), true);
    ListChangeSignalCallbackSWIGJNI.ListChangeSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public ListChangeSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(ListChangeSignalCallbackSWIGJNI.ListChangeSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ListChangeSignalCallback paramListChangeSignalCallback)
  {
    if (paramListChangeSignalCallback == null) {
      return 0L;
    }
    return paramListChangeSignalCallback.swigCPtr;
  }
  
  public abstract void OnListChanged(ListChangeArgs paramListChangeArgs);
  
  public void PerformListChanged(ListChangeArgs paramListChangeArgs)
  {
    try
    {
      OnListChanged(paramListChangeArgs);
      return;
    }
    catch (Throwable paramListChangeArgs)
    {
      Logging.a("ListChangeSignalCallback", paramListChangeArgs);
      throw paramListChangeArgs;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ListChangeSignalCallbackSWIGJNI.delete_ListChangeSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    ListChangeSignalCallbackSWIGJNI.ListChangeSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    ListChangeSignalCallbackSWIGJNI.ListChangeSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ListChangeSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */