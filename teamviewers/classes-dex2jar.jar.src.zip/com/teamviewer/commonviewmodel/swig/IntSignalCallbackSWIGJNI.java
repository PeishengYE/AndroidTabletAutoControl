package com.teamviewer.commonviewmodel.swig;

public class IntSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void IntSignalCallback_PerformCallback(long paramLong, IntSignalCallback paramIntSignalCallback, int paramInt);
  
  public static final native long IntSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void IntSignalCallback_change_ownership(IntSignalCallback paramIntSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void IntSignalCallback_director_connect(IntSignalCallback paramIntSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_IntSignalCallback_PerformCallback(IntSignalCallback paramIntSignalCallback, int paramInt)
  {
    paramIntSignalCallback.PerformCallback(paramInt);
  }
  
  public static final native void delete_IntSignalCallback(long paramLong);
  
  public static final native long new_IntSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/IntSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */