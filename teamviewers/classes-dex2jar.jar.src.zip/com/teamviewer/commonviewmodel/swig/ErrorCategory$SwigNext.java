package com.teamviewer.commonviewmodel.swig;

class ErrorCategory$SwigNext
{
  private static int next = 0;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ErrorCategory$SwigNext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */