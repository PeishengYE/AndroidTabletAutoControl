package com.teamviewer.commonviewmodel.swig;

public class ISingleErrorResultCallbackSWIGJNI
{
  public static final native void delete_ISingleErrorResultCallback(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/commonviewmodel/swig/ISingleErrorResultCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */