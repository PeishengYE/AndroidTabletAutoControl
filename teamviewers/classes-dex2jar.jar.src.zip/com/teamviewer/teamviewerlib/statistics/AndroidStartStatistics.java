package com.teamviewer.teamviewerlib.statistics;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Process;
import android.provider.Settings.Secure;
import java.lang.reflect.Method;
import o.chk;
import o.chs;

public class AndroidStartStatistics
{
  private static String a()
  {
    try
    {
      Object localObject = Class.forName("android.os.SystemProperties");
      localObject = (String)((Class)localObject).getMethod("get", new Class[] { String.class, String.class }).invoke(localObject, new Object[] { "ril.serialnumber", null });
      return (String)localObject;
    }
    catch (Exception localException) {}
    return null;
  }
  
  public static void a(Context paramContext)
  {
    jniInitStatistics(chk.b(), chk.a(), Build.VERSION.SDK_INT, chk.d(), a(), Settings.Secure.getString(paramContext.getContentResolver(), "android_id"), chs.a(), chk.c(), b());
  }
  
  private static boolean b()
  {
    return ("samsung".equalsIgnoreCase(chk.b())) && (Process.myUid() >= 10000000);
  }
  
  private static native void jniInitStatistics(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, boolean paramBoolean);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/statistics/AndroidStartStatistics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */