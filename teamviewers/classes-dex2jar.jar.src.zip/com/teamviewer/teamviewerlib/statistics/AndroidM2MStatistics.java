package com.teamviewer.teamviewerlib.statistics;

public class AndroidM2MStatistics
{
  public static void a() {}
  
  public static void a(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    jniZoomStatistics(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  private static native void jniButtonTapStatistics();
  
  private static native void jniZoomStatistics(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/statistics/AndroidM2MStatistics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */