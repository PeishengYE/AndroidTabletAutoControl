package com.teamviewer.teamviewerlib.authentication;

import com.teamviewer.teamviewerlib.bcommands.BCommand;
import o.byv;
import o.bza;
import o.cbq;

public final class AuthenticationMethodAdapter$Result
{
  public final bza a;
  public final cbq b;
  
  @byv
  AuthenticationMethodAdapter$Result(int paramInt, long paramLong)
  {
    this.a = bza.a(paramInt);
    if (paramLong != 0L)
    {
      this.b = new cbq(new BCommand(paramLong));
      return;
    }
    this.b = null;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/authentication/AuthenticationMethodAdapter$Result.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */