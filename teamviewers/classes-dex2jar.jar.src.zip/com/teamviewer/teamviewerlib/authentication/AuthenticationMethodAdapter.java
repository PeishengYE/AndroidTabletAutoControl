package com.teamviewer.teamviewerlib.authentication;

import com.teamviewer.teamviewerlib.bcommands.BCommand;

public class AuthenticationMethodAdapter
{
  private final long a;
  
  static {}
  
  private AuthenticationMethodAdapter(long paramLong)
  {
    this.a = paramLong;
  }
  
  private static native long jniCreatePublicKeyActive(int paramInt1, int paramInt2, long paramLong);
  
  private static native long jniCreateSRPActive(String paramString1, String paramString2);
  
  private static native void jniInit();
  
  private static native long jniRelease(long paramLong);
  
  private static native AuthenticationMethodAdapter.Result nextStep(long paramLong1, long paramLong2);
  
  public AuthenticationMethodAdapter.Result a(BCommand paramBCommand)
  {
    long l2 = this.a;
    if (paramBCommand != null) {}
    for (long l1 = paramBCommand.a();; l1 = 0L) {
      return nextStep(l2, l1);
    }
  }
  
  public void a()
  {
    jniRelease(this.a);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/authentication/AuthenticationMethodAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */