package com.teamviewer.teamviewerlib.authentication;

import com.teamviewer.teamviewerlib.bcommands.BCommand;

public class LoginHelper
{
  public static void a(BCommand paramBCommand, int paramInt1, int paramInt2, String paramString)
  {
    jniAddLoginTokenToBCommand(paramBCommand.a(), paramInt1, paramInt2, paramString);
  }
  
  private static native void jniAddLoginTokenToBCommand(long paramLong, int paramInt1, int paramInt2, String paramString);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/authentication/LoginHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */