package com.teamviewer.teamviewerlib.partnerlist.helper;

import com.teamviewer.corelib.logging.Logging;
import java.text.Collator;
import java.util.Locale;
import o.byv;

public final class StringCompareHelper
{
  private static final Collator a = Collator.getInstance(Locale.getDefault());
  
  static
  {
    a.setStrength(2);
  }
  
  public static void a()
  {
    if (!jniInit()) {
      Logging.b("StringCompareHelper", "init failed");
    }
  }
  
  @byv
  public static int compare(String paramString1, String paramString2)
  {
    return a.compare(paramString1, paramString2);
  }
  
  @byv
  public static boolean contains(String paramString1, String paramString2)
  {
    return paramString1.toLowerCase(Locale.getDefault()).contains(paramString2.toLowerCase(Locale.getDefault()));
  }
  
  private static native boolean jniInit();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/partnerlist/helper/StringCompareHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */