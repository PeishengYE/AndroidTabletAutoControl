package com.teamviewer.teamviewerlib.settings;

import android.annotation.TargetApi;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;
import android.os.Build.VERSION;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.NativeLibTvExt;
import java.util.Date;
import java.util.Locale;
import o.byt;
import o.byv;
import o.cjk;
import o.cng;
import o.cnh;
import o.cni;
import o.cnj;
import o.cnk;
import o.cnl;
import o.cnm;
import o.cno;
import o.cnp;

public class Settings
{
  private static Settings a = null;
  private cnm<cng> b = new cnm();
  private cnm<cni> c = new cnm();
  private cnm<cnj> d = new cnm();
  private cnm<cnk> e = new cnm();
  private cnm<cnh> f = new cnm();
  private int g = 10000;
  private int h = 0;
  private int i = 0;
  private int j = 0;
  private final String k = byt.b();
  private final Date l;
  private final int m = Build.VERSION.SDK_INT + 8192;
  
  static
  {
    if ((!NativeLibTvExt.a()) || (!jniInit())) {
      Logging.d("Settings", "initializing Settings failed!");
    }
  }
  
  private Settings()
  {
    Logging.b("Settings", "version: " + this.k);
    SharedPreferences.Editor localEditor = cjk.a().edit();
    localEditor.putString("VERSION_STRING", this.k);
    localEditor.commit();
    this.l = new Date();
  }
  
  public static Settings a()
  {
    if (a == null) {
      a = new Settings();
    }
    return a;
  }
  
  public static <T extends Enum<T>,  extends cnl> void a(cno paramcno, T paramT, int paramInt)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    jniSetInt(paramcno.a(), ((cnl)paramT).a(), paramInt);
  }
  
  public static <T extends Enum<T>,  extends cnl> void a(cno paramcno, T paramT, String paramString)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    jniSetString(paramcno.a(), ((cnl)paramT).a(), paramString);
  }
  
  public static <T extends Enum<T>,  extends cnl> void a(cno paramcno, T paramT, boolean paramBoolean)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    jniSetBool(paramcno.a(), ((cnl)paramT).a(), paramBoolean);
  }
  
  public static <T extends Enum<T>,  extends cnl> boolean a(cno paramcno, T paramT)
  {
    if (!NativeLibTvExt.a()) {
      return false;
    }
    return jniGetBool(paramcno.a(), ((cnl)paramT).a());
  }
  
  public static boolean a(cno paramcno, cnl paramcnl)
  {
    if (!NativeLibTvExt.a()) {
      return false;
    }
    return jniIsProp(paramcno.a(), paramcnl.a());
  }
  
  public static <T extends Enum<T>,  extends cnl> int b(cno paramcno, T paramT)
  {
    if (!NativeLibTvExt.a()) {
      return 0;
    }
    return jniGetInt(paramcno.a(), ((cnl)paramT).a());
  }
  
  public static <T extends Enum<T>,  extends cnl> String c(cno paramcno, T paramT)
  {
    if (!NativeLibTvExt.a()) {
      return "";
    }
    return jniGetString(paramcno.a(), ((cnl)paramT).a());
  }
  
  public static String e()
  {
    return System.getProperty("os.arch");
  }
  
  public static String f()
  {
    if (Build.VERSION.SDK_INT >= 21) {
      return l();
    }
    return k();
  }
  
  public static String g()
  {
    String str2 = "And" + Build.VERSION.RELEASE;
    String str1 = str2;
    if (str2.length() > 10) {
      str1 = str2.substring(0, 10);
    }
    return str1;
  }
  
  @byv
  public static void handleBoolPropertyChangedCallback(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    cng localcng = (cng)a().b.b(paramInt);
    if (localcng != null)
    {
      localcng.a(paramBoolean1, paramBoolean2);
      return;
    }
    Logging.c("Settings", "no property listener found");
  }
  
  @byv
  public static void handleByteArrayPropertyChangedCallback(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    cnh localcnh = (cnh)a().f.b(paramInt);
    if (localcnh != null)
    {
      localcnh.a(paramArrayOfByte1, paramArrayOfByte2);
      return;
    }
    Logging.c("Settings", "no property listener found");
  }
  
  @byv
  public static void handleInt64PropertyChangedCallback(int paramInt, long paramLong1, long paramLong2)
  {
    cnj localcnj = (cnj)a().d.b(paramInt);
    if (localcnj != null)
    {
      localcnj.a(paramLong1, paramLong2);
      return;
    }
    Logging.c("Settings", "no property listener found");
  }
  
  @byv
  public static void handleIntPropertyChangedCallback(int paramInt1, int paramInt2, int paramInt3)
  {
    cni localcni = (cni)a().c.b(paramInt1);
    if (localcni != null)
    {
      localcni.a(paramInt2, paramInt3);
      return;
    }
    Logging.c("Settings", "no property listener found");
  }
  
  @byv
  public static void handleStringPropertyChangedCallback(int paramInt, String paramString1, String paramString2)
  {
    cnk localcnk = (cnk)a().e.b(paramInt);
    if (localcnk != null)
    {
      localcnk.a(paramString1, paramString2);
      return;
    }
    Logging.c("Settings", "no property listener found");
  }
  
  private static native boolean jniGetBool(int paramInt, String paramString);
  
  private static native int jniGetInt(int paramInt, String paramString);
  
  private static native String jniGetString(int paramInt, String paramString);
  
  private static native boolean jniInit();
  
  private static native boolean jniIsProp(int paramInt, String paramString);
  
  private static native void jniRegisterBoolListener(int paramInt1, String paramString, int paramInt2);
  
  private static native void jniRegisterIntListener(int paramInt1, String paramString, int paramInt2);
  
  private static native void jniSetBool(int paramInt, String paramString, boolean paramBoolean);
  
  private static native void jniSetInt(int paramInt1, String paramString, int paramInt2);
  
  private static native void jniSetString(int paramInt, String paramString1, String paramString2);
  
  private static native void jniUnregisterListener(int paramInt);
  
  private static String k()
  {
    return Build.CPU_ABI + " : " + Build.CPU_ABI2;
  }
  
  @TargetApi(21)
  private static String l()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String[] arrayOfString = Build.SUPPORTED_ABIS;
    int i1 = arrayOfString.length;
    int n = 0;
    while (n < i1)
    {
      localStringBuilder.append(arrayOfString[n]);
      localStringBuilder.append(" ");
      n += 1;
    }
    return localStringBuilder.toString();
  }
  
  public void a(cng paramcng, cno paramcno, cnl paramcnl)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    int n = this.b.a(paramcng);
    jniRegisterBoolListener(paramcno.a(), paramcnl.a(), n);
  }
  
  public void a(cni paramcni)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    int n = this.c.b(paramcni);
    this.c.a(n);
    jniUnregisterListener(n);
  }
  
  public void a(cni paramcni, cno paramcno, cnl paramcnl)
  {
    if (!NativeLibTvExt.a()) {
      return;
    }
    int n = this.c.a(paramcni);
    jniRegisterIntListener(paramcno.a(), paramcnl.a(), n);
  }
  
  public final int b()
  {
    int n = 0;
    if (a(cno.a, cnp.b)) {
      n = b(cno.a, cnp.b);
    }
    return n;
  }
  
  public final int c()
  {
    return this.g;
  }
  
  public final String d()
  {
    return this.k;
  }
  
  public final Date h()
  {
    return (Date)this.l.clone();
  }
  
  public final int i()
  {
    return this.m;
  }
  
  public final String j()
  {
    Locale localLocale = Locale.getDefault();
    if (localLocale != null) {
      return localLocale.getLanguage();
    }
    Logging.d("Settings", "getLanguage() obtain locale failed");
    return "";
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/settings/Settings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */