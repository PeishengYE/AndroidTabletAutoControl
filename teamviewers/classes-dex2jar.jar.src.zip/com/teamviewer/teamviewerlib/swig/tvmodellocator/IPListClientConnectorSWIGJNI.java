package com.teamviewer.teamviewerlib.swig.tvmodellocator;

import com.teamviewer.teamviewerlib.swig.tvguibackend.ClientConnectParams;

public class IPListClientConnectorSWIGJNI
{
  public static final native void IPListClientConnector_RemoteControl(long paramLong1, IPListClientConnector paramIPListClientConnector, long paramLong2, ClientConnectParams paramClientConnectParams, boolean paramBoolean, int paramInt);
  
  public static final native void IPListClientConnector_SetAdditionalConnectionParams(long paramLong1, IPListClientConnector paramIPListClientConnector, long paramLong2, ClientConnectParams paramClientConnectParams, boolean paramBoolean);
  
  public static final native void delete_IPListClientConnector(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/IPListClientConnectorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */