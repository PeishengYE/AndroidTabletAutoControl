package com.teamviewer.teamviewerlib.swig.tvmodellocator;

import com.teamviewer.teamviewerlib.swig.tvguibackend.ClientConnectParams;

public class IPListClientConnector
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IPListClientConnector(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IPListClientConnector paramIPListClientConnector)
  {
    if (paramIPListClientConnector == null) {
      return 0L;
    }
    return paramIPListClientConnector.swigCPtr;
  }
  
  public void RemoteControl(ClientConnectParams paramClientConnectParams, boolean paramBoolean, int paramInt)
  {
    IPListClientConnectorSWIGJNI.IPListClientConnector_RemoteControl(this.swigCPtr, this, ClientConnectParams.getCPtr(paramClientConnectParams), paramClientConnectParams, paramBoolean, paramInt);
  }
  
  public void SetAdditionalConnectionParams(ClientConnectParams paramClientConnectParams, boolean paramBoolean)
  {
    IPListClientConnectorSWIGJNI.IPListClientConnector_SetAdditionalConnectionParams(this.swigCPtr, this, ClientConnectParams.getCPtr(paramClientConnectParams), paramClientConnectParams, paramBoolean);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IPListClientConnectorSWIGJNI.delete_IPListClientConnector(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/IPListClientConnector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */