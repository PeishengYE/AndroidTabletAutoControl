package com.teamviewer.teamviewerlib.swig.tvmodellocator;

import com.teamviewer.teamviewerlib.swig.tvguibackend.IClientConnector;

public class ClientConnectorAndroid
  extends IClientConnector
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public ClientConnectorAndroid(long paramLong, boolean paramBoolean)
  {
    super(ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ClientConnectorAndroid paramClientConnectorAndroid)
  {
    if (paramClientConnectorAndroid == null) {
      return 0L;
    }
    return paramClientConnectorAndroid.swigCPtr;
  }
  
  public ClientConnectorAndroid.ConnectionParam GetConnectionParams()
  {
    return new ClientConnectorAndroid.ConnectionParam(ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_GetConnectionParams(this.swigCPtr, this), true);
  }
  
  public ClientConnectorAndroid.EasyAccessParams GetEasyAccessParams()
  {
    return new ClientConnectorAndroid.EasyAccessParams(ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_GetEasyAccessParams(this.swigCPtr, this), true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          ClientConnectorAndroidSWIGJNI.delete_ClientConnectorAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/ClientConnectorAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */