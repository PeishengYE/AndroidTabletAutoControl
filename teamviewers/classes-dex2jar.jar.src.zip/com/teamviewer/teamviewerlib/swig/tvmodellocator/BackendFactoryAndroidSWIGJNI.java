package com.teamviewer.teamviewerlib.swig.tvmodellocator;

public class BackendFactoryAndroidSWIGJNI
{
  public static final native long BackendFactoryAndroid_GetBackendRootAndroid();
  
  public static final native long BackendFactoryAndroid_GetClientConnector();
  
  public static final native long BackendFactoryAndroid_GetFrontendDispatcher();
  
  public static final native void delete_BackendFactoryAndroid(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/BackendFactoryAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */