package com.teamviewer.teamviewerlib.swig.tvmodellocator;

public class ClientConnectorAndroidSWIGJNI
{
  public static final native byte[] ClientConnectorAndroid_ConnectionParam_GetMyLicenseFeatureVector(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native byte[] ClientConnectorAndroid_ConnectionParam_GetPartnerLicenseFeatureVector(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_actionId_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_destClientId_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native String ClientConnectorAndroid_ConnectionParam_errorMessage_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native String ClientConnectorAndroid_ConnectionParam_routerIp_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native boolean ClientConnectorAndroid_ConnectionParam_sendStatistics_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_sessionId_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_timeoutSecs_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_transferRate_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_usedLicenseFull_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native int ClientConnectorAndroid_ConnectionParam_usedLicense_get(long paramLong, ClientConnectorAndroid.ConnectionParam paramConnectionParam);
  
  public static final native long ClientConnectorAndroid_GetConnectionParams(long paramLong, ClientConnectorAndroid paramClientConnectorAndroid);
  
  public static final native long ClientConnectorAndroid_GetEasyAccessParams(long paramLong, ClientConnectorAndroid paramClientConnectorAndroid);
  
  public static final native long ClientConnectorAndroid_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void delete_ClientConnectorAndroid(long paramLong);
  
  public static final native void delete_ClientConnectorAndroid_ConnectionParam(long paramLong);
  
  public static final native void delete_ClientConnectorAndroid_EasyAccessParams(long paramLong);
  
  public static final native long new_ClientConnectorAndroid_ConnectionParam();
  
  public static final native long new_ClientConnectorAndroid_EasyAccessParams();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/ClientConnectorAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */