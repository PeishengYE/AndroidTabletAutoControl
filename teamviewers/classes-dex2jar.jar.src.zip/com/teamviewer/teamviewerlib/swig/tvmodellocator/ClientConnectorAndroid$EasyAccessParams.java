package com.teamviewer.teamviewerlib.swig.tvmodellocator;

public class ClientConnectorAndroid$EasyAccessParams
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ClientConnectorAndroid$EasyAccessParams()
  {
    this(ClientConnectorAndroidSWIGJNI.new_ClientConnectorAndroid_EasyAccessParams(), true);
  }
  
  public ClientConnectorAndroid$EasyAccessParams(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(EasyAccessParams paramEasyAccessParams)
  {
    if (paramEasyAccessParams == null) {
      return 0L;
    }
    return paramEasyAccessParams.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ClientConnectorAndroidSWIGJNI.delete_ClientConnectorAndroid_EasyAccessParams(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/ClientConnectorAndroid$EasyAccessParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */