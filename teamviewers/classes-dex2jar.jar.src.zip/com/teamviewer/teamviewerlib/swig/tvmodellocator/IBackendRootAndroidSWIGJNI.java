package com.teamviewer.teamviewerlib.swig.tvmodellocator;

public class IBackendRootAndroidSWIGJNI
{
  public static final native long IBackendRootAndroid_GetAccount(long paramLong, IBackendRootAndroid paramIBackendRootAndroid);
  
  public static final native long IBackendRootAndroid_GetClientConnector(long paramLong, IBackendRootAndroid paramIBackendRootAndroid);
  
  public static final native long IBackendRootAndroid_GetLicensing(long paramLong, IBackendRootAndroid paramIBackendRootAndroid);
  
  public static final native void delete_IBackendRootAndroid(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/IBackendRootAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */