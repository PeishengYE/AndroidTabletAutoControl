package com.teamviewer.teamviewerlib.swig.tvmodellocator;

import com.teamviewer.teamviewerlib.swig.tvguibackend.IAccountAndroid;
import com.teamviewer.teamviewerlib.swig.tvguibackend.ILicensing;

public class IBackendRootAndroid
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IBackendRootAndroid(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IBackendRootAndroid paramIBackendRootAndroid)
  {
    if (paramIBackendRootAndroid == null) {
      return 0L;
    }
    return paramIBackendRootAndroid.swigCPtr;
  }
  
  public IAccountAndroid GetAccount()
  {
    long l = IBackendRootAndroidSWIGJNI.IBackendRootAndroid_GetAccount(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IAccountAndroid(l, true);
  }
  
  public IPListClientConnector GetClientConnector()
  {
    long l = IBackendRootAndroidSWIGJNI.IBackendRootAndroid_GetClientConnector(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IPListClientConnector(l, true);
  }
  
  public ILicensing GetLicensing()
  {
    long l = IBackendRootAndroidSWIGJNI.IBackendRootAndroid_GetLicensing(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new ILicensing(l, true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IBackendRootAndroidSWIGJNI.delete_IBackendRootAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/IBackendRootAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */