package com.teamviewer.teamviewerlib.swig.tvmodellocator;

import java.util.BitSet;
import o.chi;

public class ClientConnectorAndroid$ConnectionParam
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ClientConnectorAndroid$ConnectionParam()
  {
    this(ClientConnectorAndroidSWIGJNI.new_ClientConnectorAndroid_ConnectionParam(), true);
  }
  
  public ClientConnectorAndroid$ConnectionParam(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ConnectionParam paramConnectionParam)
  {
    if (paramConnectionParam == null) {
      return 0L;
    }
    return paramConnectionParam.swigCPtr;
  }
  
  public BitSet GetMyLicenseFeatureVector()
  {
    return chi.a(ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_GetMyLicenseFeatureVector(this.swigCPtr, this));
  }
  
  public BitSet GetPartnerLicenseFeatureVector()
  {
    return chi.a(ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_GetPartnerLicenseFeatureVector(this.swigCPtr, this));
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ClientConnectorAndroidSWIGJNI.delete_ClientConnectorAndroid_ConnectionParam(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public int getActionId()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_actionId_get(this.swigCPtr, this);
  }
  
  public int getDestClientId()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_destClientId_get(this.swigCPtr, this);
  }
  
  public String getErrorMessage()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_errorMessage_get(this.swigCPtr, this);
  }
  
  public String getRouterIp()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_routerIp_get(this.swigCPtr, this);
  }
  
  public boolean getSendStatistics()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_sendStatistics_get(this.swigCPtr, this);
  }
  
  public int getSessionId()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_sessionId_get(this.swigCPtr, this);
  }
  
  public int getTimeoutSecs()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_timeoutSecs_get(this.swigCPtr, this);
  }
  
  public int getTransferRate()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_transferRate_get(this.swigCPtr, this);
  }
  
  public int getUsedLicense()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_usedLicense_get(this.swigCPtr, this);
  }
  
  public int getUsedLicenseFull()
  {
    return ClientConnectorAndroidSWIGJNI.ClientConnectorAndroid_ConnectionParam_usedLicenseFull_get(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/ClientConnectorAndroid$ConnectionParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */