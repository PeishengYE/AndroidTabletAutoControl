package com.teamviewer.teamviewerlib.swig.tvmodellocator;

public class SWIGTYPE_p_tvclientbase__IDispatcherPtr
{
  private transient long swigCPtr;
  
  public SWIGTYPE_p_tvclientbase__IDispatcherPtr()
  {
    this.swigCPtr = 0L;
  }
  
  public SWIGTYPE_p_tvclientbase__IDispatcherPtr(long paramLong, boolean paramBoolean)
  {
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(SWIGTYPE_p_tvclientbase__IDispatcherPtr paramSWIGTYPE_p_tvclientbase__IDispatcherPtr)
  {
    if (paramSWIGTYPE_p_tvclientbase__IDispatcherPtr == null) {
      return 0L;
    }
    return paramSWIGTYPE_p_tvclientbase__IDispatcherPtr.swigCPtr;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvmodellocator/SWIGTYPE_p_tvclientbase__IDispatcherPtr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */