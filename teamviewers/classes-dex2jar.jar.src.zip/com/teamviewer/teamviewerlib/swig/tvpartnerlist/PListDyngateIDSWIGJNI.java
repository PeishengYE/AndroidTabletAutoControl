package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListDyngateIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListDyngateID paramPListDyngateID1, long paramLong2, PListDyngateID paramPListDyngateID2);
  
  public static final native boolean LessThan(long paramLong1, PListDyngateID paramPListDyngateID1, long paramLong2, PListDyngateID paramPListDyngateID2);
  
  public static final native long PListDyngateID_Assignment(long paramLong1, PListDyngateID paramPListDyngateID1, long paramLong2, PListDyngateID paramPListDyngateID2);
  
  public static final native String PListDyngateID_GetAsString(long paramLong, PListDyngateID paramPListDyngateID);
  
  public static final native long PListDyngateID_GetInternalID(long paramLong, PListDyngateID paramPListDyngateID);
  
  public static final native void PListDyngateID_Increment(long paramLong, PListDyngateID paramPListDyngateID);
  
  public static final native boolean PListDyngateID_Valid(long paramLong, PListDyngateID paramPListDyngateID);
  
  public static final native void delete_PListDyngateID(long paramLong);
  
  public static final native long new_PListDyngateID__SWIG_0();
  
  public static final native long new_PListDyngateID__SWIG_1(long paramLong);
  
  public static final native long new_PListDyngateID__SWIG_2(long paramLong, PListDyngateID paramPListDyngateID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListDyngateIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */