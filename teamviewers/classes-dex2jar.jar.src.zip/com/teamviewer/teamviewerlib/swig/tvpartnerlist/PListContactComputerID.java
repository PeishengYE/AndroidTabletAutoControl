package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListContactComputerID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListContactComputerID()
  {
    this(PListContactComputerIDSWIGJNI.new_PListContactComputerID__SWIG_0(), true);
  }
  
  public PListContactComputerID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListContactComputerID(PListContactID paramPListContactID, PListSessionID paramPListSessionID)
  {
    this(PListContactComputerIDSWIGJNI.new_PListContactComputerID__SWIG_1(PListContactID.getCPtr(paramPListContactID), paramPListContactID, PListSessionID.getCPtr(paramPListSessionID), paramPListSessionID), true);
  }
  
  public static long getCPtr(PListContactComputerID paramPListContactComputerID)
  {
    if (paramPListContactComputerID == null) {
      return 0L;
    }
    return paramPListContactComputerID.swigCPtr;
  }
  
  public PListContactID GetInternalContactID()
  {
    return new PListContactID(PListContactComputerIDSWIGJNI.PListContactComputerID_GetInternalContactID(this.swigCPtr, this), true);
  }
  
  public PListSessionID GetInternalSessionID()
  {
    return new PListSessionID(PListContactComputerIDSWIGJNI.PListContactComputerID_GetInternalSessionID(this.swigCPtr, this), true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListContactComputerIDSWIGJNI.delete_PListContactComputerID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListContactComputerID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */