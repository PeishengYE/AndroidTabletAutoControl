package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListComputerIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListComputerID paramPListComputerID1, long paramLong2, PListComputerID paramPListComputerID2);
  
  public static final native boolean LessThan(long paramLong1, PListComputerID paramPListComputerID1, long paramLong2, PListComputerID paramPListComputerID2);
  
  public static final native long PListComputerID_Assignment(long paramLong1, PListComputerID paramPListComputerID1, long paramLong2, PListComputerID paramPListComputerID2);
  
  public static final native String PListComputerID_GetAsString(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native long PListComputerID_GetInternalID(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native void PListComputerID_Increment(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native boolean PListComputerID_Valid(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native void delete_PListComputerID(long paramLong);
  
  public static final native long new_PListComputerID__SWIG_0();
  
  public static final native long new_PListComputerID__SWIG_1(long paramLong);
  
  public static final native long new_PListComputerID__SWIG_2(long paramLong, PListComputerID paramPListComputerID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListComputerIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */