package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListGroupIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListGroupID paramPListGroupID1, long paramLong2, PListGroupID paramPListGroupID2);
  
  public static final native boolean LessThan(long paramLong1, PListGroupID paramPListGroupID1, long paramLong2, PListGroupID paramPListGroupID2);
  
  public static final native boolean NotEqual(long paramLong1, PListGroupID paramPListGroupID1, long paramLong2, PListGroupID paramPListGroupID2);
  
  public static final native long PListGroupID_Assignment(long paramLong1, PListGroupID paramPListGroupID1, long paramLong2, PListGroupID paramPListGroupID2);
  
  public static final native String PListGroupID_GetAsString(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native long PListGroupID_GetInternalID(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native void PListGroupID_Increment(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native boolean PListGroupID_Valid(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native void delete_PListGroupID(long paramLong);
  
  public static final native long new_PListGroupID__SWIG_0();
  
  public static final native long new_PListGroupID__SWIG_1(long paramLong);
  
  public static final native long new_PListGroupID__SWIG_2(long paramLong, PListGroupID paramPListGroupID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListGroupIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */