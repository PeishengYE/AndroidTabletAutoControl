package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListContactIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListContactID paramPListContactID1, long paramLong2, PListContactID paramPListContactID2);
  
  public static final native boolean LessThan(long paramLong1, PListContactID paramPListContactID1, long paramLong2, PListContactID paramPListContactID2);
  
  public static final native long PListContactID_Assignment(long paramLong1, PListContactID paramPListContactID1, long paramLong2, PListContactID paramPListContactID2);
  
  public static final native String PListContactID_GetAsString(long paramLong, PListContactID paramPListContactID);
  
  public static final native long PListContactID_GetInternalID(long paramLong, PListContactID paramPListContactID);
  
  public static final native void PListContactID_Increment(long paramLong, PListContactID paramPListContactID);
  
  public static final native boolean PListContactID_Valid(long paramLong, PListContactID paramPListContactID);
  
  public static final native void delete_PListContactID(long paramLong);
  
  public static final native long new_PListContactID__SWIG_0();
  
  public static final native long new_PListContactID__SWIG_1(long paramLong);
  
  public static final native long new_PListContactID__SWIG_2(long paramLong, PListContactID paramPListContactID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListContactIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */