package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListGroupID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListGroupID()
  {
    this(PListGroupIDSWIGJNI.new_PListGroupID__SWIG_0(), true);
  }
  
  public PListGroupID(long paramLong)
  {
    this(PListGroupIDSWIGJNI.new_PListGroupID__SWIG_1(paramLong), true);
  }
  
  public PListGroupID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListGroupID(PListGroupID paramPListGroupID)
  {
    this(PListGroupIDSWIGJNI.new_PListGroupID__SWIG_2(getCPtr(paramPListGroupID), paramPListGroupID), true);
  }
  
  public static long getCPtr(PListGroupID paramPListGroupID)
  {
    if (paramPListGroupID == null) {
      return 0L;
    }
    return paramPListGroupID.swigCPtr;
  }
  
  public PListGroupID Assignment(PListGroupID paramPListGroupID)
  {
    return new PListGroupID(PListGroupIDSWIGJNI.PListGroupID_Assignment(this.swigCPtr, this, getCPtr(paramPListGroupID), paramPListGroupID), false);
  }
  
  public String GetAsString()
  {
    return PListGroupIDSWIGJNI.PListGroupID_GetAsString(this.swigCPtr, this);
  }
  
  public long GetInternalID()
  {
    return PListGroupIDSWIGJNI.PListGroupID_GetInternalID(this.swigCPtr, this);
  }
  
  public void Increment()
  {
    PListGroupIDSWIGJNI.PListGroupID_Increment(this.swigCPtr, this);
  }
  
  public boolean Valid()
  {
    return PListGroupIDSWIGJNI.PListGroupID_Valid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListGroupIDSWIGJNI.delete_PListGroupID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListGroupID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */