package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListAccountID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListAccountID()
  {
    this(PListAccountIDSWIGJNI.new_PListAccountID__SWIG_0(), true);
  }
  
  public PListAccountID(long paramLong)
  {
    this(PListAccountIDSWIGJNI.new_PListAccountID__SWIG_1(paramLong), true);
  }
  
  public PListAccountID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListAccountID(PListAccountID paramPListAccountID)
  {
    this(PListAccountIDSWIGJNI.new_PListAccountID__SWIG_2(getCPtr(paramPListAccountID), paramPListAccountID), true);
  }
  
  public static long getCPtr(PListAccountID paramPListAccountID)
  {
    if (paramPListAccountID == null) {
      return 0L;
    }
    return paramPListAccountID.swigCPtr;
  }
  
  public PListAccountID Assignment(PListAccountID paramPListAccountID)
  {
    return new PListAccountID(PListAccountIDSWIGJNI.PListAccountID_Assignment(this.swigCPtr, this, getCPtr(paramPListAccountID), paramPListAccountID), false);
  }
  
  public String GetAsString()
  {
    return PListAccountIDSWIGJNI.PListAccountID_GetAsString(this.swigCPtr, this);
  }
  
  public long GetInternalID()
  {
    return PListAccountIDSWIGJNI.PListAccountID_GetInternalID(this.swigCPtr, this);
  }
  
  public void Increment()
  {
    PListAccountIDSWIGJNI.PListAccountID_Increment(this.swigCPtr, this);
  }
  
  public boolean Valid()
  {
    return PListAccountIDSWIGJNI.PListAccountID_Valid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListAccountIDSWIGJNI.delete_PListAccountID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListAccountID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */