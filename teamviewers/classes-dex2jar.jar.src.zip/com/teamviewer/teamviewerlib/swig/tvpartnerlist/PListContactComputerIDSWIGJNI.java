package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListContactComputerIDSWIGJNI
{
  public static final native boolean Equal__SWIG_2(long paramLong1, PListContactComputerID paramPListContactComputerID1, long paramLong2, PListContactComputerID paramPListContactComputerID2);
  
  public static final native boolean LessThan__SWIG_2(long paramLong1, PListContactComputerID paramPListContactComputerID1, long paramLong2, PListContactComputerID paramPListContactComputerID2);
  
  public static final native long PListContactComputerID_GetInternalContactID(long paramLong, PListContactComputerID paramPListContactComputerID);
  
  public static final native long PListContactComputerID_GetInternalSessionID(long paramLong, PListContactComputerID paramPListContactComputerID);
  
  public static final native void delete_PListContactComputerID(long paramLong);
  
  public static final native long new_PListContactComputerID__SWIG_0();
  
  public static final native long new_PListContactComputerID__SWIG_1(long paramLong1, PListContactID paramPListContactID, long paramLong2, PListSessionID paramPListSessionID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListContactComputerIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */