package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListComputerID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListComputerID()
  {
    this(PListComputerIDSWIGJNI.new_PListComputerID__SWIG_0(), true);
  }
  
  public PListComputerID(long paramLong)
  {
    this(PListComputerIDSWIGJNI.new_PListComputerID__SWIG_1(paramLong), true);
  }
  
  public PListComputerID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListComputerID(PListComputerID paramPListComputerID)
  {
    this(PListComputerIDSWIGJNI.new_PListComputerID__SWIG_2(getCPtr(paramPListComputerID), paramPListComputerID), true);
  }
  
  public static long getCPtr(PListComputerID paramPListComputerID)
  {
    if (paramPListComputerID == null) {
      return 0L;
    }
    return paramPListComputerID.swigCPtr;
  }
  
  public PListComputerID Assignment(PListComputerID paramPListComputerID)
  {
    return new PListComputerID(PListComputerIDSWIGJNI.PListComputerID_Assignment(this.swigCPtr, this, getCPtr(paramPListComputerID), paramPListComputerID), false);
  }
  
  public String GetAsString()
  {
    return PListComputerIDSWIGJNI.PListComputerID_GetAsString(this.swigCPtr, this);
  }
  
  public long GetInternalID()
  {
    return PListComputerIDSWIGJNI.PListComputerID_GetInternalID(this.swigCPtr, this);
  }
  
  public void Increment()
  {
    PListComputerIDSWIGJNI.PListComputerID_Increment(this.swigCPtr, this);
  }
  
  public boolean Valid()
  {
    return PListComputerIDSWIGJNI.PListComputerID_Valid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListComputerIDSWIGJNI.delete_PListComputerID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListComputerID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */