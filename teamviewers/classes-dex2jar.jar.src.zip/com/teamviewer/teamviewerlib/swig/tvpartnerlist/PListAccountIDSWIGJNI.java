package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListAccountIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListAccountID paramPListAccountID1, long paramLong2, PListAccountID paramPListAccountID2);
  
  public static final native boolean LessThan(long paramLong1, PListAccountID paramPListAccountID1, long paramLong2, PListAccountID paramPListAccountID2);
  
  public static final native long PListAccountID_Assignment(long paramLong1, PListAccountID paramPListAccountID1, long paramLong2, PListAccountID paramPListAccountID2);
  
  public static final native String PListAccountID_GetAsString(long paramLong, PListAccountID paramPListAccountID);
  
  public static final native long PListAccountID_GetInternalID(long paramLong, PListAccountID paramPListAccountID);
  
  public static final native void PListAccountID_Increment(long paramLong, PListAccountID paramPListAccountID);
  
  public static final native boolean PListAccountID_Valid(long paramLong, PListAccountID paramPListAccountID);
  
  public static final native void delete_PListAccountID(long paramLong);
  
  public static final native long new_PListAccountID__SWIG_0();
  
  public static final native long new_PListAccountID__SWIG_1(long paramLong);
  
  public static final native long new_PListAccountID__SWIG_2(long paramLong, PListAccountID paramPListAccountID);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListAccountIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */