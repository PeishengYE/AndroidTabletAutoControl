package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListDyngateID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListDyngateID()
  {
    this(PListDyngateIDSWIGJNI.new_PListDyngateID__SWIG_0(), true);
  }
  
  public PListDyngateID(long paramLong)
  {
    this(PListDyngateIDSWIGJNI.new_PListDyngateID__SWIG_1(paramLong), true);
  }
  
  public PListDyngateID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListDyngateID(PListDyngateID paramPListDyngateID)
  {
    this(PListDyngateIDSWIGJNI.new_PListDyngateID__SWIG_2(getCPtr(paramPListDyngateID), paramPListDyngateID), true);
  }
  
  public static long getCPtr(PListDyngateID paramPListDyngateID)
  {
    if (paramPListDyngateID == null) {
      return 0L;
    }
    return paramPListDyngateID.swigCPtr;
  }
  
  public PListDyngateID Assignment(PListDyngateID paramPListDyngateID)
  {
    return new PListDyngateID(PListDyngateIDSWIGJNI.PListDyngateID_Assignment(this.swigCPtr, this, getCPtr(paramPListDyngateID), paramPListDyngateID), false);
  }
  
  public String GetAsString()
  {
    return PListDyngateIDSWIGJNI.PListDyngateID_GetAsString(this.swigCPtr, this);
  }
  
  public long GetInternalID()
  {
    return PListDyngateIDSWIGJNI.PListDyngateID_GetInternalID(this.swigCPtr, this);
  }
  
  public void Increment()
  {
    PListDyngateIDSWIGJNI.PListDyngateID_Increment(this.swigCPtr, this);
  }
  
  public boolean Valid()
  {
    return PListDyngateIDSWIGJNI.PListDyngateID_Valid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListDyngateIDSWIGJNI.delete_PListDyngateID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListDyngateID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */