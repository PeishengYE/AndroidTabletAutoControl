package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListSessionID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListSessionID(long paramLong)
  {
    this(PListSessionIDSWIGJNI.new_PListSessionID(paramLong), true);
  }
  
  public PListSessionID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(PListSessionID paramPListSessionID)
  {
    if (paramPListSessionID == null) {
      return 0L;
    }
    return paramPListSessionID.swigCPtr;
  }
  
  public long GetInternalID()
  {
    return PListSessionIDSWIGJNI.PListSessionID_GetInternalID(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListSessionIDSWIGJNI.delete_PListSessionID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListSessionID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */