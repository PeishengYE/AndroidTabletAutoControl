package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListSessionIDSWIGJNI
{
  public static final native boolean Equal(long paramLong1, PListSessionID paramPListSessionID1, long paramLong2, PListSessionID paramPListSessionID2);
  
  public static final native boolean GreaterThan(long paramLong1, PListSessionID paramPListSessionID1, long paramLong2, PListSessionID paramPListSessionID2);
  
  public static final native boolean LessThan(long paramLong1, PListSessionID paramPListSessionID1, long paramLong2, PListSessionID paramPListSessionID2);
  
  public static final native long PListSessionID_GetInternalID(long paramLong, PListSessionID paramPListSessionID);
  
  public static final native void delete_PListSessionID(long paramLong);
  
  public static final native long new_PListSessionID(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListSessionIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */