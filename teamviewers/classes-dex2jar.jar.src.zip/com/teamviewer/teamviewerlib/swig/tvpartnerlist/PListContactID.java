package com.teamviewer.teamviewerlib.swig.tvpartnerlist;

public class PListContactID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PListContactID()
  {
    this(PListContactIDSWIGJNI.new_PListContactID__SWIG_0(), true);
  }
  
  public PListContactID(long paramLong)
  {
    this(PListContactIDSWIGJNI.new_PListContactID__SWIG_1(paramLong), true);
  }
  
  public PListContactID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public PListContactID(PListContactID paramPListContactID)
  {
    this(PListContactIDSWIGJNI.new_PListContactID__SWIG_2(getCPtr(paramPListContactID), paramPListContactID), true);
  }
  
  public static long getCPtr(PListContactID paramPListContactID)
  {
    if (paramPListContactID == null) {
      return 0L;
    }
    return paramPListContactID.swigCPtr;
  }
  
  public PListContactID Assignment(PListContactID paramPListContactID)
  {
    return new PListContactID(PListContactIDSWIGJNI.PListContactID_Assignment(this.swigCPtr, this, getCPtr(paramPListContactID), paramPListContactID), false);
  }
  
  public String GetAsString()
  {
    return PListContactIDSWIGJNI.PListContactID_GetAsString(this.swigCPtr, this);
  }
  
  public long GetInternalID()
  {
    return PListContactIDSWIGJNI.PListContactID_GetInternalID(this.swigCPtr, this);
  }
  
  public void Increment()
  {
    PListContactIDSWIGJNI.PListContactID_Increment(this.swigCPtr, this);
  }
  
  public boolean Valid()
  {
    return PListContactIDSWIGJNI.PListContactID_Valid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PListContactIDSWIGJNI.delete_PListContactID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvpartnerlist/PListContactID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */