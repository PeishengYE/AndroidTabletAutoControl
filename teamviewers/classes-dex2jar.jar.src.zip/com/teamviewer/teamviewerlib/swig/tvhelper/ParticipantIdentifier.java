package com.teamviewer.teamviewerlib.swig.tvhelper;

public class ParticipantIdentifier
{
  public static final ParticipantIdentifier PARTICIPANT_ID_UNKNOWN = ;
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ParticipantIdentifier()
  {
    this(ParticipantIdentifierSWIGJNI.new_ParticipantIdentifier__SWIG_2(), true);
  }
  
  public ParticipantIdentifier(long paramLong)
  {
    this(ParticipantIdentifierSWIGJNI.new_ParticipantIdentifier__SWIG_1(paramLong), true);
  }
  
  public ParticipantIdentifier(long paramLong, int paramInt)
  {
    this(ParticipantIdentifierSWIGJNI.new_ParticipantIdentifier__SWIG_0(paramLong, paramInt), true);
  }
  
  public ParticipantIdentifier(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ParticipantIdentifier paramParticipantIdentifier)
  {
    if (paramParticipantIdentifier == null) {
      return 0L;
    }
    return paramParticipantIdentifier.swigCPtr;
  }
  
  private static ParticipantIdentifier getParticipantID_UNKNOWN()
  {
    long l = ParticipantIdentifierSWIGJNI.ParticipantIdentifier_ParticipantID_UNKNOWN_get();
    if (l == 0L) {
      return null;
    }
    return new ParticipantIdentifier(l, false);
  }
  
  public boolean Equal(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_Equal(this.swigCPtr, this, getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsValid()
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_IsValid(this.swigCPtr, this);
  }
  
  public boolean LessThan(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_LessThan(this.swigCPtr, this, getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean NotEqual(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_NotEqual(this.swigCPtr, this, getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantIdentifierSWIGJNI.delete_ParticipantIdentifier(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {}
    do
    {
      return true;
      if (!(paramObject instanceof ParticipantIdentifier)) {
        break;
      }
    } while (((ParticipantIdentifier)paramObject).getValue() == getValue());
    return false;
    return false;
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long getDynGateID()
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_getDynGateID(this.swigCPtr, this);
  }
  
  public int getSessionID()
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_getSessionID(this.swigCPtr, this);
  }
  
  public long getValue()
  {
    return ParticipantIdentifierSWIGJNI.ParticipantIdentifier_Value_get(this.swigCPtr, this);
  }
  
  public int hashCode()
  {
    long l = getValue();
    return (int)(l ^ l >>> 32);
  }
  
  public String toString()
  {
    return "[" + getDynGateID() + ", " + getSessionID() + "]";
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/ParticipantIdentifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */