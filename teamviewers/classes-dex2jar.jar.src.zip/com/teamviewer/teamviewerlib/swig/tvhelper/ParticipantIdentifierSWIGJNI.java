package com.teamviewer.teamviewerlib.swig.tvhelper;

public class ParticipantIdentifierSWIGJNI
{
  public static final native boolean ParticipantIdentifier_Equal(long paramLong1, ParticipantIdentifier paramParticipantIdentifier1, long paramLong2, ParticipantIdentifier paramParticipantIdentifier2);
  
  public static final native boolean ParticipantIdentifier_IsValid(long paramLong, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean ParticipantIdentifier_LessThan(long paramLong1, ParticipantIdentifier paramParticipantIdentifier1, long paramLong2, ParticipantIdentifier paramParticipantIdentifier2);
  
  public static final native boolean ParticipantIdentifier_NotEqual(long paramLong1, ParticipantIdentifier paramParticipantIdentifier1, long paramLong2, ParticipantIdentifier paramParticipantIdentifier2);
  
  public static final native long ParticipantIdentifier_ParticipantID_UNKNOWN_get();
  
  public static final native long ParticipantIdentifier_Value_get(long paramLong, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long ParticipantIdentifier_getDynGateID(long paramLong, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native int ParticipantIdentifier_getSessionID(long paramLong, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native void delete_ParticipantIdentifier(long paramLong);
  
  public static final native long new_ParticipantIdentifier__SWIG_0(long paramLong, int paramInt);
  
  public static final native long new_ParticipantIdentifier__SWIG_1(long paramLong);
  
  public static final native long new_ParticipantIdentifier__SWIG_2();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/ParticipantIdentifierSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */