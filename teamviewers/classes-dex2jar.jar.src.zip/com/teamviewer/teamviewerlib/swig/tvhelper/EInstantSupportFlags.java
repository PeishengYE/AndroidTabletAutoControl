package com.teamviewer.teamviewerlib.swig.tvhelper;

public final class EInstantSupportFlags
{
  public static final int SupportSession_Customer = 2;
  public static final int SupportSession_ShowWaitingRoom = 4;
  public static final int SupportSession_Supporter = 1;
  public static final int SupportSession_Undefined = 0;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/EInstantSupportFlags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */