package com.teamviewer.teamviewerlib.swig.tvhelper;

public final class StreamType
{
  public static final int StreamType_Audio = 3;
  public static final int StreamType_Chat = 5;
  public static final int StreamType_Clipboard = 24;
  public static final int StreamType_DragDrop = 9;
  public static final int StreamType_File = 6;
  public static final int StreamType_FileBox = 8;
  public static final int StreamType_Last = 27;
  public static final int StreamType_Misc = 1;
  public static final int StreamType_Print = 13;
  public static final int StreamType_RS_Apps = 17;
  public static final int StreamType_RS_Chat = 22;
  public static final int StreamType_RS_Configuration = 19;
  public static final int StreamType_RS_Legacy = 23;
  public static final int StreamType_RS_Logs = 20;
  public static final int StreamType_RS_Misc = 15;
  public static final int StreamType_RS_Monitoring = 16;
  public static final int StreamType_RS_Processes = 18;
  public static final int StreamType_RS_Screenshot = 21;
  public static final int StreamType_RemoteAudio = 11;
  public static final int StreamType_RemoteAudioControl = 12;
  public static final int StreamType_RemoteSupport = 14;
  public static final int StreamType_Screen = 2;
  public static final int StreamType_ScreenVideo = 10;
  public static final int StreamType_Unknown = 0;
  public static final int StreamType_VPN = 7;
  public static final int StreamType_Video = 4;
  public static final int StreamType_VoIP_Control = 25;
  public static final int StreamType_VoIP_Data = 26;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/StreamType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */