package com.teamviewer.teamviewerlib.swig.tvhelper;

import java.math.BigInteger;

public class CParticipant
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public CParticipant(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public CParticipant(CParticipant paramCParticipant)
  {
    this(ParticipantSWIGJNI.new_CParticipant__SWIG_1(getCPtr(paramCParticipant), paramCParticipant), true);
  }
  
  public CParticipant(ParticipantIdentifier paramParticipantIdentifier)
  {
    this(ParticipantSWIGJNI.new_CParticipant__SWIG_0(ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier), true);
  }
  
  public static int RoleToIndex(int paramInt)
  {
    return ParticipantSWIGJNI.CParticipant_RoleToIndex(paramInt);
  }
  
  public static long getCPtr(CParticipant paramCParticipant)
  {
    if (paramCParticipant == null) {
      return 0L;
    }
    return paramCParticipant.swigCPtr;
  }
  
  public CParticipant Assignment(CParticipant paramCParticipant)
  {
    return new CParticipant(ParticipantSWIGJNI.CParticipant_Assignment(this.swigCPtr, this, getCPtr(paramCParticipant), paramCParticipant), false);
  }
  
  public String GetAccountPictureURL()
  {
    return ParticipantSWIGJNI.CParticipant_GetAccountPictureURL(this.swigCPtr, this);
  }
  
  public long GetCompatibilityFlags()
  {
    return ParticipantSWIGJNI.CParticipant_GetCompatibilityFlags(this.swigCPtr, this);
  }
  
  public ParticipantIdentifier GetID()
  {
    return new ParticipantIdentifier(ParticipantSWIGJNI.CParticipant_GetID(this.swigCPtr, this), true);
  }
  
  public String GetName()
  {
    return ParticipantSWIGJNI.CParticipant_GetName(this.swigCPtr, this);
  }
  
  public BigInteger GetSupportedStreamCompression()
  {
    return ParticipantSWIGJNI.CParticipant_GetSupportedStreamCompression(this.swigCPtr, this);
  }
  
  public long GetSupportedStreamFeatures(int paramInt)
  {
    return ParticipantSWIGJNI.CParticipant_GetSupportedStreamFeatures(this.swigCPtr, this, paramInt);
  }
  
  public int GetType()
  {
    return ParticipantSWIGJNI.CParticipant_GetType(this.swigCPtr, this);
  }
  
  public boolean IsFullyCompatible(long paramLong)
  {
    return ParticipantSWIGJNI.CParticipant_IsFullyCompatible(this.swigCPtr, this, paramLong);
  }
  
  public boolean IsOfType(int paramInt)
  {
    return ParticipantSWIGJNI.CParticipant_IsOfType(this.swigCPtr, this, paramInt);
  }
  
  public boolean IsOrganizer()
  {
    return ParticipantSWIGJNI.CParticipant_IsOrganizer(this.swigCPtr, this);
  }
  
  public boolean IsPresenter()
  {
    return ParticipantSWIGJNI.CParticipant_IsPresenter(this.swigCPtr, this);
  }
  
  public boolean IsValid()
  {
    return ParticipantSWIGJNI.CParticipant_IsValid(this.swigCPtr, this);
  }
  
  public boolean IsVisible()
  {
    return ParticipantSWIGJNI.CParticipant_IsVisible(this.swigCPtr, this);
  }
  
  public void SetAccountPictureURL(String paramString)
  {
    ParticipantSWIGJNI.CParticipant_SetAccountPictureURL(this.swigCPtr, this, paramString);
  }
  
  public void SetName(String paramString)
  {
    ParticipantSWIGJNI.CParticipant_SetName(this.swigCPtr, this, paramString);
  }
  
  public void SetOrganizer(boolean paramBoolean)
  {
    ParticipantSWIGJNI.CParticipant_SetOrganizer(this.swigCPtr, this, paramBoolean);
  }
  
  public void SetParticipantType(int paramInt)
  {
    ParticipantSWIGJNI.CParticipant_SetParticipantType(this.swigCPtr, this, paramInt);
  }
  
  public void SetPresenter(boolean paramBoolean)
  {
    ParticipantSWIGJNI.CParticipant_SetPresenter(this.swigCPtr, this, paramBoolean);
  }
  
  public void SetVisible(boolean paramBoolean)
  {
    ParticipantSWIGJNI.CParticipant_SetVisible(this.swigCPtr, this, paramBoolean);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantSWIGJNI.delete_CParticipant(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/CParticipant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */