package com.teamviewer.teamviewerlib.swig.tvhelper;

public class DataStreamSWIGJNI
{
  public static final native long DataStream_Assignment(long paramLong1, DataStream paramDataStream1, long paramLong2, DataStream paramDataStream2);
  
  public static final native long DataStream_RequiredFeatures_get(long paramLong, DataStream paramDataStream);
  
  public static final native void DataStream_RequiredFeatures_set(long paramLong1, DataStream paramDataStream, long paramLong2);
  
  public static final native long DataStream_StreamID_get(long paramLong, DataStream paramDataStream);
  
  public static final native void DataStream_StreamID_set(long paramLong1, DataStream paramDataStream, long paramLong2);
  
  public static final native int DataStream_StreamType_get(long paramLong, DataStream paramDataStream);
  
  public static final native void DataStream_StreamType_set(long paramLong, DataStream paramDataStream, int paramInt);
  
  public static final native void delete_DataStream(long paramLong);
  
  public static final native long new_DataStream__SWIG_0();
  
  public static final native long new_DataStream__SWIG_1(long paramLong, DataStream paramDataStream);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/DataStreamSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */