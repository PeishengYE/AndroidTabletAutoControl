package com.teamviewer.teamviewerlib.swig.tvhelper;

public final class KnownStreams
{
  public static final int DefaultStream_Audio = 4;
  public static final int DefaultStream_Chat = 6;
  public static final int DefaultStream_File = 7;
  public static final int DefaultStream_Misc = 2;
  public static final int DefaultStream_Screen = 3;
  public static final int DefaultStream_VPN = 8;
  public static final int DefaultStream_Video = 5;
  public static final int KnownStream_MaxIndex = 9;
  public static final int PrivateStream = 1;
  public static final int UnknownStream = 0;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/KnownStreams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */