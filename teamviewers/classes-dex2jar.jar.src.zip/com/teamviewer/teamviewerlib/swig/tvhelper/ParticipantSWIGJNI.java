package com.teamviewer.teamviewerlib.swig.tvhelper;

import java.math.BigInteger;

public class ParticipantSWIGJNI
{
  public static final native long CParticipant_Assignment(long paramLong1, CParticipant paramCParticipant1, long paramLong2, CParticipant paramCParticipant2);
  
  public static final native String CParticipant_GetAccountPictureURL(long paramLong, CParticipant paramCParticipant);
  
  public static final native long CParticipant_GetCompatibilityFlags(long paramLong, CParticipant paramCParticipant);
  
  public static final native long CParticipant_GetID(long paramLong, CParticipant paramCParticipant);
  
  public static final native String CParticipant_GetName(long paramLong, CParticipant paramCParticipant);
  
  public static final native BigInteger CParticipant_GetSupportedStreamCompression(long paramLong, CParticipant paramCParticipant);
  
  public static final native long CParticipant_GetSupportedStreamFeatures(long paramLong, CParticipant paramCParticipant, int paramInt);
  
  public static final native int CParticipant_GetType(long paramLong, CParticipant paramCParticipant);
  
  public static final native boolean CParticipant_IsFullyCompatible(long paramLong1, CParticipant paramCParticipant, long paramLong2);
  
  public static final native boolean CParticipant_IsOfType(long paramLong, CParticipant paramCParticipant, int paramInt);
  
  public static final native boolean CParticipant_IsOrganizer(long paramLong, CParticipant paramCParticipant);
  
  public static final native boolean CParticipant_IsPresenter(long paramLong, CParticipant paramCParticipant);
  
  public static final native boolean CParticipant_IsValid(long paramLong, CParticipant paramCParticipant);
  
  public static final native boolean CParticipant_IsVisible(long paramLong, CParticipant paramCParticipant);
  
  public static final native int CParticipant_RoleToIndex(int paramInt);
  
  public static final native void CParticipant_SetAccountPictureURL(long paramLong, CParticipant paramCParticipant, String paramString);
  
  public static final native void CParticipant_SetName(long paramLong, CParticipant paramCParticipant, String paramString);
  
  public static final native void CParticipant_SetOrganizer(long paramLong, CParticipant paramCParticipant, boolean paramBoolean);
  
  public static final native void CParticipant_SetParticipantType(long paramLong, CParticipant paramCParticipant, int paramInt);
  
  public static final native void CParticipant_SetPresenter(long paramLong, CParticipant paramCParticipant, boolean paramBoolean);
  
  public static final native void CParticipant_SetVisible(long paramLong, CParticipant paramCParticipant, boolean paramBoolean);
  
  public static final native void delete_CParticipant(long paramLong);
  
  public static final native long new_CParticipant__SWIG_0(long paramLong, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long new_CParticipant__SWIG_1(long paramLong, CParticipant paramCParticipant);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/ParticipantSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */