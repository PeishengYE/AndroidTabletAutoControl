package com.teamviewer.teamviewerlib.swig.tvhelper;

public class DataStream
{
  public static final int STREAM_ID_UNKNOWN = 0;
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public DataStream()
  {
    this(DataStreamSWIGJNI.new_DataStream__SWIG_0(), true);
  }
  
  public DataStream(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public DataStream(DataStream paramDataStream)
  {
    this(DataStreamSWIGJNI.new_DataStream__SWIG_1(getCPtr(paramDataStream), paramDataStream), true);
  }
  
  public static long getCPtr(DataStream paramDataStream)
  {
    if (paramDataStream == null) {
      return 0L;
    }
    return paramDataStream.swigCPtr;
  }
  
  public DataStream Assignment(DataStream paramDataStream)
  {
    return new DataStream(DataStreamSWIGJNI.DataStream_Assignment(this.swigCPtr, this, getCPtr(paramDataStream), paramDataStream), false);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          DataStreamSWIGJNI.delete_DataStream(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long getRequiredFeatures()
  {
    return DataStreamSWIGJNI.DataStream_RequiredFeatures_get(this.swigCPtr, this);
  }
  
  public long getStreamID()
  {
    return DataStreamSWIGJNI.DataStream_StreamID_get(this.swigCPtr, this);
  }
  
  public int getStreamType()
  {
    return DataStreamSWIGJNI.DataStream_StreamType_get(this.swigCPtr, this);
  }
  
  public void setRequiredFeatures(long paramLong)
  {
    DataStreamSWIGJNI.DataStream_RequiredFeatures_set(this.swigCPtr, this, paramLong);
  }
  
  public void setStreamID(long paramLong)
  {
    DataStreamSWIGJNI.DataStream_StreamID_set(this.swigCPtr, this, paramLong);
  }
  
  public void setStreamType(int paramInt)
  {
    DataStreamSWIGJNI.DataStream_StreamType_set(this.swigCPtr, this, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/DataStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */