package com.teamviewer.teamviewerlib.swig.tvhelper;

public final class StreamCompression
{
  public static final int LZ4 = 9;
  public static final int None = 1;
  public static final int Undefined = 0;
  public static final int ZLibLevel0 = 8;
  public static final int ZLibLevel1 = 6;
  public static final int ZLibLevel1RLE = 7;
  public static final int ZLibLevel3 = 4;
  public static final int ZLibLevel3RLE = 5;
  public static final int ZLibLevel6 = 3;
  public static final int ZLibLevel9 = 2;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvhelper/StreamCompression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */