package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class ServiceCaseViewModelSWIGJNI
{
  public static final native void ServiceCaseViewModel_CloseCase(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native String ServiceCaseViewModel_GetAssignee(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native int ServiceCaseViewModel_GetAssigneeID(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native String ServiceCaseViewModel_GetDescription(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native String ServiceCaseViewModel_GetDisplayID(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native String ServiceCaseViewModel_GetGroup(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native int ServiceCaseViewModel_GetGroupID(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native int ServiceCaseViewModel_GetID(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native String ServiceCaseViewModel_GetName(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native boolean ServiceCaseViewModel_IsCloseAllowed(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native boolean ServiceCaseViewModel_IsEditableByMe(long paramLong, ServiceCaseViewModel paramServiceCaseViewModel);
  
  public static final native void ServiceCaseViewModel_UpdateNote(long paramLong1, ServiceCaseViewModel paramServiceCaseViewModel, String paramString, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void delete_ServiceCaseViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */