package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class LogoutViewModelSWIGJNI
{
  public static final native boolean LogoutViewModel_IsEnabled(long paramLong, LogoutViewModel paramLogoutViewModel);
  
  public static final native void LogoutViewModel_LogOut(long paramLong1, LogoutViewModel paramLogoutViewModel, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native long LogoutViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void delete_LogoutViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/LogoutViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */