package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class ManagedDeviceViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ManagedDeviceViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ManagedDeviceViewModel paramManagedDeviceViewModel)
  {
    if (paramManagedDeviceViewModel == null) {
      return 0L;
    }
    return paramManagedDeviceViewModel.swigCPtr;
  }
  
  public String GetManagementId()
  {
    return ManagedDeviceViewModelSWIGJNI.ManagedDeviceViewModel_GetManagementId(this.swigCPtr, this);
  }
  
  public boolean IsEasyAccessEnabled()
  {
    return ManagedDeviceViewModelSWIGJNI.ManagedDeviceViewModel_IsEasyAccessEnabled(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ManagedDeviceViewModelSWIGJNI.delete_ManagedDeviceViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ManagedDeviceViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */