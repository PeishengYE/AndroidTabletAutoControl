package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public enum GroupSharingStatus
{
  NotShared,  Shared,  SharedAndOwned;
  
  private final int swigValue;
  
  private GroupSharingStatus()
  {
    this.swigValue = GroupSharingStatus.SwigNext.access$008();
  }
  
  private GroupSharingStatus(int paramInt)
  {
    this.swigValue = paramInt;
    GroupSharingStatus.SwigNext.access$002(paramInt + 1);
  }
  
  private GroupSharingStatus(GroupSharingStatus paramGroupSharingStatus)
  {
    this.swigValue = paramGroupSharingStatus.swigValue;
    GroupSharingStatus.SwigNext.access$002(this.swigValue + 1);
  }
  
  public static GroupSharingStatus swigToEnum(int paramInt)
  {
    GroupSharingStatus[] arrayOfGroupSharingStatus = (GroupSharingStatus[])GroupSharingStatus.class.getEnumConstants();
    if ((paramInt < arrayOfGroupSharingStatus.length) && (paramInt >= 0) && (arrayOfGroupSharingStatus[paramInt].swigValue == paramInt)) {
      return arrayOfGroupSharingStatus[paramInt];
    }
    int j = arrayOfGroupSharingStatus.length;
    int i = 0;
    while (i < j)
    {
      GroupSharingStatus localGroupSharingStatus = arrayOfGroupSharingStatus[i];
      if (localGroupSharingStatus.swigValue == paramInt) {
        return localGroupSharingStatus;
      }
      i += 1;
    }
    throw new IllegalArgumentException("No enum " + GroupSharingStatus.class + " with value " + paramInt);
  }
  
  public final int swigValue()
  {
    return this.swigValue;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupSharingStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */