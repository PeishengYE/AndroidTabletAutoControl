package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;

public class GroupListElementViewModelSWIGJNI
{
  public static final native int GroupListElementViewModel_Compare(long paramLong1, GroupListElementViewModel paramGroupListElementViewModel, long paramLong2, IComparable paramIComparable);
  
  public static final native int GroupListElementViewModel_GetGroupSharingStatus(long paramLong, GroupListElementViewModel paramGroupListElementViewModel);
  
  public static final native long GroupListElementViewModel_GetID(long paramLong, GroupListElementViewModel paramGroupListElementViewModel);
  
  public static final native String GroupListElementViewModel_GetName(long paramLong, GroupListElementViewModel paramGroupListElementViewModel);
  
  public static final native void GroupListElementViewModel_RegisterForChanges(long paramLong1, GroupListElementViewModel paramGroupListElementViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native long GroupListElementViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void delete_GroupListElementViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupListElementViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */