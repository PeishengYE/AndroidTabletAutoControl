package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvguibackend.LoginState;

public class LoginViewModel
  extends AccountViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public LoginViewModel(long paramLong, boolean paramBoolean)
  {
    super(LoginViewModelSWIGJNI.LoginViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(LoginViewModel paramLoginViewModel)
  {
    if (paramLoginViewModel == null) {
      return 0L;
    }
    return paramLoginViewModel.swigCPtr;
  }
  
  public String GetLoginName()
  {
    return LoginViewModelSWIGJNI.LoginViewModel_GetLoginName(this.swigCPtr, this);
  }
  
  public boolean IsAccountLoginPossible(String paramString1, String paramString2)
  {
    return LoginViewModelSWIGJNI.LoginViewModel_IsAccountLoginPossible(this.swigCPtr, this, paramString1, paramString2);
  }
  
  public boolean IsReadyForLogin()
  {
    return LoginViewModelSWIGJNI.LoginViewModel_IsReadyForLogin(this.swigCPtr, this);
  }
  
  public void LogIn(ISingleErrorResultCallback paramISingleErrorResultCallback, IGenericSignalCallback paramIGenericSignalCallback, String paramString1, String paramString2)
  {
    LoginViewModelSWIGJNI.LoginViewModel_LogIn(this.swigCPtr, this, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback, paramString1, paramString2);
  }
  
  public void OnTfaResult(int paramInt, boolean paramBoolean)
  {
    LoginViewModelSWIGJNI.LoginViewModel_OnTfaResult(this.swigCPtr, this, paramInt, paramBoolean);
  }
  
  public void SaveLoginName(String paramString)
  {
    LoginViewModelSWIGJNI.LoginViewModel_SaveLoginName(this.swigCPtr, this, paramString);
  }
  
  public boolean ShowLoginInProgressView(LoginState paramLoginState)
  {
    return LoginViewModelSWIGJNI.LoginViewModel_ShowLoginInProgressView(this.swigCPtr, this, paramLoginState.swigValue());
  }
  
  public boolean ShowOfflineView(LoginState paramLoginState)
  {
    return LoginViewModelSWIGJNI.LoginViewModel_ShowOfflineView(this.swigCPtr, this, paramLoginState.swigValue());
  }
  
  public boolean ShowOnlineView(LoginState paramLoginState)
  {
    return LoginViewModelSWIGJNI.LoginViewModel_ShowOnlineView(this.swigCPtr, this, paramLoginState.swigValue());
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          LoginViewModelSWIGJNI.delete_LoginViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/LoginViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */