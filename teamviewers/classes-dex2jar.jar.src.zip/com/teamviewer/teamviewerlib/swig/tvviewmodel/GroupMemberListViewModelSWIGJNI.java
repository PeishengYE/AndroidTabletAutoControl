package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListComputerID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListContactID;

public class GroupMemberListViewModelSWIGJNI
{
  public static final native long GroupMemberListViewModel_GetElement(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, long paramLong2, IndexPath paramIndexPath);
  
  public static final native String GroupMemberListViewModel_GetGroupName(long paramLong, GroupMemberListViewModel paramGroupMemberListViewModel);
  
  public static final native int GroupMemberListViewModel_GetSize(long paramLong, GroupMemberListViewModel paramGroupMemberListViewModel, int paramInt);
  
  public static final native void GroupMemberListViewModel_RegisterForChanges(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void GroupMemberListViewModel_RemoveComputer(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, long paramLong2, PListComputerID paramPListComputerID, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void GroupMemberListViewModel_RemoveContact(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, long paramLong2, PListContactID paramPListContactID, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void GroupMemberListViewModel_RemoveGroup(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void GroupMemberListViewModel_RenameGroup(long paramLong1, GroupMemberListViewModel paramGroupMemberListViewModel, String paramString, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void delete_GroupMemberListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */