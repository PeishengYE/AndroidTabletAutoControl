package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class DyngateViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public DyngateViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(DyngateViewModel paramDyngateViewModel)
  {
    if (paramDyngateViewModel == null) {
      return 0L;
    }
    return paramDyngateViewModel.swigCPtr;
  }
  
  public String GetDisplayName()
  {
    return DyngateViewModelSWIGJNI.DyngateViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public String GetPassword()
  {
    return DyngateViewModelSWIGJNI.DyngateViewModel_GetPassword(this.swigCPtr, this);
  }
  
  public void SetHadConnectionFlag()
  {
    DyngateViewModelSWIGJNI.DyngateViewModel_SetHadConnectionFlag(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          DyngateViewModelSWIGJNI.delete_DyngateViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/DyngateViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */