package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class DefaultMessageViewModel
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public DefaultMessageViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public DefaultMessageViewModel(DefaultMessageViewModel paramDefaultMessageViewModel)
  {
    this(DefaultMessageViewModelSWIGJNI.new_DefaultMessageViewModel(getCPtr(paramDefaultMessageViewModel), paramDefaultMessageViewModel), true);
  }
  
  public static long getCPtr(DefaultMessageViewModel paramDefaultMessageViewModel)
  {
    if (paramDefaultMessageViewModel == null) {
      return 0L;
    }
    return paramDefaultMessageViewModel.swigCPtr;
  }
  
  public IDefaultMessageButtonVector GetButtons()
  {
    return new IDefaultMessageButtonVector(DefaultMessageViewModelSWIGJNI.DefaultMessageViewModel_GetButtons(this.swigCPtr, this), true);
  }
  
  public String GetText()
  {
    return DefaultMessageViewModelSWIGJNI.DefaultMessageViewModel_GetText(this.swigCPtr, this);
  }
  
  public String GetTitle()
  {
    return DefaultMessageViewModelSWIGJNI.DefaultMessageViewModel_GetTitle(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          DefaultMessageViewModelSWIGJNI.delete_DefaultMessageViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/DefaultMessageViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */