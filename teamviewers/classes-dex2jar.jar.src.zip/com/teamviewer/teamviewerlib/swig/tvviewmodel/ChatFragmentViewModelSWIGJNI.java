package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class ChatFragmentViewModelSWIGJNI
{
  public static final native long ChatFragmentViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native boolean ChatFragmentViewModel_ShouldShowLoginFragment(long paramLong, ChatFragmentViewModel paramChatFragmentViewModel, int paramInt);
  
  public static final native void delete_ChatFragmentViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ChatFragmentViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */