package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;

public class ServiceCaseListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ServiceCaseListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ServiceCaseListViewModel paramServiceCaseListViewModel)
  {
    if (paramServiceCaseListViewModel == null) {
      return 0L;
    }
    return paramServiceCaseListViewModel.swigCPtr;
  }
  
  public int GetElement(int paramInt)
  {
    return ServiceCaseListViewModelSWIGJNI.ServiceCaseListViewModel_GetElement(this.swigCPtr, this, paramInt);
  }
  
  public int GetSize()
  {
    return ServiceCaseListViewModelSWIGJNI.ServiceCaseListViewModel_GetSize(this.swigCPtr, this);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    ServiceCaseListViewModelSWIGJNI.ServiceCaseListViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ServiceCaseListViewModelSWIGJNI.delete_ServiceCaseListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */