package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AccountSignalsHelper
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public AccountSignalsHelper(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static void RegisterAccountLoginStateChangedSlot(AccountViewModelBase paramAccountViewModelBase, AccountLoginStateChangedSignalCallback paramAccountLoginStateChangedSignalCallback)
  {
    AccountSignalsHelperSWIGJNI.AccountSignalsHelper_RegisterAccountLoginStateChangedSlot(AccountViewModelBase.getCPtr(paramAccountViewModelBase), paramAccountViewModelBase, AccountLoginStateChangedSignalCallback.getCPtr(paramAccountLoginStateChangedSignalCallback), paramAccountLoginStateChangedSignalCallback);
  }
  
  public static long getCPtr(AccountSignalsHelper paramAccountSignalsHelper)
  {
    if (paramAccountSignalsHelper == null) {
      return 0L;
    }
    return paramAccountSignalsHelper.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          AccountSignalsHelperSWIGJNI.delete_AccountSignalsHelper(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AccountSignalsHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */