package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListDyngateID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class ComputerViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ComputerViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ComputerViewModel paramComputerViewModel)
  {
    if (paramComputerViewModel == null) {
      return 0L;
    }
    return paramComputerViewModel.swigCPtr;
  }
  
  public void CreateComputer(String paramString1, String paramString2, String paramString3, PListGroupID paramPListGroupID, String paramString4, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    ComputerViewModelSWIGJNI.ComputerViewModel_CreateComputer(this.swigCPtr, this, paramString1, paramString2, paramString3, PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID, paramString4, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public String GetAlias()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_GetAlias(this.swigCPtr, this);
  }
  
  public String GetDisplayName()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public PListDyngateID GetDyngateID()
  {
    return new PListDyngateID(ComputerViewModelSWIGJNI.ComputerViewModel_GetDyngateID(this.swigCPtr, this), true);
  }
  
  public PListGroupID GetGroupID()
  {
    return new PListGroupID(ComputerViewModelSWIGJNI.ComputerViewModel_GetGroupID(this.swigCPtr, this), true);
  }
  
  public String GetNote()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_GetNote(this.swigCPtr, this);
  }
  
  public String GetPassword()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_GetPassword(this.swigCPtr, this);
  }
  
  public boolean HasPasswordSet()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_HasPasswordSet(this.swigCPtr, this);
  }
  
  public boolean IsEditableByMe()
  {
    return ComputerViewModelSWIGJNI.ComputerViewModel_IsEditableByMe(this.swigCPtr, this);
  }
  
  public void UpdateComputer(String paramString1, String paramString2, boolean paramBoolean, PListGroupID paramPListGroupID, String paramString3, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    ComputerViewModelSWIGJNI.ComputerViewModel_UpdateComputer(this.swigCPtr, this, paramString1, paramString2, paramBoolean, PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID, paramString3, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ComputerViewModelSWIGJNI.delete_ComputerViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ComputerViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */