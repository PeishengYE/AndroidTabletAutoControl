package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import java.math.BigInteger;

public class GroupMemberListElementViewModelSWIGJNI
{
  public static final native boolean GroupMemberListElementViewModel_CanWakeUp(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native String GroupMemberListElementViewModel_GetAccountPictureUrl(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native BigInteger GroupMemberListElementViewModel_GetChatEndPoint(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native long GroupMemberListElementViewModel_GetID(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native String GroupMemberListElementViewModel_GetName(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native int GroupMemberListElementViewModel_GetOnlineState(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native int GroupMemberListElementViewModel_GetType(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_IsChatPossible(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_IsEditableByMe(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_IsOnline(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native void GroupMemberListElementViewModel_RegisterForChanges(long paramLong1, GroupMemberListElementViewModel paramGroupMemberListElementViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native boolean GroupMemberListElementViewModel_ShowChatTo(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_ShowConnect(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_ShowConnectConfirm(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native boolean GroupMemberListElementViewModel_WakeUpDevice(long paramLong, GroupMemberListElementViewModel paramGroupMemberListElementViewModel);
  
  public static final native void delete_GroupMemberListElementViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberListElementViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */