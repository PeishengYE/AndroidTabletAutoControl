package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class LoginViewModelSWIGJNI
{
  public static final native String LoginViewModel_GetLoginName(long paramLong, LoginViewModel paramLoginViewModel);
  
  public static final native boolean LoginViewModel_IsAccountLoginPossible(long paramLong, LoginViewModel paramLoginViewModel, String paramString1, String paramString2);
  
  public static final native boolean LoginViewModel_IsReadyForLogin(long paramLong, LoginViewModel paramLoginViewModel);
  
  public static final native void LoginViewModel_LogIn(long paramLong1, LoginViewModel paramLoginViewModel, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback, long paramLong3, IGenericSignalCallback paramIGenericSignalCallback, String paramString1, String paramString2);
  
  public static final native void LoginViewModel_OnTfaResult(long paramLong, LoginViewModel paramLoginViewModel, int paramInt, boolean paramBoolean);
  
  public static final native long LoginViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void LoginViewModel_SaveLoginName(long paramLong, LoginViewModel paramLoginViewModel, String paramString);
  
  public static final native boolean LoginViewModel_ShowLoginInProgressView(long paramLong, LoginViewModel paramLoginViewModel, int paramInt);
  
  public static final native boolean LoginViewModel_ShowOfflineView(long paramLong, LoginViewModel paramLoginViewModel, int paramInt);
  
  public static final native boolean LoginViewModel_ShowOnlineView(long paramLong, LoginViewModel paramLoginViewModel, int paramInt);
  
  public static final native void delete_LoginViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/LoginViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */