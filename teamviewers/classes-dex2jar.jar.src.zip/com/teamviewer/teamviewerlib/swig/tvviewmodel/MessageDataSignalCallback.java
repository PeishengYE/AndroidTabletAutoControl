package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.SignalCallbackBase;

public class MessageDataSignalCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public MessageDataSignalCallback()
  {
    this(MessageDataSignalCallbackSWIGJNI.new_MessageDataSignalCallback(), true);
    MessageDataSignalCallbackSWIGJNI.MessageDataSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public MessageDataSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(MessageDataSignalCallbackSWIGJNI.MessageDataSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(MessageDataSignalCallback paramMessageDataSignalCallback)
  {
    if (paramMessageDataSignalCallback == null) {
      return 0L;
    }
    return paramMessageDataSignalCallback.swigCPtr;
  }
  
  public void OnMessage(DefaultMessageViewModel paramDefaultMessageViewModel)
  {
    MessageDataSignalCallbackSWIGJNI.MessageDataSignalCallback_OnMessage(this.swigCPtr, this, DefaultMessageViewModel.getCPtr(paramDefaultMessageViewModel), paramDefaultMessageViewModel);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          MessageDataSignalCallbackSWIGJNI.delete_MessageDataSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    MessageDataSignalCallbackSWIGJNI.MessageDataSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    MessageDataSignalCallbackSWIGJNI.MessageDataSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MessageDataSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */