package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListDyngateID;

public class MachineListElementViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public MachineListElementViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(MachineListElementViewModel paramMachineListElementViewModel)
  {
    if (paramMachineListElementViewModel == null) {
      return 0L;
    }
    return paramMachineListElementViewModel.swigCPtr;
  }
  
  public String GetDisplayName()
  {
    return MachineListElementViewModelSWIGJNI.MachineListElementViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public PListDyngateID GetDyngateID()
  {
    return new PListDyngateID(MachineListElementViewModelSWIGJNI.MachineListElementViewModel_GetDyngateID(this.swigCPtr, this), true);
  }
  
  public String GetPassword()
  {
    return MachineListElementViewModelSWIGJNI.MachineListElementViewModel_GetPassword(this.swigCPtr, this);
  }
  
  public boolean HasPasswordSet()
  {
    return MachineListElementViewModelSWIGJNI.MachineListElementViewModel_HasPasswordSet(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          MachineListElementViewModelSWIGJNI.delete_MachineListElementViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineListElementViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */