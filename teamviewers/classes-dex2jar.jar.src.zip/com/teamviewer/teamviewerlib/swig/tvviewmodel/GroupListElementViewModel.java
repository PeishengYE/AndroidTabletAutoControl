package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class GroupListElementViewModel
  extends IComparable
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public GroupListElementViewModel(long paramLong, boolean paramBoolean)
  {
    super(GroupListElementViewModelSWIGJNI.GroupListElementViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(GroupListElementViewModel paramGroupListElementViewModel)
  {
    if (paramGroupListElementViewModel == null) {
      return 0L;
    }
    return paramGroupListElementViewModel.swigCPtr;
  }
  
  public int Compare(IComparable paramIComparable)
  {
    return GroupListElementViewModelSWIGJNI.GroupListElementViewModel_Compare(this.swigCPtr, this, IComparable.getCPtr(paramIComparable), paramIComparable);
  }
  
  public GroupSharingStatus GetGroupSharingStatus()
  {
    return GroupSharingStatus.swigToEnum(GroupListElementViewModelSWIGJNI.GroupListElementViewModel_GetGroupSharingStatus(this.swigCPtr, this));
  }
  
  public PListGroupID GetID()
  {
    return new PListGroupID(GroupListElementViewModelSWIGJNI.GroupListElementViewModel_GetID(this.swigCPtr, this), true);
  }
  
  public String GetName()
  {
    return GroupListElementViewModelSWIGJNI.GroupListElementViewModel_GetName(this.swigCPtr, this);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    GroupListElementViewModelSWIGJNI.GroupListElementViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          GroupListElementViewModelSWIGJNI.delete_GroupListElementViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupListElementViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */