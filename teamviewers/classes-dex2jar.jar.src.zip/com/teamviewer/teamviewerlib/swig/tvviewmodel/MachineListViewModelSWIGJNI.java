package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;

public class MachineListViewModelSWIGJNI
{
  public static final native long MachineListViewModel_GetElement(long paramLong1, MachineListViewModel paramMachineListViewModel, long paramLong2);
  
  public static final native long MachineListViewModel_GetSize(long paramLong, MachineListViewModel paramMachineListViewModel);
  
  public static final native boolean MachineListViewModel_IsContactComputerSelectionRequired(long paramLong, MachineListViewModel paramMachineListViewModel);
  
  public static final native void MachineListViewModel_RegisterForChanges(long paramLong1, MachineListViewModel paramMachineListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void delete_MachineListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */