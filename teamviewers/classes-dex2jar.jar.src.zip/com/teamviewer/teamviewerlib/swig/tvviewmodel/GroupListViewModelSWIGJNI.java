package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class GroupListViewModelSWIGJNI
{
  public static final native void GroupListViewModel_CreateGroup(long paramLong1, GroupListViewModel paramGroupListViewModel, String paramString, long paramLong2, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native long GroupListViewModel_GetElement(long paramLong, GroupListViewModel paramGroupListViewModel, int paramInt);
  
  public static final native int GroupListViewModel_GetIndexForGroupID(long paramLong1, GroupListViewModel paramGroupListViewModel, long paramLong2, PListGroupID paramPListGroupID);
  
  public static final native int GroupListViewModel_GetSize(long paramLong, GroupListViewModel paramGroupListViewModel);
  
  public static final native boolean GroupListViewModel_HasGroups(long paramLong, GroupListViewModel paramGroupListViewModel);
  
  public static final native boolean GroupListViewModel_IsEnabled(long paramLong, GroupListViewModel paramGroupListViewModel, int paramInt);
  
  public static final native void GroupListViewModel_RegisterForChanges(long paramLong1, GroupListViewModel paramGroupListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void delete_GroupListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */