package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class IDefaultMessageButtonVector
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IDefaultMessageButtonVector()
  {
    this(DefaultMessageViewModelSWIGJNI.new_IDefaultMessageButtonVector(), true);
  }
  
  public IDefaultMessageButtonVector(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IDefaultMessageButtonVector paramIDefaultMessageButtonVector)
  {
    if (paramIDefaultMessageButtonVector == null) {
      return 0L;
    }
    return paramIDefaultMessageButtonVector.swigCPtr;
  }
  
  public void add(DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel)
  {
    DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_add(this.swigCPtr, this, DefaultMessageButtonViewModel.getCPtr(paramDefaultMessageButtonViewModel), paramDefaultMessageButtonViewModel);
  }
  
  public long capacity()
  {
    return DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_capacity(this.swigCPtr, this);
  }
  
  public void clear()
  {
    DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_clear(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          DefaultMessageViewModelSWIGJNI.delete_IDefaultMessageButtonVector(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public DefaultMessageButtonViewModel get(int paramInt)
  {
    return new DefaultMessageButtonViewModel(DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_get(this.swigCPtr, this, paramInt), false);
  }
  
  public boolean isEmpty()
  {
    return DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_isEmpty(this.swigCPtr, this);
  }
  
  public void reserve(long paramLong)
  {
    DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_reserve(this.swigCPtr, this, paramLong);
  }
  
  public void set(int paramInt, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel)
  {
    DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_set(this.swigCPtr, this, paramInt, DefaultMessageButtonViewModel.getCPtr(paramDefaultMessageButtonViewModel), paramDefaultMessageButtonViewModel);
  }
  
  public long size()
  {
    return DefaultMessageViewModelSWIGJNI.IDefaultMessageButtonVector_size(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/IDefaultMessageButtonVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */