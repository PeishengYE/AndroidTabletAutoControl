package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class MachineListElementViewModelSWIGJNI
{
  public static final native String MachineListElementViewModel_GetDisplayName(long paramLong, MachineListElementViewModel paramMachineListElementViewModel);
  
  public static final native long MachineListElementViewModel_GetDyngateID(long paramLong, MachineListElementViewModel paramMachineListElementViewModel);
  
  public static final native String MachineListElementViewModel_GetPassword(long paramLong, MachineListElementViewModel paramMachineListElementViewModel);
  
  public static final native boolean MachineListElementViewModel_HasPasswordSet(long paramLong, MachineListElementViewModel paramMachineListElementViewModel);
  
  public static final native void delete_MachineListElementViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineListElementViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */