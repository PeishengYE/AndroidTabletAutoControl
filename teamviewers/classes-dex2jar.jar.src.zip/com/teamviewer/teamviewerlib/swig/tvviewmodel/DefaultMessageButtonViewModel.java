package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class DefaultMessageButtonViewModel
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public DefaultMessageButtonViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel)
  {
    if (paramDefaultMessageButtonViewModel == null) {
      return 0L;
    }
    return paramDefaultMessageButtonViewModel.swigCPtr;
  }
  
  public boolean Active()
  {
    return DefaultMessageButtonViewModelSWIGJNI.DefaultMessageButtonViewModel_Active(this.swigCPtr, this);
  }
  
  public void Execute()
  {
    DefaultMessageButtonViewModelSWIGJNI.DefaultMessageButtonViewModel_Execute(this.swigCPtr, this);
  }
  
  public long GetIndex()
  {
    return DefaultMessageButtonViewModelSWIGJNI.DefaultMessageButtonViewModel_GetIndex(this.swigCPtr, this);
  }
  
  public String GetText()
  {
    return DefaultMessageButtonViewModelSWIGJNI.DefaultMessageButtonViewModel_GetText(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          DefaultMessageButtonViewModelSWIGJNI.delete_DefaultMessageButtonViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/DefaultMessageButtonViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */