package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class TokenLoginViewModel
  extends AccountViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public TokenLoginViewModel(long paramLong, boolean paramBoolean)
  {
    super(TokenLoginViewModelSWIGJNI.TokenLoginViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(TokenLoginViewModel paramTokenLoginViewModel)
  {
    if (paramTokenLoginViewModel == null) {
      return 0L;
    }
    return paramTokenLoginViewModel.swigCPtr;
  }
  
  public boolean IsCurrentlyLoggedIn(String paramString)
  {
    return TokenLoginViewModelSWIGJNI.TokenLoginViewModel_IsCurrentlyLoggedIn(this.swigCPtr, this, paramString);
  }
  
  public void TryLogin(String paramString1, String paramString2, long paramLong, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    TokenLoginViewModelSWIGJNI.TokenLoginViewModel_TryLogin(this.swigCPtr, this, paramString1, paramString2, paramLong, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          TokenLoginViewModelSWIGJNI.delete_TokenLoginViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/TokenLoginViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */