package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListDyngateID;

public class MachineId
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public MachineId(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(MachineId paramMachineId)
  {
    if (paramMachineId == null) {
      return 0L;
    }
    return paramMachineId.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          MachineIdSWIGJNI.delete_MachineId(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public PListDyngateID getDyngateId()
  {
    long l = MachineIdSWIGJNI.MachineId_dyngateId_get(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new PListDyngateID(l, false);
  }
  
  public MachineType getType()
  {
    return MachineType.swigToEnum(MachineIdSWIGJNI.MachineId_type_get(this.swigCPtr, this));
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */