package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class ContactViewModelSWIGJNI
{
  public static final native void ContactViewModel_CreateContact(long paramLong1, ContactViewModel paramContactViewModel, String paramString1, long paramLong2, PListGroupID paramPListGroupID, String paramString2, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native String ContactViewModel_GetDisplayName(long paramLong, ContactViewModel paramContactViewModel);
  
  public static final native long ContactViewModel_GetGroupID(long paramLong, ContactViewModel paramContactViewModel);
  
  public static final native String ContactViewModel_GetName(long paramLong, ContactViewModel paramContactViewModel);
  
  public static final native String ContactViewModel_GetNote(long paramLong, ContactViewModel paramContactViewModel);
  
  public static final native boolean ContactViewModel_IsEditableByMe(long paramLong, ContactViewModel paramContactViewModel);
  
  public static final native void ContactViewModel_UpdateContact(long paramLong1, ContactViewModel paramContactViewModel, long paramLong2, PListGroupID paramPListGroupID, String paramString, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void delete_ContactViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ContactViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */