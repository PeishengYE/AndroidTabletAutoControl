package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class GroupMemberId
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public GroupMemberId(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public GroupMemberId(GroupMemberType paramGroupMemberType, long paramLong)
  {
    this(GroupMemberIdSWIGJNI.new_GroupMemberId(paramGroupMemberType.swigValue(), paramLong), true);
  }
  
  public static long getCPtr(GroupMemberId paramGroupMemberId)
  {
    if (paramGroupMemberId == null) {
      return 0L;
    }
    return paramGroupMemberId.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GroupMemberIdSWIGJNI.delete_GroupMemberId(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long getMemberId()
  {
    return GroupMemberIdSWIGJNI.GroupMemberId_memberId_get(this.swigCPtr, this);
  }
  
  public GroupMemberType getType()
  {
    return GroupMemberType.swigToEnum(GroupMemberIdSWIGJNI.GroupMemberId_type_get(this.swigCPtr, this));
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */