package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ViewModelOnlineState;
import java.math.BigInteger;

public class GroupMemberListElementViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public GroupMemberListElementViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(GroupMemberListElementViewModel paramGroupMemberListElementViewModel)
  {
    if (paramGroupMemberListElementViewModel == null) {
      return 0L;
    }
    return paramGroupMemberListElementViewModel.swigCPtr;
  }
  
  public boolean CanWakeUp()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_CanWakeUp(this.swigCPtr, this);
  }
  
  public String GetAccountPictureUrl()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetAccountPictureUrl(this.swigCPtr, this);
  }
  
  public BigInteger GetChatEndPoint()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetChatEndPoint(this.swigCPtr, this);
  }
  
  public long GetID()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetID(this.swigCPtr, this);
  }
  
  public String GetName()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetName(this.swigCPtr, this);
  }
  
  public ViewModelOnlineState GetOnlineState()
  {
    return ViewModelOnlineState.swigToEnum(GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetOnlineState(this.swigCPtr, this));
  }
  
  public GroupMemberType GetType()
  {
    return GroupMemberType.swigToEnum(GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_GetType(this.swigCPtr, this));
  }
  
  public boolean IsChatPossible()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_IsChatPossible(this.swigCPtr, this);
  }
  
  public boolean IsEditableByMe()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_IsEditableByMe(this.swigCPtr, this);
  }
  
  public boolean IsOnline()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_IsOnline(this.swigCPtr, this);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public boolean ShowChatTo()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_ShowChatTo(this.swigCPtr, this);
  }
  
  public boolean ShowConnect()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_ShowConnect(this.swigCPtr, this);
  }
  
  public boolean ShowConnectConfirm()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_ShowConnectConfirm(this.swigCPtr, this);
  }
  
  public boolean WakeUpDevice()
  {
    return GroupMemberListElementViewModelSWIGJNI.GroupMemberListElementViewModel_WakeUpDevice(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GroupMemberListElementViewModelSWIGJNI.delete_GroupMemberListElementViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberListElementViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */