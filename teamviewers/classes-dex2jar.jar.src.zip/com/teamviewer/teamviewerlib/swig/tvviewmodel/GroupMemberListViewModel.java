package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListComputerID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListContactID;

public class GroupMemberListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public GroupMemberListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(GroupMemberListViewModel paramGroupMemberListViewModel)
  {
    if (paramGroupMemberListViewModel == null) {
      return 0L;
    }
    return paramGroupMemberListViewModel.swigCPtr;
  }
  
  public GroupMemberId GetElement(IndexPath paramIndexPath)
  {
    long l = GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_GetElement(this.swigCPtr, this, IndexPath.getCPtr(paramIndexPath), paramIndexPath);
    if (l == 0L) {
      return null;
    }
    return new GroupMemberId(l, true);
  }
  
  public String GetGroupName()
  {
    return GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_GetGroupName(this.swigCPtr, this);
  }
  
  public int GetSize(GroupUIModelSection paramGroupUIModelSection)
  {
    return GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_GetSize(this.swigCPtr, this, paramGroupUIModelSection.swigValue());
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public void RemoveComputer(PListComputerID paramPListComputerID, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_RemoveComputer(this.swigCPtr, this, PListComputerID.getCPtr(paramPListComputerID), paramPListComputerID, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void RemoveContact(PListContactID paramPListContactID, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_RemoveContact(this.swigCPtr, this, PListContactID.getCPtr(paramPListContactID), paramPListContactID, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void RemoveGroup(ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_RemoveGroup(this.swigCPtr, this, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void RenameGroup(String paramString, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    GroupMemberListViewModelSWIGJNI.GroupMemberListViewModel_RenameGroup(this.swigCPtr, this, paramString, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GroupMemberListViewModelSWIGJNI.delete_GroupMemberListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */