package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class ContactViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ContactViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ContactViewModel paramContactViewModel)
  {
    if (paramContactViewModel == null) {
      return 0L;
    }
    return paramContactViewModel.swigCPtr;
  }
  
  public void CreateContact(String paramString1, PListGroupID paramPListGroupID, String paramString2, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    ContactViewModelSWIGJNI.ContactViewModel_CreateContact(this.swigCPtr, this, paramString1, PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID, paramString2, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public String GetDisplayName()
  {
    return ContactViewModelSWIGJNI.ContactViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public PListGroupID GetGroupID()
  {
    return new PListGroupID(ContactViewModelSWIGJNI.ContactViewModel_GetGroupID(this.swigCPtr, this), true);
  }
  
  public String GetName()
  {
    return ContactViewModelSWIGJNI.ContactViewModel_GetName(this.swigCPtr, this);
  }
  
  public String GetNote()
  {
    return ContactViewModelSWIGJNI.ContactViewModel_GetNote(this.swigCPtr, this);
  }
  
  public boolean IsEditableByMe()
  {
    return ContactViewModelSWIGJNI.ContactViewModel_IsEditableByMe(this.swigCPtr, this);
  }
  
  public void UpdateContact(PListGroupID paramPListGroupID, String paramString, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    ContactViewModelSWIGJNI.ContactViewModel_UpdateContact(this.swigCPtr, this, PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID, paramString, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ContactViewModelSWIGJNI.delete_ContactViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ContactViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */