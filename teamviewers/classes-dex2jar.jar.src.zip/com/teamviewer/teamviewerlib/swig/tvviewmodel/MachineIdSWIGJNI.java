package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class MachineIdSWIGJNI
{
  public static final native long MachineId_dyngateId_get(long paramLong, MachineId paramMachineId);
  
  public static final native int MachineId_type_get(long paramLong, MachineId paramMachineId);
  
  public static final native void delete_MachineId(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineIdSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */