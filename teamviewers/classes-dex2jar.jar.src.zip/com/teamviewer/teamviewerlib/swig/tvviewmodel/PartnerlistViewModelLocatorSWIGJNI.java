package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListComputerID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListContactID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListDyngateID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListServiceCaseID;

public class PartnerlistViewModelLocatorSWIGJNI
{
  public static final native long PartnerlistViewModelLocator_GetComputerViewModel(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native long PartnerlistViewModelLocator_GetContactViewModel(long paramLong, PListContactID paramPListContactID);
  
  public static final native long PartnerlistViewModelLocator_GetDyngateViewModel(long paramLong, PListDyngateID paramPListDyngateID);
  
  public static final native long PartnerlistViewModelLocator_GetGroupListElementViewModel(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native long PartnerlistViewModelLocator_GetGroupListViewModel(boolean paramBoolean);
  
  public static final native long PartnerlistViewModelLocator_GetGroupMemberListElementViewModel(long paramLong, GroupMemberId paramGroupMemberId);
  
  public static final native long PartnerlistViewModelLocator_GetGroupMemberListViewModel(long paramLong, PListGroupID paramPListGroupID);
  
  public static final native long PartnerlistViewModelLocator_GetMachineListElementViewModel(long paramLong, MachineId paramMachineId);
  
  public static final native long PartnerlistViewModelLocator_GetMachineListViewModel(long paramLong, PListContactID paramPListContactID, boolean paramBoolean1, boolean paramBoolean2);
  
  public static final native long PartnerlistViewModelLocator_GetManagedDeviceViewModel__SWIG_0(long paramLong, PListComputerID paramPListComputerID);
  
  public static final native long PartnerlistViewModelLocator_GetManagedDeviceViewModel__SWIG_1(long paramLong, MachineId paramMachineId);
  
  public static final native long PartnerlistViewModelLocator_GetServiceCaseListElementViewModel(long paramLong, PListServiceCaseID paramPListServiceCaseID);
  
  public static final native long PartnerlistViewModelLocator_GetServiceCaseListViewModel();
  
  public static final native long PartnerlistViewModelLocator_GetServiceCaseViewModel(long paramLong, PListServiceCaseID paramPListServiceCaseID);
  
  public static final native void delete_PartnerlistViewModelLocator(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/PartnerlistViewModelLocatorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */