package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import java.math.BigInteger;

public class ServiceCaseListElementViewModel
  extends IComparable
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public ServiceCaseListElementViewModel(long paramLong, boolean paramBoolean)
  {
    super(ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ServiceCaseListElementViewModel paramServiceCaseListElementViewModel)
  {
    if (paramServiceCaseListElementViewModel == null) {
      return 0L;
    }
    return paramServiceCaseListElementViewModel.swigCPtr;
  }
  
  public void CloseCase()
  {
    ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_CloseCase(this.swigCPtr, this);
  }
  
  public int Compare(IComparable paramIComparable)
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_Compare(this.swigCPtr, this, IComparable.getCPtr(paramIComparable), paramIComparable);
  }
  
  public BigInteger GetChatEndPoint()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_GetChatEndPoint(this.swigCPtr, this);
  }
  
  public int GetID()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_GetID(this.swigCPtr, this);
  }
  
  public ServiceCaseListElementViewModel.IconState GetIcon()
  {
    return ServiceCaseListElementViewModel.IconState.swigToEnum(ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_GetIcon(this.swigCPtr, this));
  }
  
  public String GetName()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_GetName(this.swigCPtr, this);
  }
  
  public String GetPassword()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_GetPassword(this.swigCPtr, this);
  }
  
  public boolean IsCloseAllowed()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_IsCloseAllowed(this.swigCPtr, this);
  }
  
  public boolean IsConnectPossible()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_IsConnectPossible(this.swigCPtr, this);
  }
  
  public boolean IsEditableByMe()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_IsEditableByMe(this.swigCPtr, this);
  }
  
  public boolean IsTakeOverPossible()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_IsTakeOverPossible(this.swigCPtr, this);
  }
  
  public boolean IsVisible()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_IsVisible(this.swigCPtr, this);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public boolean ShowChatTo()
  {
    return ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_ShowChatTo(this.swigCPtr, this);
  }
  
  public void TakeOver()
  {
    ServiceCaseListElementViewModelSWIGJNI.ServiceCaseListElementViewModel_TakeOver(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          ServiceCaseListElementViewModelSWIGJNI.delete_ServiceCaseListElementViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseListElementViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */