package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListComputerID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListContactID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListDyngateID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListServiceCaseID;

public class PartnerlistViewModelLocator
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public PartnerlistViewModelLocator(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static ComputerViewModel GetComputerViewModel(PListComputerID paramPListComputerID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetComputerViewModel(PListComputerID.getCPtr(paramPListComputerID), paramPListComputerID);
    if (l == 0L) {
      return null;
    }
    return new ComputerViewModel(l, true);
  }
  
  public static ContactViewModel GetContactViewModel(PListContactID paramPListContactID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetContactViewModel(PListContactID.getCPtr(paramPListContactID), paramPListContactID);
    if (l == 0L) {
      return null;
    }
    return new ContactViewModel(l, true);
  }
  
  public static DyngateViewModel GetDyngateViewModel(PListDyngateID paramPListDyngateID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetDyngateViewModel(PListDyngateID.getCPtr(paramPListDyngateID), paramPListDyngateID);
    if (l == 0L) {
      return null;
    }
    return new DyngateViewModel(l, true);
  }
  
  public static GroupListElementViewModel GetGroupListElementViewModel(PListGroupID paramPListGroupID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetGroupListElementViewModel(PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID);
    if (l == 0L) {
      return null;
    }
    return new GroupListElementViewModel(l, true);
  }
  
  public static GroupListViewModel GetGroupListViewModel(boolean paramBoolean)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetGroupListViewModel(paramBoolean);
    if (l == 0L) {
      return null;
    }
    return new GroupListViewModel(l, true);
  }
  
  public static GroupMemberListElementViewModel GetGroupMemberListElementViewModel(GroupMemberId paramGroupMemberId)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetGroupMemberListElementViewModel(GroupMemberId.getCPtr(paramGroupMemberId), paramGroupMemberId);
    if (l == 0L) {
      return null;
    }
    return new GroupMemberListElementViewModel(l, true);
  }
  
  public static GroupMemberListViewModel GetGroupMemberListViewModel(PListGroupID paramPListGroupID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetGroupMemberListViewModel(PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID);
    if (l == 0L) {
      return null;
    }
    return new GroupMemberListViewModel(l, true);
  }
  
  public static MachineListElementViewModel GetMachineListElementViewModel(MachineId paramMachineId)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetMachineListElementViewModel(MachineId.getCPtr(paramMachineId), paramMachineId);
    if (l == 0L) {
      return null;
    }
    return new MachineListElementViewModel(l, true);
  }
  
  public static MachineListViewModel GetMachineListViewModel(PListContactID paramPListContactID, boolean paramBoolean1, boolean paramBoolean2)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetMachineListViewModel(PListContactID.getCPtr(paramPListContactID), paramPListContactID, paramBoolean1, paramBoolean2);
    if (l == 0L) {
      return null;
    }
    return new MachineListViewModel(l, true);
  }
  
  public static ManagedDeviceViewModel GetManagedDeviceViewModel(PListComputerID paramPListComputerID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetManagedDeviceViewModel__SWIG_0(PListComputerID.getCPtr(paramPListComputerID), paramPListComputerID);
    if (l == 0L) {
      return null;
    }
    return new ManagedDeviceViewModel(l, true);
  }
  
  public static ManagedDeviceViewModel GetManagedDeviceViewModel(MachineId paramMachineId)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetManagedDeviceViewModel__SWIG_1(MachineId.getCPtr(paramMachineId), paramMachineId);
    if (l == 0L) {
      return null;
    }
    return new ManagedDeviceViewModel(l, true);
  }
  
  public static ServiceCaseListElementViewModel GetServiceCaseListElementViewModel(PListServiceCaseID paramPListServiceCaseID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetServiceCaseListElementViewModel(PListServiceCaseID.getCPtr(paramPListServiceCaseID), paramPListServiceCaseID);
    if (l == 0L) {
      return null;
    }
    return new ServiceCaseListElementViewModel(l, true);
  }
  
  public static ServiceCaseListViewModel GetServiceCaseListViewModel()
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetServiceCaseListViewModel();
    if (l == 0L) {
      return null;
    }
    return new ServiceCaseListViewModel(l, true);
  }
  
  public static ServiceCaseViewModel GetServiceCaseViewModel(PListServiceCaseID paramPListServiceCaseID)
  {
    long l = PartnerlistViewModelLocatorSWIGJNI.PartnerlistViewModelLocator_GetServiceCaseViewModel(PListServiceCaseID.getCPtr(paramPListServiceCaseID), paramPListServiceCaseID);
    if (l == 0L) {
      return null;
    }
    return new ServiceCaseViewModel(l, true);
  }
  
  public static long getCPtr(PartnerlistViewModelLocator paramPartnerlistViewModelLocator)
  {
    if (paramPartnerlistViewModelLocator == null) {
      return 0L;
    }
    return paramPartnerlistViewModelLocator.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          PartnerlistViewModelLocatorSWIGJNI.delete_PartnerlistViewModelLocator(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/PartnerlistViewModelLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */