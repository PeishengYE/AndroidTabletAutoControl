package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;

public class ServiceCaseListViewModelSWIGJNI
{
  public static final native int ServiceCaseListViewModel_GetElement(long paramLong, ServiceCaseListViewModel paramServiceCaseListViewModel, int paramInt);
  
  public static final native int ServiceCaseListViewModel_GetSize(long paramLong, ServiceCaseListViewModel paramServiceCaseListViewModel);
  
  public static final native void ServiceCaseListViewModel_RegisterForChanges(long paramLong1, ServiceCaseListViewModel paramServiceCaseListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void delete_ServiceCaseListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */