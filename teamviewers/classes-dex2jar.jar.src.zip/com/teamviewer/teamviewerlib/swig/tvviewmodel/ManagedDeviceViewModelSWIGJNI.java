package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class ManagedDeviceViewModelSWIGJNI
{
  public static final native String ManagedDeviceViewModel_GetManagementId(long paramLong, ManagedDeviceViewModel paramManagedDeviceViewModel);
  
  public static final native boolean ManagedDeviceViewModel_IsEasyAccessEnabled(long paramLong, ManagedDeviceViewModel paramManagedDeviceViewModel);
  
  public static final native void delete_ManagedDeviceViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ManagedDeviceViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */