package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class GroupMemberIdSWIGJNI
{
  public static final native long GroupMemberId_memberId_get(long paramLong, GroupMemberId paramGroupMemberId);
  
  public static final native int GroupMemberId_type_get(long paramLong, GroupMemberId paramGroupMemberId);
  
  public static final native void delete_GroupMemberId(long paramLong);
  
  public static final native long new_GroupMemberId(int paramInt, long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupMemberIdSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */