package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class GroupListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public GroupListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(GroupListViewModel paramGroupListViewModel)
  {
    if (paramGroupListViewModel == null) {
      return 0L;
    }
    return paramGroupListViewModel.swigCPtr;
  }
  
  public void CreateGroup(String paramString, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    GroupListViewModelSWIGJNI.GroupListViewModel_CreateGroup(this.swigCPtr, this, paramString, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public PListGroupID GetElement(int paramInt)
  {
    return new PListGroupID(GroupListViewModelSWIGJNI.GroupListViewModel_GetElement(this.swigCPtr, this, paramInt), true);
  }
  
  public int GetIndexForGroupID(PListGroupID paramPListGroupID)
  {
    return GroupListViewModelSWIGJNI.GroupListViewModel_GetIndexForGroupID(this.swigCPtr, this, PListGroupID.getCPtr(paramPListGroupID), paramPListGroupID);
  }
  
  public int GetSize()
  {
    return GroupListViewModelSWIGJNI.GroupListViewModel_GetSize(this.swigCPtr, this);
  }
  
  public boolean HasGroups()
  {
    return GroupListViewModelSWIGJNI.GroupListViewModel_HasGroups(this.swigCPtr, this);
  }
  
  public boolean IsEnabled(int paramInt)
  {
    return GroupListViewModelSWIGJNI.GroupListViewModel_IsEnabled(this.swigCPtr, this, paramInt);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    GroupListViewModelSWIGJNI.GroupListViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GroupListViewModelSWIGJNI.delete_GroupListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */