package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class MessageDataSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void MessageDataSignalCallback_OnMessage(long paramLong1, MessageDataSignalCallback paramMessageDataSignalCallback, long paramLong2, DefaultMessageViewModel paramDefaultMessageViewModel);
  
  public static final native long MessageDataSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void MessageDataSignalCallback_change_ownership(MessageDataSignalCallback paramMessageDataSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void MessageDataSignalCallback_director_connect(MessageDataSignalCallback paramMessageDataSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_MessageDataSignalCallback_OnMessage(MessageDataSignalCallback paramMessageDataSignalCallback, long paramLong)
  {
    paramMessageDataSignalCallback.OnMessage(new DefaultMessageViewModel(paramLong, false));
  }
  
  public static final native void delete_MessageDataSignalCallback(long paramLong);
  
  public static final native long new_MessageDataSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MessageDataSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */