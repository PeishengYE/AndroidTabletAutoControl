package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AutoLoginViewModelSWIGJNI
{
  public static final native void AutoLoginViewModel_StartAutoLogin(long paramLong, AutoLoginViewModel paramAutoLoginViewModel);
  
  public static final native void delete_AutoLoginViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AutoLoginViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */