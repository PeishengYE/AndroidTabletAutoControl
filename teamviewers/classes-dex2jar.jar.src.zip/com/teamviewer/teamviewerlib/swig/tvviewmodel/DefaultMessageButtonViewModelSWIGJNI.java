package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class DefaultMessageButtonViewModelSWIGJNI
{
  public static final native boolean DefaultMessageButtonViewModel_Active(long paramLong, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native void DefaultMessageButtonViewModel_Execute(long paramLong, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native long DefaultMessageButtonViewModel_GetIndex(long paramLong, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native String DefaultMessageButtonViewModel_GetText(long paramLong, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native void delete_DefaultMessageButtonViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/DefaultMessageButtonViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */