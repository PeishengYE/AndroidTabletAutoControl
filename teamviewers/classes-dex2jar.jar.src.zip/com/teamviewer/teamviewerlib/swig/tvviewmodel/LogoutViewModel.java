package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class LogoutViewModel
  extends AccountViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public LogoutViewModel(long paramLong, boolean paramBoolean)
  {
    super(LogoutViewModelSWIGJNI.LogoutViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(LogoutViewModel paramLogoutViewModel)
  {
    if (paramLogoutViewModel == null) {
      return 0L;
    }
    return paramLogoutViewModel.swigCPtr;
  }
  
  public boolean IsEnabled()
  {
    return LogoutViewModelSWIGJNI.LogoutViewModel_IsEnabled(this.swigCPtr, this);
  }
  
  public void LogOut(ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    LogoutViewModelSWIGJNI.LogoutViewModel_LogOut(this.swigCPtr, this, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          LogoutViewModelSWIGJNI.delete_LogoutViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/LogoutViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */