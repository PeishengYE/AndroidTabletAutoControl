package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;
import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListGroupID;

public class ComputerViewModelSWIGJNI
{
  public static final native void ComputerViewModel_CreateComputer(long paramLong1, ComputerViewModel paramComputerViewModel, String paramString1, String paramString2, String paramString3, long paramLong2, PListGroupID paramPListGroupID, String paramString4, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native String ComputerViewModel_GetAlias(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native String ComputerViewModel_GetDisplayName(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native long ComputerViewModel_GetDyngateID(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native long ComputerViewModel_GetGroupID(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native String ComputerViewModel_GetNote(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native String ComputerViewModel_GetPassword(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native boolean ComputerViewModel_HasPasswordSet(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native boolean ComputerViewModel_IsEditableByMe(long paramLong, ComputerViewModel paramComputerViewModel);
  
  public static final native void ComputerViewModel_UpdateComputer(long paramLong1, ComputerViewModel paramComputerViewModel, String paramString1, String paramString2, boolean paramBoolean, long paramLong2, PListGroupID paramPListGroupID, String paramString3, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void delete_ComputerViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ComputerViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */