package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvguibackend.LoginState;

public class ChatFragmentViewModel
  extends AccountViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public ChatFragmentViewModel(long paramLong, boolean paramBoolean)
  {
    super(ChatFragmentViewModelSWIGJNI.ChatFragmentViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ChatFragmentViewModel paramChatFragmentViewModel)
  {
    if (paramChatFragmentViewModel == null) {
      return 0L;
    }
    return paramChatFragmentViewModel.swigCPtr;
  }
  
  public boolean ShouldShowLoginFragment(LoginState paramLoginState)
  {
    return ChatFragmentViewModelSWIGJNI.ChatFragmentViewModel_ShouldShowLoginFragment(this.swigCPtr, this, paramLoginState.swigValue());
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          ChatFragmentViewModelSWIGJNI.delete_ChatFragmentViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ChatFragmentViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */