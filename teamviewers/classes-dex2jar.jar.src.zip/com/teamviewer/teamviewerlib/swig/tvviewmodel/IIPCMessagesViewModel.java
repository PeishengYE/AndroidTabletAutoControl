package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class IIPCMessagesViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IIPCMessagesViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IIPCMessagesViewModel paramIIPCMessagesViewModel)
  {
    if (paramIIPCMessagesViewModel == null) {
      return 0L;
    }
    return paramIIPCMessagesViewModel.swigCPtr;
  }
  
  public void SetAppVisibilityBackground()
  {
    IIPCMessagesViewModelSWIGJNI.IIPCMessagesViewModel_SetAppVisibilityBackground(this.swigCPtr, this);
  }
  
  public void SetAppVisibilityForeground()
  {
    IIPCMessagesViewModelSWIGJNI.IIPCMessagesViewModel_SetAppVisibilityForeground(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IIPCMessagesViewModelSWIGJNI.delete_IIPCMessagesViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/IIPCMessagesViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */