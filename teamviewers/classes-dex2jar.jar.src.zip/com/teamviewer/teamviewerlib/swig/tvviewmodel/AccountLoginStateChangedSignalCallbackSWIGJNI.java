package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvguibackend.LoginState;

public class AccountLoginStateChangedSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void AccountLoginStateChangedSignalCallback_PerformLoginStateChanged(long paramLong, AccountLoginStateChangedSignalCallback paramAccountLoginStateChangedSignalCallback, int paramInt);
  
  public static final native long AccountLoginStateChangedSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void AccountLoginStateChangedSignalCallback_change_ownership(AccountLoginStateChangedSignalCallback paramAccountLoginStateChangedSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void AccountLoginStateChangedSignalCallback_director_connect(AccountLoginStateChangedSignalCallback paramAccountLoginStateChangedSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_AccountLoginStateChangedSignalCallback_PerformLoginStateChanged(AccountLoginStateChangedSignalCallback paramAccountLoginStateChangedSignalCallback, int paramInt)
  {
    paramAccountLoginStateChangedSignalCallback.PerformLoginStateChanged(LoginState.swigToEnum(paramInt));
  }
  
  public static final native void delete_AccountLoginStateChangedSignalCallback(long paramLong);
  
  public static final native long new_AccountLoginStateChangedSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AccountLoginStateChangedSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */