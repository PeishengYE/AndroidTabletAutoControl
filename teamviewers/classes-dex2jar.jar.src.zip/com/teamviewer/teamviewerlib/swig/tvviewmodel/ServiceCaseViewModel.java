package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class ServiceCaseViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ServiceCaseViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ServiceCaseViewModel paramServiceCaseViewModel)
  {
    if (paramServiceCaseViewModel == null) {
      return 0L;
    }
    return paramServiceCaseViewModel.swigCPtr;
  }
  
  public void CloseCase()
  {
    ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_CloseCase(this.swigCPtr, this);
  }
  
  public String GetAssignee()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetAssignee(this.swigCPtr, this);
  }
  
  public int GetAssigneeID()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetAssigneeID(this.swigCPtr, this);
  }
  
  public String GetDescription()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetDescription(this.swigCPtr, this);
  }
  
  public String GetDisplayID()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetDisplayID(this.swigCPtr, this);
  }
  
  public String GetGroup()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetGroup(this.swigCPtr, this);
  }
  
  public int GetGroupID()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetGroupID(this.swigCPtr, this);
  }
  
  public int GetID()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetID(this.swigCPtr, this);
  }
  
  public String GetName()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_GetName(this.swigCPtr, this);
  }
  
  public boolean IsCloseAllowed()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_IsCloseAllowed(this.swigCPtr, this);
  }
  
  public boolean IsEditableByMe()
  {
    return ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_IsEditableByMe(this.swigCPtr, this);
  }
  
  public void UpdateNote(String paramString, ISingleErrorResultCallback paramISingleErrorResultCallback)
  {
    ServiceCaseViewModelSWIGJNI.ServiceCaseViewModel_UpdateNote(this.swigCPtr, this, paramString, ISingleErrorResultCallback.getCPtr(paramISingleErrorResultCallback), paramISingleErrorResultCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ServiceCaseViewModelSWIGJNI.delete_ServiceCaseViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */