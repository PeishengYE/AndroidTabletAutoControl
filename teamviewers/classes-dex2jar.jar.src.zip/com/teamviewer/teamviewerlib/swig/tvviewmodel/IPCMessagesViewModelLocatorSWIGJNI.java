package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class IPCMessagesViewModelLocatorSWIGJNI
{
  public static final native long IPCMessagesViewModelLocator_GetIIPCMessagesViewModel();
  
  public static final native void delete_IPCMessagesViewModelLocator(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/IPCMessagesViewModelLocatorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */