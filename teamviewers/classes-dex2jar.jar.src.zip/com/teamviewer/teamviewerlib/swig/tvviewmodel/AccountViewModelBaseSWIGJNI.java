package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AccountViewModelBaseSWIGJNI
{
  public static final native int AccountViewModelBase_GetLoginState(long paramLong, AccountViewModelBase paramAccountViewModelBase);
  
  public static final native void delete_AccountViewModelBase(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AccountViewModelBaseSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */