package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvguibackend.LoginState;

public class BLFragmentViewModel
  extends AccountViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public BLFragmentViewModel(long paramLong, boolean paramBoolean)
  {
    super(BLFragmentViewModelSWIGJNI.BLFragmentViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(BLFragmentViewModel paramBLFragmentViewModel)
  {
    if (paramBLFragmentViewModel == null) {
      return 0L;
    }
    return paramBLFragmentViewModel.swigCPtr;
  }
  
  public boolean ShouldShowLoginFragment(LoginState paramLoginState)
  {
    return BLFragmentViewModelSWIGJNI.BLFragmentViewModel_ShouldShowLoginFragment(this.swigCPtr, this, paramLoginState.swigValue());
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          BLFragmentViewModelSWIGJNI.delete_BLFragmentViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/BLFragmentViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */