package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class DefaultMessageViewModelSWIGJNI
{
  public static final native long DefaultMessageViewModel_GetButtons(long paramLong, DefaultMessageViewModel paramDefaultMessageViewModel);
  
  public static final native String DefaultMessageViewModel_GetText(long paramLong, DefaultMessageViewModel paramDefaultMessageViewModel);
  
  public static final native String DefaultMessageViewModel_GetTitle(long paramLong, DefaultMessageViewModel paramDefaultMessageViewModel);
  
  public static final native void IDefaultMessageButtonVector_add(long paramLong1, IDefaultMessageButtonVector paramIDefaultMessageButtonVector, long paramLong2, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native long IDefaultMessageButtonVector_capacity(long paramLong, IDefaultMessageButtonVector paramIDefaultMessageButtonVector);
  
  public static final native void IDefaultMessageButtonVector_clear(long paramLong, IDefaultMessageButtonVector paramIDefaultMessageButtonVector);
  
  public static final native long IDefaultMessageButtonVector_get(long paramLong, IDefaultMessageButtonVector paramIDefaultMessageButtonVector, int paramInt);
  
  public static final native boolean IDefaultMessageButtonVector_isEmpty(long paramLong, IDefaultMessageButtonVector paramIDefaultMessageButtonVector);
  
  public static final native void IDefaultMessageButtonVector_reserve(long paramLong1, IDefaultMessageButtonVector paramIDefaultMessageButtonVector, long paramLong2);
  
  public static final native void IDefaultMessageButtonVector_set(long paramLong1, IDefaultMessageButtonVector paramIDefaultMessageButtonVector, int paramInt, long paramLong2, DefaultMessageButtonViewModel paramDefaultMessageButtonViewModel);
  
  public static final native long IDefaultMessageButtonVector_size(long paramLong, IDefaultMessageButtonVector paramIDefaultMessageButtonVector);
  
  public static final native void delete_DefaultMessageViewModel(long paramLong);
  
  public static final native void delete_IDefaultMessageButtonVector(long paramLong);
  
  public static final native long new_DefaultMessageViewModel(long paramLong, DefaultMessageViewModel paramDefaultMessageViewModel);
  
  public static final native long new_IDefaultMessageButtonVector();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/DefaultMessageViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */