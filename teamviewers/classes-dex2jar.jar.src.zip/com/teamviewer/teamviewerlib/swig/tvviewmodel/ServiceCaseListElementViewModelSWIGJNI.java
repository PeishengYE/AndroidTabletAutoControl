package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import java.math.BigInteger;

public class ServiceCaseListElementViewModelSWIGJNI
{
  public static final native void ServiceCaseListElementViewModel_CloseCase(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native int ServiceCaseListElementViewModel_Compare(long paramLong1, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel, long paramLong2, IComparable paramIComparable);
  
  public static final native BigInteger ServiceCaseListElementViewModel_GetChatEndPoint(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native int ServiceCaseListElementViewModel_GetID(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native int ServiceCaseListElementViewModel_GetIcon(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native String ServiceCaseListElementViewModel_GetName(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native String ServiceCaseListElementViewModel_GetPassword(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native boolean ServiceCaseListElementViewModel_IsCloseAllowed(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native boolean ServiceCaseListElementViewModel_IsConnectPossible(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native boolean ServiceCaseListElementViewModel_IsEditableByMe(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native boolean ServiceCaseListElementViewModel_IsTakeOverPossible(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native boolean ServiceCaseListElementViewModel_IsVisible(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native void ServiceCaseListElementViewModel_RegisterForChanges(long paramLong1, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native long ServiceCaseListElementViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native boolean ServiceCaseListElementViewModel_ShowChatTo(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native void ServiceCaseListElementViewModel_TakeOver(long paramLong, ServiceCaseListElementViewModel paramServiceCaseListElementViewModel);
  
  public static final native void delete_ServiceCaseListElementViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/ServiceCaseListElementViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */