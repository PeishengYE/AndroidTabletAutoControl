package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class GroupUIModelHelperDefinitionsSWIGJNI
{
  public static final native long IndexPath_row_get(long paramLong, IndexPath paramIndexPath);
  
  public static final native void IndexPath_row_set(long paramLong1, IndexPath paramIndexPath, long paramLong2);
  
  public static final native int IndexPath_section_get(long paramLong, IndexPath paramIndexPath);
  
  public static final native void IndexPath_section_set(long paramLong, IndexPath paramIndexPath, int paramInt);
  
  public static final native void delete_IndexPath(long paramLong);
  
  public static final native long new_IndexPath();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/GroupUIModelHelperDefinitionsSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */