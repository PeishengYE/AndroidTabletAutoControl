package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AccountViewModelLocator
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public AccountViewModelLocator(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static AccountViewModelBase GetAccountViewModelBase()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetAccountViewModelBase();
    if (l == 0L) {
      return null;
    }
    return new AccountViewModelBase(l, true);
  }
  
  public static AutoLoginViewModel GetAutoLoginViewModel()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetAutoLoginViewModel();
    if (l == 0L) {
      return null;
    }
    return new AutoLoginViewModel(l, true);
  }
  
  public static BLFragmentViewModel GetBLFragmentViewModel()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetBLFragmentViewModel();
    if (l == 0L) {
      return null;
    }
    return new BLFragmentViewModel(l, true);
  }
  
  public static ChatFragmentViewModel GetChatFragmentViewModel()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetChatFragmentViewModel();
    if (l == 0L) {
      return null;
    }
    return new ChatFragmentViewModel(l, true);
  }
  
  public static LoginViewModel GetLoginViewModel(LoginViewModel.LoginViewType paramLoginViewType)
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetLoginViewModel(paramLoginViewType.swigValue());
    if (l == 0L) {
      return null;
    }
    return new LoginViewModel(l, true);
  }
  
  public static LogoutViewModel GetLogoutViewModel()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetLogoutViewModel();
    if (l == 0L) {
      return null;
    }
    return new LogoutViewModel(l, true);
  }
  
  public static TokenLoginViewModel GetTokenLoginViewModel()
  {
    long l = AccountViewModelLocatorSWIGJNI.AccountViewModelLocator_GetTokenLoginViewModel();
    if (l == 0L) {
      return null;
    }
    return new TokenLoginViewModel(l, true);
  }
  
  public static long getCPtr(AccountViewModelLocator paramAccountViewModelLocator)
  {
    if (paramAccountViewModelLocator == null) {
      return 0L;
    }
    return paramAccountViewModelLocator.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          AccountViewModelLocatorSWIGJNI.delete_AccountViewModelLocator(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AccountViewModelLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */