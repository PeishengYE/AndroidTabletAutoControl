package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AccountViewModelLocatorSWIGJNI
{
  public static final native long AccountViewModelLocator_GetAccountViewModelBase();
  
  public static final native long AccountViewModelLocator_GetAutoLoginViewModel();
  
  public static final native long AccountViewModelLocator_GetBLFragmentViewModel();
  
  public static final native long AccountViewModelLocator_GetChatFragmentViewModel();
  
  public static final native long AccountViewModelLocator_GetLoginViewModel(int paramInt);
  
  public static final native long AccountViewModelLocator_GetLogoutViewModel();
  
  public static final native long AccountViewModelLocator_GetTokenLoginViewModel();
  
  public static final native void delete_AccountViewModelLocator(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AccountViewModelLocatorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */