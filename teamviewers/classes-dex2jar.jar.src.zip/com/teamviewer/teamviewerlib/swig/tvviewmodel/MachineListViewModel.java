package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;

public class MachineListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public MachineListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(MachineListViewModel paramMachineListViewModel)
  {
    if (paramMachineListViewModel == null) {
      return 0L;
    }
    return paramMachineListViewModel.swigCPtr;
  }
  
  public MachineId GetElement(long paramLong)
  {
    paramLong = MachineListViewModelSWIGJNI.MachineListViewModel_GetElement(this.swigCPtr, this, paramLong);
    if (paramLong == 0L) {
      return null;
    }
    return new MachineId(paramLong, true);
  }
  
  public long GetSize()
  {
    return MachineListViewModelSWIGJNI.MachineListViewModel_GetSize(this.swigCPtr, this);
  }
  
  public boolean IsContactComputerSelectionRequired()
  {
    return MachineListViewModelSWIGJNI.MachineListViewModel_IsContactComputerSelectionRequired(this.swigCPtr, this);
  }
  
  public void RegisterForChanges(IGenericSignalCallback paramIGenericSignalCallback)
  {
    MachineListViewModelSWIGJNI.MachineListViewModel_RegisterForChanges(this.swigCPtr, this, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          MachineListViewModelSWIGJNI.delete_MachineListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/MachineListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */