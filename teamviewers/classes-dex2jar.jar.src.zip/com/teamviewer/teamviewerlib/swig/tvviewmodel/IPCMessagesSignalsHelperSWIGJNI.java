package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class IPCMessagesSignalsHelperSWIGJNI
{
  public static final native void IPCMessagesSignalsHelper_RegisterForPopUpMessageChangedSlot(long paramLong1, IIPCMessagesViewModel paramIIPCMessagesViewModel, long paramLong2, MessageDataSignalCallback paramMessageDataSignalCallback);
  
  public static final native void IPCMessagesSignalsHelper_RegisterForTrayMessageChangedSlot(long paramLong1, IIPCMessagesViewModel paramIIPCMessagesViewModel, long paramLong2, MessageDataSignalCallback paramMessageDataSignalCallback);
  
  public static final native void delete_IPCMessagesSignalsHelper(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/IPCMessagesSignalsHelperSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */