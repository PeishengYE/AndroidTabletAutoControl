package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.commonviewmodel.swig.ISingleErrorResultCallback;

public class TokenLoginViewModelSWIGJNI
{
  public static final native boolean TokenLoginViewModel_IsCurrentlyLoggedIn(long paramLong, TokenLoginViewModel paramTokenLoginViewModel, String paramString);
  
  public static final native long TokenLoginViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void TokenLoginViewModel_TryLogin(long paramLong1, TokenLoginViewModel paramTokenLoginViewModel, String paramString1, String paramString2, long paramLong2, long paramLong3, ISingleErrorResultCallback paramISingleErrorResultCallback);
  
  public static final native void delete_TokenLoginViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/TokenLoginViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */