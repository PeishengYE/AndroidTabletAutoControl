package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class AutoLoginViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public AutoLoginViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(AutoLoginViewModel paramAutoLoginViewModel)
  {
    if (paramAutoLoginViewModel == null) {
      return 0L;
    }
    return paramAutoLoginViewModel.swigCPtr;
  }
  
  public void StartAutoLogin()
  {
    AutoLoginViewModelSWIGJNI.AutoLoginViewModel_StartAutoLogin(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          AutoLoginViewModelSWIGJNI.delete_AutoLoginViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/AutoLoginViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */