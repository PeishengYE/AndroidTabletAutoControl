package com.teamviewer.teamviewerlib.swig.tvviewmodel;

public class IndexPath
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IndexPath()
  {
    this(GroupUIModelHelperDefinitionsSWIGJNI.new_IndexPath(), true);
  }
  
  public IndexPath(long paramLong, GroupUIModelSection paramGroupUIModelSection)
  {
    this();
    setRow(paramLong);
    setSection(paramGroupUIModelSection);
  }
  
  public IndexPath(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IndexPath paramIndexPath)
  {
    if (paramIndexPath == null) {
      return 0L;
    }
    return paramIndexPath.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          GroupUIModelHelperDefinitionsSWIGJNI.delete_IndexPath(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long getRow()
  {
    return GroupUIModelHelperDefinitionsSWIGJNI.IndexPath_row_get(this.swigCPtr, this);
  }
  
  public GroupUIModelSection getSection()
  {
    return GroupUIModelSection.swigToEnum(GroupUIModelHelperDefinitionsSWIGJNI.IndexPath_section_get(this.swigCPtr, this));
  }
  
  public void setRow(long paramLong)
  {
    GroupUIModelHelperDefinitionsSWIGJNI.IndexPath_row_set(this.swigCPtr, this, paramLong);
  }
  
  public void setSection(GroupUIModelSection paramGroupUIModelSection)
  {
    GroupUIModelHelperDefinitionsSWIGJNI.IndexPath_section_set(this.swigCPtr, this, paramGroupUIModelSection.swigValue());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/IndexPath.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */