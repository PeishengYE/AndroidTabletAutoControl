package com.teamviewer.teamviewerlib.swig.tvviewmodel;

import com.teamviewer.teamviewerlib.swig.tvpartnerlist.PListSessionID;

public class SessionIdHelperSWIGJNI
{
  public static final native long SessionIdHelper_GetDyngateIdBySessionId(long paramLong, PListSessionID paramPListSessionID);
  
  public static final native void delete_SessionIdHelper(long paramLong);
  
  public static final native long new_SessionIdHelper();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvviewmodel/SessionIdHelperSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */