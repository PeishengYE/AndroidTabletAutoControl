package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class ILicensing
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ILicensing(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ILicensing paramILicensing)
  {
    if (paramILicensing == null) {
      return 0L;
    }
    return paramILicensing.swigCPtr;
  }
  
  public boolean IsAccountTrialExpired()
  {
    return ILicensingSWIGJNI.ILicensing_IsAccountTrialExpired(this.swigCPtr, this);
  }
  
  public boolean IsAccountTrialValid()
  {
    return ILicensingSWIGJNI.ILicensing_IsAccountTrialValid(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ILicensingSWIGJNI.delete_ILicensing(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/ILicensing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */