package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class IAccountAndroid
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IAccountAndroid(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IAccountAndroid paramIAccountAndroid)
  {
    if (paramIAccountAndroid == null) {
      return 0L;
    }
    return paramIAccountAndroid.swigCPtr;
  }
  
  public long GetAccountID()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_GetAccountID(this.swigCPtr, this);
  }
  
  public String GetAccountPictureUrl()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_GetAccountPictureUrl(this.swigCPtr, this);
  }
  
  public long GetCompanyID()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_GetCompanyID(this.swigCPtr, this);
  }
  
  public String GetDisplayName()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_GetDisplayName(this.swigCPtr, this);
  }
  
  public boolean IsLoggedIn()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_IsLoggedIn(this.swigCPtr, this);
  }
  
  public boolean IsSessionCommentingEnabled()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_IsSessionCommentingEnabled(this.swigCPtr, this);
  }
  
  public boolean IsSessionLoggingEnabled()
  {
    return IAccountAndroidSWIGJNI.IAccountAndroid_IsSessionLoggingEnabled(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IAccountAndroidSWIGJNI.delete_IAccountAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/IAccountAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */