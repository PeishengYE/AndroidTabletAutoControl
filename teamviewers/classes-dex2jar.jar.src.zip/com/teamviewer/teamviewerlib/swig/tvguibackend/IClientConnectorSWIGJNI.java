package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class IClientConnectorSWIGJNI
{
  public static final native void delete_IClientConnector(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/IClientConnectorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */