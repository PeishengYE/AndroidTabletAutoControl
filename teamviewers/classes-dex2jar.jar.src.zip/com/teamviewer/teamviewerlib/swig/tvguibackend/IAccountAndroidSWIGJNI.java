package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class IAccountAndroidSWIGJNI
{
  public static final native long IAccountAndroid_GetAccountID(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native String IAccountAndroid_GetAccountPictureUrl(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native long IAccountAndroid_GetCompanyID(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native String IAccountAndroid_GetDisplayName(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native boolean IAccountAndroid_IsLoggedIn(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native boolean IAccountAndroid_IsSessionCommentingEnabled(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native boolean IAccountAndroid_IsSessionLoggingEnabled(long paramLong, IAccountAndroid paramIAccountAndroid);
  
  public static final native void delete_IAccountAndroid(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/IAccountAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */