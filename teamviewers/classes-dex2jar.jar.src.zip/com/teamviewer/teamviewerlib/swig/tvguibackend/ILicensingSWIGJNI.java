package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class ILicensingSWIGJNI
{
  public static final native boolean ILicensing_IsAccountTrialExpired(long paramLong, ILicensing paramILicensing);
  
  public static final native boolean ILicensing_IsAccountTrialValid(long paramLong, ILicensing paramILicensing);
  
  public static final native void delete_ILicensing(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/ILicensingSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */