package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class ClientConnectParams
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ClientConnectParams()
  {
    this(ClientConnectParamsSWIGJNI.new_ClientConnectParams(), true);
  }
  
  public ClientConnectParams(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ClientConnectParams paramClientConnectParams)
  {
    if (paramClientConnectParams == null) {
      return 0L;
    }
    return paramClientConnectParams.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ClientConnectParamsSWIGJNI.delete_ClientConnectParams(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public boolean getAutoTryLastPassword()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_autoTryLastPassword_get(this.swigCPtr, this);
  }
  
  public int getConnectionMode()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_connectionMode_get(this.swigCPtr, this);
  }
  
  public String getDestination()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_destination_get(this.swigCPtr, this);
  }
  
  public int getInstantSupportFlags()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_instantSupportFlags_get(this.swigCPtr, this);
  }
  
  public String getInstantSupportSessionId()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_getInstantSupportSessionId(this.swigCPtr, this);
  }
  
  public int getPartnerSessionID()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_partnerSessionID_get(this.swigCPtr, this);
  }
  
  public long getReconnectToken()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_reconnectToken_get(this.swigCPtr, this);
  }
  
  public boolean getWinAuthOnly()
  {
    return ClientConnectParamsSWIGJNI.ClientConnectParams_winAuthOnly_get(this.swigCPtr, this);
  }
  
  public void setAutoTryLastPassword(boolean paramBoolean)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_autoTryLastPassword_set(this.swigCPtr, this, paramBoolean);
  }
  
  public void setConnectionMode(int paramInt)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_connectionMode_set(this.swigCPtr, this, paramInt);
  }
  
  public void setDestination(String paramString)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_destination_set(this.swigCPtr, this, paramString);
  }
  
  public void setInstantSupportFlags(int paramInt)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_instantSupportFlags_set(this.swigCPtr, this, paramInt);
  }
  
  public void setInstantSupportSessionId(String paramString)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_setInstantSupportSessionId(this.swigCPtr, this, paramString);
  }
  
  public void setPartnerSessionID(int paramInt)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_partnerSessionID_set(this.swigCPtr, this, paramInt);
  }
  
  public void setReconnectToken(long paramLong)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_reconnectToken_set(this.swigCPtr, this, paramLong);
  }
  
  public void setUseEasyAccess(String paramString)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_setUseEasyAccess(this.swigCPtr, this, paramString);
  }
  
  public void setWinAuthOnly(boolean paramBoolean)
  {
    ClientConnectParamsSWIGJNI.ClientConnectParams_winAuthOnly_set(this.swigCPtr, this, paramBoolean);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/ClientConnectParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */