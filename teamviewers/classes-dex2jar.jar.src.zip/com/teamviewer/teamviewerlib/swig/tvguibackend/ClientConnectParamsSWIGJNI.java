package com.teamviewer.teamviewerlib.swig.tvguibackend;

public class ClientConnectParamsSWIGJNI
{
  public static final native boolean ClientConnectParams_autoTryLastPassword_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_autoTryLastPassword_set(long paramLong, ClientConnectParams paramClientConnectParams, boolean paramBoolean);
  
  public static final native int ClientConnectParams_connectionMode_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_connectionMode_set(long paramLong, ClientConnectParams paramClientConnectParams, int paramInt);
  
  public static final native String ClientConnectParams_destination_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_destination_set(long paramLong, ClientConnectParams paramClientConnectParams, String paramString);
  
  public static final native String ClientConnectParams_getInstantSupportSessionId(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native int ClientConnectParams_instantSupportFlags_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_instantSupportFlags_set(long paramLong, ClientConnectParams paramClientConnectParams, int paramInt);
  
  public static final native int ClientConnectParams_partnerSessionID_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_partnerSessionID_set(long paramLong, ClientConnectParams paramClientConnectParams, int paramInt);
  
  public static final native long ClientConnectParams_reconnectToken_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_reconnectToken_set(long paramLong1, ClientConnectParams paramClientConnectParams, long paramLong2);
  
  public static final native void ClientConnectParams_setInstantSupportSessionId(long paramLong, ClientConnectParams paramClientConnectParams, String paramString);
  
  public static final native void ClientConnectParams_setUseEasyAccess(long paramLong, ClientConnectParams paramClientConnectParams, String paramString);
  
  public static final native boolean ClientConnectParams_winAuthOnly_get(long paramLong, ClientConnectParams paramClientConnectParams);
  
  public static final native void ClientConnectParams_winAuthOnly_set(long paramLong, ClientConnectParams paramClientConnectParams, boolean paramBoolean);
  
  public static final native void delete_ClientConnectParams(long paramLong);
  
  public static final native long new_ClientConnectParams();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvguibackend/ClientConnectParamsSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */