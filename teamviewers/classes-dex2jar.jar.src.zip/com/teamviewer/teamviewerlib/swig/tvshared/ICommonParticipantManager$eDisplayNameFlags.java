package com.teamviewer.teamviewerlib.swig.tvshared;

public final class ICommonParticipantManager$eDisplayNameFlags
{
  public static final int DNF_APPEND_ID = 1;
  public static final int DNF_APPEND_ROLE = 2;
  public static final int DNF_DEFAULT = 56;
  public static final int DNF_MT_APPEND_ROLE = 64;
  public static final int DNF_NONE = 0;
  public static final int DNF_OS_APPEND_ID = 16;
  public static final int DNF_OS_PREFER_ALIAS = 32;
  public static final int DNF_SHOW_NAME_FOR_MAGIC_IDS = 8;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/ICommonParticipantManager$eDisplayNameFlags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */