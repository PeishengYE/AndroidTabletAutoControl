package com.teamviewer.teamviewerlib.swig.tvshared;

public final class IBaseParticipantManager$RCAccessControlState
{
  public static final int RCAccessControlState_AnswerReceived = 2;
  public static final int RCAccessControlState_LocalSet = 1;
  public static final int RCAccessControlState_Undefined = 0;
  public static final int RCAccessControlState_UserAnswerToMsgBox = 3;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/IBaseParticipantManager$RCAccessControlState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */