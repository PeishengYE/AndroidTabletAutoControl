package com.teamviewer.teamviewerlib.swig.tvshared;

import com.teamviewer.teamviewerlib.swig.tvhelper.DataStream;
import com.teamviewer.teamviewerlib.swig.tvhelper.ParticipantIdentifier;

public class ParticipantManagerSWIGJNI
{
  public static final native void IBaseParticipantManager_ActivateWhiteboard(long paramLong, IBaseParticipantManager paramIBaseParticipantManager, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToActivateWhiteboard(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToChat(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToDownloadFiles(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToDraw(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToListen(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToPoint(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToRemoteCtrl(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToSeeInvisible(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToSeeVideo(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToShowVideo(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToSpeak(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowToUploadFiles(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_AllowedToActivateWhiteboard(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToAssignOrganizer(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToAssignPresenter(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToChat(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToDisplayMeetingId(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToDisplayPassword(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToDownloadFiles(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToDraw(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToListen(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToPoint(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToRemoteCtrl(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToSeeInvisible(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToSeeVideo(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToSendChat(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToShowVideo(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToSpeak(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AllowedToUploadFiles(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_AmIOrganizer(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_AmIPresenter(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_CanChat(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanDrawWhiteboard(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanPoint(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanRemoteControl(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanShowVideo(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanSpeak(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_CanUploadFiles(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long IBaseParticipantManager_GetAllVisible(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_GetMeetingSetting(long paramLong, IBaseParticipantManager paramIBaseParticipantManager, int paramInt);
  
  public static final native long IBaseParticipantManager_GetMyParticipantIdentifier(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native long IBaseParticipantManager_GetParticipantCount(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native long IBaseParticipantManager_GetParticipantIDs(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native int IBaseParticipantManager_GetParticipantType(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long IBaseParticipantManager_GetPresenter(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native int IBaseParticipantManager_GetRegStream(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, long paramLong3, DataStream paramDataStream);
  
  public static final native long IBaseParticipantManager_GetRegStreamID(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, int paramInt);
  
  public static final native long IBaseParticipantManager_GetStreamSource(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2);
  
  public static final native long IBaseParticipantManager_GetSupportedStreamFeatures(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, int paramInt);
  
  public static final native int IBaseParticipantManager_GetSyncState(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_HasParticipant(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_IsAudioCall(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_IsAudioInteractionAllowed(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_IsFullyCompatible(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_IsOrganizer(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native int IBaseParticipantManager_IsParticipantVisible(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_IsPresenter(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_IsPresenterHandingOverPossible(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean IBaseParticipantManager_IsRecordMeetingAllowed(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_IsVideoChat(long paramLong, IBaseParticipantManager paramIBaseParticipantManager);
  
  public static final native boolean IBaseParticipantManager_SetAccountPictureURL(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, String paramString);
  
  public static final native void IBaseParticipantManager_SetMeetingMode(long paramLong, IBaseParticipantManager paramIBaseParticipantManager, boolean paramBoolean1, boolean paramBoolean2);
  
  public static final native boolean IBaseParticipantManager_SetMyAccountData(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, String paramString1, String paramString2);
  
  public static final native void IBaseParticipantManager_SetMyParticipantIdentifier(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native int IBaseParticipantManager_SetOrganizer(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_SetParticipantName(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, String paramString);
  
  public static final native int IBaseParticipantManager_SetPresenter(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean);
  
  public static final native boolean IBaseParticipantManager_SubscribeStreamIfSupported(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2, DataStream paramDataStream);
  
  public static final native int IBaseParticipantManager_TranslateStreamType(int paramInt);
  
  public static final native void IBaseParticipantManager_UnsubscribeStream(long paramLong1, IBaseParticipantManager paramIBaseParticipantManager, long paramLong2);
  
  public static final native boolean ICommonParticipantManager_AllowedToDownloadFilesSC(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean ICommonParticipantManager_AllowedToShareFilesWithPresentersSC(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean ICommonParticipantManager_AllowedToShareFilesWithVisibleSC(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native boolean ICommonParticipantManager_AllowedToUseFileshareWidget(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native String ICommonParticipantManager_GetNameOfParticipant__SWIG_0(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier, int paramInt);
  
  public static final native String ICommonParticipantManager_GetNameOfParticipant__SWIG_1(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native String ICommonParticipantManager_GetNameOfUniquePartnerOrMeetingID__SWIG_0(long paramLong, ICommonParticipantManager paramICommonParticipantManager, int paramInt);
  
  public static final native String ICommonParticipantManager_GetNameOfUniquePartnerOrMeetingID__SWIG_1(long paramLong, ICommonParticipantManager paramICommonParticipantManager);
  
  public static final native long ICommonParticipantManager_GetOutgoingStreamID(long paramLong, ICommonParticipantManager paramICommonParticipantManager, int paramInt);
  
  public static final native long ICommonParticipantManager_GetPIDOfUniquePartner(long paramLong, ICommonParticipantManager paramICommonParticipantManager);
  
  public static final native long ICommonParticipantManager_GetParticipant(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long ICommonParticipantManager_GetSortedParticipantList(long paramLong, ICommonParticipantManager paramICommonParticipantManager);
  
  public static final native void ICommonParticipantManager_PendingParticipant_Accept(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native void ICommonParticipantManager_PendingParticipant_Deny(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native void ICommonParticipantManager_PendingParticipant_Whitelist_Add(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, boolean paramBoolean);
  
  public static final native void ICommonParticipantManager_PendingParticipant_Whitelist_Remove(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, long paramLong2, boolean paramBoolean);
  
  public static final native boolean ICommonParticipantManager_RegisterNewStreamWithoutCallback(long paramLong1, ICommonParticipantManager paramICommonParticipantManager, int paramInt1, int paramInt2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, boolean paramBoolean3, long paramLong2, long paramLong3, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long ICommonParticipantManager_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void ICommonParticipantManager_StartFullSynchronisation(long paramLong, ICommonParticipantManager paramICommonParticipantManager, int paramInt);
  
  public static final native void TParticipantIdentifierVector_add(long paramLong1, TParticipantIdentifierVector paramTParticipantIdentifierVector, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long TParticipantIdentifierVector_capacity(long paramLong, TParticipantIdentifierVector paramTParticipantIdentifierVector);
  
  public static final native void TParticipantIdentifierVector_clear(long paramLong, TParticipantIdentifierVector paramTParticipantIdentifierVector);
  
  public static final native long TParticipantIdentifierVector_get(long paramLong, TParticipantIdentifierVector paramTParticipantIdentifierVector, int paramInt);
  
  public static final native boolean TParticipantIdentifierVector_isEmpty(long paramLong, TParticipantIdentifierVector paramTParticipantIdentifierVector);
  
  public static final native void TParticipantIdentifierVector_reserve(long paramLong1, TParticipantIdentifierVector paramTParticipantIdentifierVector, long paramLong2);
  
  public static final native void TParticipantIdentifierVector_set(long paramLong1, TParticipantIdentifierVector paramTParticipantIdentifierVector, int paramInt, long paramLong2, ParticipantIdentifier paramParticipantIdentifier);
  
  public static final native long TParticipantIdentifierVector_size(long paramLong, TParticipantIdentifierVector paramTParticipantIdentifierVector);
  
  public static final native void VectorLong_add(long paramLong1, VectorLong paramVectorLong, long paramLong2);
  
  public static final native long VectorLong_capacity(long paramLong, VectorLong paramVectorLong);
  
  public static final native void VectorLong_clear(long paramLong, VectorLong paramVectorLong);
  
  public static final native long VectorLong_get(long paramLong, VectorLong paramVectorLong, int paramInt);
  
  public static final native boolean VectorLong_isEmpty(long paramLong, VectorLong paramVectorLong);
  
  public static final native void VectorLong_reserve(long paramLong1, VectorLong paramVectorLong, long paramLong2);
  
  public static final native void VectorLong_set(long paramLong1, VectorLong paramVectorLong, int paramInt, long paramLong2);
  
  public static final native long VectorLong_size(long paramLong, VectorLong paramVectorLong);
  
  public static final native void delete_IBaseParticipantManager(long paramLong);
  
  public static final native void delete_ICommonParticipantManager(long paramLong);
  
  public static final native void delete_TParticipantIdentifierVector(long paramLong);
  
  public static final native void delete_VectorLong(long paramLong);
  
  public static final native long new_TParticipantIdentifierVector__SWIG_0();
  
  public static final native long new_TParticipantIdentifierVector__SWIG_1(long paramLong);
  
  public static final native long new_VectorLong__SWIG_0();
  
  public static final native long new_VectorLong__SWIG_1(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/ParticipantManagerSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */