package com.teamviewer.teamviewerlib.swig.tvshared;

import com.teamviewer.teamviewerlib.swig.tvhelper.ParticipantIdentifier;

public class TParticipantIdentifierVector
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public TParticipantIdentifierVector()
  {
    this(ParticipantManagerSWIGJNI.new_TParticipantIdentifierVector__SWIG_0(), true);
  }
  
  public TParticipantIdentifierVector(long paramLong)
  {
    this(ParticipantManagerSWIGJNI.new_TParticipantIdentifierVector__SWIG_1(paramLong), true);
  }
  
  public TParticipantIdentifierVector(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(TParticipantIdentifierVector paramTParticipantIdentifierVector)
  {
    if (paramTParticipantIdentifierVector == null) {
      return 0L;
    }
    return paramTParticipantIdentifierVector.swigCPtr;
  }
  
  public void add(ParticipantIdentifier paramParticipantIdentifier)
  {
    ParticipantManagerSWIGJNI.TParticipantIdentifierVector_add(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public long capacity()
  {
    return ParticipantManagerSWIGJNI.TParticipantIdentifierVector_capacity(this.swigCPtr, this);
  }
  
  public void clear()
  {
    ParticipantManagerSWIGJNI.TParticipantIdentifierVector_clear(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantManagerSWIGJNI.delete_TParticipantIdentifierVector(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public ParticipantIdentifier get(int paramInt)
  {
    return new ParticipantIdentifier(ParticipantManagerSWIGJNI.TParticipantIdentifierVector_get(this.swigCPtr, this, paramInt), false);
  }
  
  public boolean isEmpty()
  {
    return ParticipantManagerSWIGJNI.TParticipantIdentifierVector_isEmpty(this.swigCPtr, this);
  }
  
  public void reserve(long paramLong)
  {
    ParticipantManagerSWIGJNI.TParticipantIdentifierVector_reserve(this.swigCPtr, this, paramLong);
  }
  
  public void set(int paramInt, ParticipantIdentifier paramParticipantIdentifier)
  {
    ParticipantManagerSWIGJNI.TParticipantIdentifierVector_set(this.swigCPtr, this, paramInt, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public long size()
  {
    return ParticipantManagerSWIGJNI.TParticipantIdentifierVector_size(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/TParticipantIdentifierVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */