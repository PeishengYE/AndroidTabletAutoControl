package com.teamviewer.teamviewerlib.swig.tvshared;

import com.teamviewer.teamviewerlib.swig.tvhelper.CParticipant;
import com.teamviewer.teamviewerlib.swig.tvhelper.ParticipantIdentifier;

public class ICommonParticipantManager
  extends IBaseParticipantManager
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public ICommonParticipantManager(long paramLong, boolean paramBoolean)
  {
    super(ParticipantManagerSWIGJNI.ICommonParticipantManager_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ICommonParticipantManager paramICommonParticipantManager)
  {
    if (paramICommonParticipantManager == null) {
      return 0L;
    }
    return paramICommonParticipantManager.swigCPtr;
  }
  
  public boolean AllowedToDownloadFilesSC(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_AllowedToDownloadFilesSC(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToShareFilesWithPresentersSC(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_AllowedToShareFilesWithPresentersSC(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToShareFilesWithVisibleSC(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_AllowedToShareFilesWithVisibleSC(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToUseFileshareWidget(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_AllowedToUseFileshareWidget(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public String GetNameOfParticipant(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_GetNameOfParticipant__SWIG_1(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public String GetNameOfParticipant(ParticipantIdentifier paramParticipantIdentifier, int paramInt)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_GetNameOfParticipant__SWIG_0(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramInt);
  }
  
  public String GetNameOfUniquePartnerOrMeetingID()
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_GetNameOfUniquePartnerOrMeetingID__SWIG_1(this.swigCPtr, this);
  }
  
  public String GetNameOfUniquePartnerOrMeetingID(int paramInt)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_GetNameOfUniquePartnerOrMeetingID__SWIG_0(this.swigCPtr, this, paramInt);
  }
  
  public long GetOutgoingStreamID(int paramInt)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_GetOutgoingStreamID(this.swigCPtr, this, paramInt);
  }
  
  public ParticipantIdentifier GetPIDOfUniquePartner()
  {
    return new ParticipantIdentifier(ParticipantManagerSWIGJNI.ICommonParticipantManager_GetPIDOfUniquePartner(this.swigCPtr, this), true);
  }
  
  public CParticipant GetParticipant(ParticipantIdentifier paramParticipantIdentifier)
  {
    return new CParticipant(ParticipantManagerSWIGJNI.ICommonParticipantManager_GetParticipant(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier), true);
  }
  
  public TParticipantIdentifierVector GetSortedParticipantList()
  {
    return new TParticipantIdentifierVector(ParticipantManagerSWIGJNI.ICommonParticipantManager_GetSortedParticipantList(this.swigCPtr, this), true);
  }
  
  public void PendingParticipant_Accept(ParticipantIdentifier paramParticipantIdentifier)
  {
    ParticipantManagerSWIGJNI.ICommonParticipantManager_PendingParticipant_Accept(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public void PendingParticipant_Deny(ParticipantIdentifier paramParticipantIdentifier)
  {
    ParticipantManagerSWIGJNI.ICommonParticipantManager_PendingParticipant_Deny(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public void PendingParticipant_Whitelist_Add(long paramLong, boolean paramBoolean)
  {
    ParticipantManagerSWIGJNI.ICommonParticipantManager_PendingParticipant_Whitelist_Add(this.swigCPtr, this, paramLong, paramBoolean);
  }
  
  public void PendingParticipant_Whitelist_Remove(long paramLong, boolean paramBoolean)
  {
    ParticipantManagerSWIGJNI.ICommonParticipantManager_PendingParticipant_Whitelist_Remove(this.swigCPtr, this, paramLong, paramBoolean);
  }
  
  public boolean RegisterNewStreamWithoutCallback(int paramInt1, int paramInt2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2, boolean paramBoolean3, long paramLong, ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.ICommonParticipantManager_RegisterNewStreamWithoutCallback(this.swigCPtr, this, paramInt1, paramInt2, paramBoolean1, paramInt3, paramBoolean2, paramBoolean3, paramLong, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public void StartFullSynchronisation(int paramInt)
  {
    ParticipantManagerSWIGJNI.ICommonParticipantManager_StartFullSynchronisation(this.swigCPtr, this, paramInt);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          ParticipantManagerSWIGJNI.delete_ICommonParticipantManager(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/ICommonParticipantManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */