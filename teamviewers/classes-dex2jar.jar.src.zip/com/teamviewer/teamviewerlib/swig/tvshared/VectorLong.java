package com.teamviewer.teamviewerlib.swig.tvshared;

public class VectorLong
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public VectorLong()
  {
    this(ParticipantManagerSWIGJNI.new_VectorLong__SWIG_0(), true);
  }
  
  public VectorLong(long paramLong)
  {
    this(ParticipantManagerSWIGJNI.new_VectorLong__SWIG_1(paramLong), true);
  }
  
  public VectorLong(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(VectorLong paramVectorLong)
  {
    if (paramVectorLong == null) {
      return 0L;
    }
    return paramVectorLong.swigCPtr;
  }
  
  public void add(long paramLong)
  {
    ParticipantManagerSWIGJNI.VectorLong_add(this.swigCPtr, this, paramLong);
  }
  
  public long capacity()
  {
    return ParticipantManagerSWIGJNI.VectorLong_capacity(this.swigCPtr, this);
  }
  
  public void clear()
  {
    ParticipantManagerSWIGJNI.VectorLong_clear(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantManagerSWIGJNI.delete_VectorLong(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public long get(int paramInt)
  {
    return ParticipantManagerSWIGJNI.VectorLong_get(this.swigCPtr, this, paramInt);
  }
  
  public boolean isEmpty()
  {
    return ParticipantManagerSWIGJNI.VectorLong_isEmpty(this.swigCPtr, this);
  }
  
  public void reserve(long paramLong)
  {
    ParticipantManagerSWIGJNI.VectorLong_reserve(this.swigCPtr, this, paramLong);
  }
  
  public void set(int paramInt, long paramLong)
  {
    ParticipantManagerSWIGJNI.VectorLong_set(this.swigCPtr, this, paramInt, paramLong);
  }
  
  public long size()
  {
    return ParticipantManagerSWIGJNI.VectorLong_size(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/VectorLong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */