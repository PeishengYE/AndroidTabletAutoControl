package com.teamviewer.teamviewerlib.swig.tvshared;

public final class IBaseParticipantManager$ESyncState
{
  public static final int NotSynced = 0;
  public static final int Synced = 2;
  public static final int Syncing = 1;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/IBaseParticipantManager$ESyncState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */