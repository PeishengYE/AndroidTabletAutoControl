package com.teamviewer.teamviewerlib.swig.tvshared;

public final class IBaseParticipantManager$eReturnType
{
  public static final int RT_FALSE = 1;
  public static final int RT_NONE = 0;
  public static final int RT_SYNCHRONIZING = 3;
  public static final int RT_TRUE = 2;
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/IBaseParticipantManager$eReturnType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */