package com.teamviewer.teamviewerlib.swig.tvshared;

public class ParticipantManagerFactoryAndroid
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ParticipantManagerFactoryAndroid(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static ICommonParticipantManager Create(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    long l = ParticipantManagerFactoryAndroidSWIGJNI.ParticipantManagerFactoryAndroid_Create(paramInt1, paramInt2, paramBoolean);
    if (l == 0L) {
      return null;
    }
    return new ICommonParticipantManager(l, true);
  }
  
  public static void Shutdown() {}
  
  public static long getCPtr(ParticipantManagerFactoryAndroid paramParticipantManagerFactoryAndroid)
  {
    if (paramParticipantManagerFactoryAndroid == null) {
      return 0L;
    }
    return paramParticipantManagerFactoryAndroid.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantManagerFactoryAndroidSWIGJNI.delete_ParticipantManagerFactoryAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/ParticipantManagerFactoryAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */