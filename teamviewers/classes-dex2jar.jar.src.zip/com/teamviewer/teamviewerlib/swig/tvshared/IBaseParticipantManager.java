package com.teamviewer.teamviewerlib.swig.tvshared;

import com.teamviewer.teamviewerlib.swig.tvhelper.DataStream;
import com.teamviewer.teamviewerlib.swig.tvhelper.ParticipantIdentifier;

public class IBaseParticipantManager
{
  public static final long MAX_MEETING_NAME_LEN = 50L;
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IBaseParticipantManager(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static int TranslateStreamType(int paramInt)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_TranslateStreamType(paramInt);
  }
  
  public static long getCPtr(IBaseParticipantManager paramIBaseParticipantManager)
  {
    if (paramIBaseParticipantManager == null) {
      return 0L;
    }
    return paramIBaseParticipantManager.swigCPtr;
  }
  
  public void ActivateWhiteboard(boolean paramBoolean)
  {
    ParticipantManagerSWIGJNI.IBaseParticipantManager_ActivateWhiteboard(this.swigCPtr, this, paramBoolean);
  }
  
  public boolean AllowToActivateWhiteboard(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToActivateWhiteboard(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToChat(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToChat(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToDownloadFiles(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToDownloadFiles(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToDraw(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToDraw(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToListen(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToListen(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToPoint(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToPoint(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToRemoteCtrl(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToRemoteCtrl(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToSeeInvisible(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToSeeInvisible(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToSeeVideo(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToSeeVideo(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToShowVideo(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToShowVideo(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToSpeak(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToSpeak(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowToUploadFiles(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowToUploadFiles(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean AllowedToActivateWhiteboard(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToActivateWhiteboard(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToAssignOrganizer(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToAssignOrganizer(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToAssignPresenter(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToAssignPresenter(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToChat(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToChat(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToDisplayMeetingId(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToDisplayMeetingId(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToDisplayPassword(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToDisplayPassword(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToDownloadFiles(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToDownloadFiles(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToDraw(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToDraw(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToListen(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToListen(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToPoint(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToPoint(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToRemoteCtrl(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToRemoteCtrl(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToSeeInvisible(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToSeeInvisible(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToSeeVideo(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToSeeVideo(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToSendChat(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToSendChat(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToShowVideo(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToShowVideo(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToSpeak(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToSpeak(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AllowedToUploadFiles(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AllowedToUploadFiles(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean AmIOrganizer()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AmIOrganizer(this.swigCPtr, this);
  }
  
  public boolean AmIPresenter()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_AmIPresenter(this.swigCPtr, this);
  }
  
  public boolean CanChat(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanChat(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanDrawWhiteboard(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanDrawWhiteboard(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanPoint(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanPoint(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanRemoteControl(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanRemoteControl(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanShowVideo(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanShowVideo(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanSpeak(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanSpeak(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean CanUploadFiles(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_CanUploadFiles(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public TParticipantIdentifierVector GetAllVisible()
  {
    return new TParticipantIdentifierVector(ParticipantManagerSWIGJNI.IBaseParticipantManager_GetAllVisible(this.swigCPtr, this), true);
  }
  
  public boolean GetMeetingSetting(int paramInt)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetMeetingSetting(this.swigCPtr, this, paramInt);
  }
  
  public ParticipantIdentifier GetMyParticipantIdentifier()
  {
    return new ParticipantIdentifier(ParticipantManagerSWIGJNI.IBaseParticipantManager_GetMyParticipantIdentifier(this.swigCPtr, this), true);
  }
  
  public long GetParticipantCount()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetParticipantCount(this.swigCPtr, this);
  }
  
  public TParticipantIdentifierVector GetParticipantIDs()
  {
    return new TParticipantIdentifierVector(ParticipantManagerSWIGJNI.IBaseParticipantManager_GetParticipantIDs(this.swigCPtr, this), true);
  }
  
  public int GetParticipantType(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetParticipantType(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public ParticipantIdentifier GetPresenter()
  {
    return new ParticipantIdentifier(ParticipantManagerSWIGJNI.IBaseParticipantManager_GetPresenter(this.swigCPtr, this), true);
  }
  
  public int GetRegStream(long paramLong, DataStream paramDataStream)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetRegStream(this.swigCPtr, this, paramLong, DataStream.getCPtr(paramDataStream), paramDataStream);
  }
  
  public long GetRegStreamID(ParticipantIdentifier paramParticipantIdentifier, int paramInt)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetRegStreamID(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramInt);
  }
  
  public ParticipantIdentifier GetStreamSource(long paramLong)
  {
    return new ParticipantIdentifier(ParticipantManagerSWIGJNI.IBaseParticipantManager_GetStreamSource(this.swigCPtr, this, paramLong), true);
  }
  
  public long GetSupportedStreamFeatures(ParticipantIdentifier paramParticipantIdentifier, int paramInt)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetSupportedStreamFeatures(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramInt);
  }
  
  public int GetSyncState()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_GetSyncState(this.swigCPtr, this);
  }
  
  public boolean HasParticipant(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_HasParticipant(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsAudioCall()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsAudioCall(this.swigCPtr, this);
  }
  
  public boolean IsAudioInteractionAllowed()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsAudioInteractionAllowed(this.swigCPtr, this);
  }
  
  public boolean IsFullyCompatible(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsFullyCompatible(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsOrganizer(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsOrganizer(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public int IsParticipantVisible(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsParticipantVisible(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsPresenter(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsPresenter(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsPresenterHandingOverPossible(ParticipantIdentifier paramParticipantIdentifier)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsPresenterHandingOverPossible(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public boolean IsRecordMeetingAllowed()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsRecordMeetingAllowed(this.swigCPtr, this);
  }
  
  public boolean IsVideoChat()
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_IsVideoChat(this.swigCPtr, this);
  }
  
  public boolean SetAccountPictureURL(ParticipantIdentifier paramParticipantIdentifier, String paramString)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SetAccountPictureURL(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramString);
  }
  
  public void SetMeetingMode(boolean paramBoolean1, boolean paramBoolean2)
  {
    ParticipantManagerSWIGJNI.IBaseParticipantManager_SetMeetingMode(this.swigCPtr, this, paramBoolean1, paramBoolean2);
  }
  
  public boolean SetMyAccountData(long paramLong, String paramString1, String paramString2)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SetMyAccountData(this.swigCPtr, this, paramLong, paramString1, paramString2);
  }
  
  public void SetMyParticipantIdentifier(ParticipantIdentifier paramParticipantIdentifier)
  {
    ParticipantManagerSWIGJNI.IBaseParticipantManager_SetMyParticipantIdentifier(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier);
  }
  
  public int SetOrganizer(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SetOrganizer(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean SetParticipantName(ParticipantIdentifier paramParticipantIdentifier, String paramString)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SetParticipantName(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramString);
  }
  
  public int SetPresenter(ParticipantIdentifier paramParticipantIdentifier, boolean paramBoolean)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SetPresenter(this.swigCPtr, this, ParticipantIdentifier.getCPtr(paramParticipantIdentifier), paramParticipantIdentifier, paramBoolean);
  }
  
  public boolean SubscribeStreamIfSupported(DataStream paramDataStream)
  {
    return ParticipantManagerSWIGJNI.IBaseParticipantManager_SubscribeStreamIfSupported(this.swigCPtr, this, DataStream.getCPtr(paramDataStream), paramDataStream);
  }
  
  public void UnsubscribeStream(long paramLong)
  {
    ParticipantManagerSWIGJNI.IBaseParticipantManager_UnsubscribeStream(this.swigCPtr, this, paramLong);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ParticipantManagerSWIGJNI.delete_IBaseParticipantManager(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/swig/tvshared/IBaseParticipantManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */