package com.teamviewer.teamviewerlib.helper;

public class ControlFileConnector
{
  public static String a(String paramString)
  {
    return jniGetChecksum(paramString);
  }
  
  private static native String jniGetChecksum(String paramString);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/helper/ControlFileConnector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */