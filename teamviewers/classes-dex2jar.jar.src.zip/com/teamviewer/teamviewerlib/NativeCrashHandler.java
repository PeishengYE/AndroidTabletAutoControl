package com.teamviewer.teamviewerlib;

import com.teamviewer.corelib.logging.Logging;
import o.byi;
import o.bys;
import o.byv;

public class NativeCrashHandler
{
  @byv
  private static void makeCrashReport(String paramString1, String paramString2, StackTraceElement[] paramArrayOfStackTraceElement, int paramInt)
  {
    if (paramArrayOfStackTraceElement != null) {
      byi.a = paramArrayOfStackTraceElement;
    }
    if ((paramString2 == null) || (paramString2.length() == 0)) {}
    for (paramString1 = new byi(paramString1, paramInt);; paramString1 = new byi(paramString1, paramString2, paramInt))
    {
      paramString2 = bys.b();
      if (paramString2 == null) {
        break;
      }
      paramString2.uncaughtException(Thread.currentThread(), paramString1);
      return;
    }
    Logging.d("NativeCrashHandler", "TVExceptionHandler is null");
    throw paramString1;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/NativeCrashHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */