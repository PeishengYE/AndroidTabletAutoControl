package com.teamviewer.teamviewerlib.gui;

import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.gui.dialogs.DialogID;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData;
import com.teamviewer.teamviewerlib.gui.dialogs.TVDialogListenerMetaData.Button;
import o.byo;
import o.byr;
import o.byt;
import o.byv;
import o.cfx;
import o.cga;
import o.cgb;
import o.cgc;
import o.cgd;
import o.cge;
import o.cgt;
import o.cgu;
import o.cgv;
import o.chb;
import o.cho;
import o.cif;
import o.ciy;

public class UIConnector
{
  public static final cgv cancelListener = new cgd();
  public static final cgv negativeListener;
  public static final cgv neutralListener;
  public static final cgv positiveListener = new cga();
  
  static
  {
    negativeListener = new cgb();
    neutralListener = new cgc();
  }
  
  private static boolean a(String paramString)
  {
    return ciy.a(byr.tv_IDS_NONCOMMERCIAL_TITLE).equals(paramString);
  }
  
  private static void b(String paramString)
  {
    cif.a.a(new cge(paramString));
  }
  
  private static void b(cgu paramcgu, TVDialogListenerMetaData.Button paramButton)
  {
    DialogID localDialogID = paramcgu.W();
    jniOnClickCallback(localDialogID.a, localDialogID.b, paramButton.a());
    paramcgu.a();
  }
  
  private static native void jniOnClickCallback(int paramInt1, int paramInt2, int paramInt3);
  
  @byv
  public static void showDialog(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean)
  {
    if (byt.e)
    {
      if (a(paramString1))
      {
        Logging.b("UIConnector", "show sponsored session dialog");
        cfx.a(cfx.a(paramString1, paramString2, paramString1, byo.tv_notification_icon, false, 6), 5);
      }
    }
    else if ((byt.g) && (a(paramString1)))
    {
      Logging.b("UIConnector", "Show sponsored session custom toast");
      b(paramString2);
      return;
    }
    paramString6 = new DialogID(paramInt1, paramInt2);
    chb localchb = cgt.a();
    cgu localcgu = localchb.a(paramString6);
    if (!cho.h(paramString1)) {
      localcgu.d(paramString1);
    }
    localcgu.e(paramString2);
    if (!cho.h(paramString3))
    {
      localcgu.f(paramString3);
      localchb.a(UIConnector.class, new TVDialogListenerMetaData("positiveListener", paramString6, TVDialogListenerMetaData.Button.b));
    }
    if (!cho.h(paramString4))
    {
      localcgu.g(paramString4);
      localchb.a(UIConnector.class, new TVDialogListenerMetaData("negativeListener", paramString6, TVDialogListenerMetaData.Button.c));
    }
    if (!cho.h(paramString5))
    {
      localcgu.h(paramString5);
      localchb.a(UIConnector.class, new TVDialogListenerMetaData("neutralListener", paramString6, TVDialogListenerMetaData.Button.d));
    }
    localchb.a(UIConnector.class, new TVDialogListenerMetaData("cancelListener", paramString6, TVDialogListenerMetaData.Button.a));
    localcgu.U();
  }
  
  @byv
  public static void showToast(String paramString)
  {
    cfx.a(paramString);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/gui/UIConnector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */