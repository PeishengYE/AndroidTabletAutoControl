package com.teamviewer.teamviewerlib.gui.dialogs;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import o.cgx;

public class TVDialogListenerMetaData
  implements Parcelable
{
  public static final Parcelable.Creator<TVDialogListenerMetaData> CREATOR = new cgx();
  private final String a;
  private final DialogID b;
  private final TVDialogListenerMetaData.Button c;
  
  private TVDialogListenerMetaData(Parcel paramParcel)
  {
    this.a = paramParcel.readString();
    this.b = new DialogID(paramParcel.readInt(), paramParcel.readInt());
    this.c = ((TVDialogListenerMetaData.Button)paramParcel.readParcelable(getClass().getClassLoader()));
  }
  
  public TVDialogListenerMetaData(String paramString, DialogID paramDialogID, TVDialogListenerMetaData.Button paramButton)
  {
    this.a = paramString;
    this.b = paramDialogID;
    this.c = paramButton;
  }
  
  public String a()
  {
    return this.a;
  }
  
  public boolean a(TVDialogListenerMetaData paramTVDialogListenerMetaData)
  {
    return (paramTVDialogListenerMetaData.c().equals(c())) && (paramTVDialogListenerMetaData.b().equals(b()));
  }
  
  public DialogID b()
  {
    return this.b;
  }
  
  public TVDialogListenerMetaData.Button c()
  {
    return this.c;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    return (this == paramObject) || (((paramObject instanceof TVDialogListenerMetaData)) && (a((TVDialogListenerMetaData)paramObject)));
  }
  
  public int hashCode()
  {
    return this.b.hashCode() * 17 + c().hashCode();
  }
  
  public String toString()
  {
    return String.valueOf(this.b) + " " + this.c.toString() + " " + this.a;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.a);
    paramParcel.writeInt(this.b.a);
    paramParcel.writeInt(this.b.b);
    paramParcel.writeParcelable(this.c, paramInt);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/gui/dialogs/TVDialogListenerMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */