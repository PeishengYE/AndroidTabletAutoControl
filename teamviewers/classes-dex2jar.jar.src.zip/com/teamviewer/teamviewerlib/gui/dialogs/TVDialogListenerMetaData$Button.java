package com.teamviewer.teamviewerlib.gui.dialogs;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import o.cgy;

public enum TVDialogListenerMetaData$Button
  implements Parcelable
{
  public static final Parcelable.Creator<Button> CREATOR = new cgy();
  private final byte h;
  
  private TVDialogListenerMetaData$Button(int paramInt)
  {
    this.h = ((byte)paramInt);
  }
  
  public final byte a()
  {
    return this.h;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(ordinal());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/gui/dialogs/TVDialogListenerMetaData$Button.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */