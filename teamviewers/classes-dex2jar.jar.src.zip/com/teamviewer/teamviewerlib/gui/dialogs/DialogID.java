package com.teamviewer.teamviewerlib.gui.dialogs;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import o.cgp;

public class DialogID
  implements Parcelable
{
  public static final Parcelable.Creator<DialogID> CREATOR = new cgp();
  public final int a;
  public final int b;
  
  public DialogID(int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public DialogID(Parcel paramParcel)
  {
    this.a = paramParcel.readInt();
    this.b = paramParcel.readInt();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    do
    {
      return true;
      if (!(paramObject instanceof DialogID)) {
        break;
      }
      paramObject = (DialogID)paramObject;
    } while ((this.a == ((DialogID)paramObject).a) && (this.b == ((DialogID)paramObject).b));
    return false;
    return false;
  }
  
  public int hashCode()
  {
    return this.a * 31 + this.b;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.a);
    paramParcel.writeInt(this.b);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/gui/dialogs/DialogID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */