package com.teamviewer.teamviewerlib.meeting;

import o.cjx;

public class StreamFeatures
{
  public static long a(cjx paramcjx)
  {
    return jniGetSupportedStreamFeatures(paramcjx.a());
  }
  
  public static boolean a(cjx paramcjx, long paramLong)
  {
    return (a(paramcjx) & paramLong) == paramLong;
  }
  
  private static native long jniGetSupportedStreamFeatures(int paramInt);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/meeting/StreamFeatures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */