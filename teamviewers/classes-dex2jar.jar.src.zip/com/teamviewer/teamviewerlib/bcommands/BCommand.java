package com.teamviewer.teamviewerlib.bcommands;

import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.swig.tvhelper.ParticipantIdentifier;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import o.bzz;
import o.cdj;
import o.cdm;
import o.cdp;
import o.cdr;
import o.cds;
import o.cdt;
import o.cdu;
import o.cdv;
import o.cdw;
import o.cdx;
import o.cho;
import o.cjv;

public class BCommand
{
  private final long a;
  private boolean b = false;
  
  public BCommand(long paramLong)
  {
    if (paramLong == 0L) {
      throw new NullPointerException("cptr must not be 0!");
    }
    this.a = paramLong;
  }
  
  public BCommand(bzz parambzz, byte paramByte)
  {
    this.a = jniNewBCommand(paramByte);
    a(parambzz);
  }
  
  private void a(bzz parambzz)
  {
    a(cdr.c, parambzz.a());
  }
  
  private static native void jniAddParam(long paramLong, byte paramByte, byte[] paramArrayOfByte);
  
  private static native void jniDeleteBCommand(long paramLong);
  
  private static native byte jniGetCommandType(long paramLong);
  
  private static native byte[] jniGetParam(long paramLong, byte paramByte);
  
  private static native long jniGetSenderParticipantId(long paramLong);
  
  private static native int jniGetStreamId(long paramLong);
  
  private static native long jniNewBCommand(byte paramByte);
  
  private static native void jniSetKnownStream(long paramLong, int paramInt);
  
  private static native void jniSetStreamFlags(long paramLong, char paramChar);
  
  private static native void jniSetStreamId(long paramLong, int paramInt);
  
  private static native void jniSetTargetParticipantId(long paramLong1, long paramLong2);
  
  public final long a()
  {
    return this.a;
  }
  
  public final <T> List<T> a(cdj paramcdj, cdm<T> paramcdm)
  {
    Object localObject1 = jniGetParam(this.a, paramcdj.a());
    if (localObject1 == null) {
      return null;
    }
    localArrayList = new ArrayList();
    localObject1 = ByteBuffer.wrap((byte[])localObject1);
    ((ByteBuffer)localObject1).order(ByteOrder.LITTLE_ENDIAN);
    try
    {
      while (((ByteBuffer)localObject1).hasRemaining())
      {
        Object localObject2 = paramcdm.a((ByteBuffer)localObject1, ((ByteBuffer)localObject1).getInt());
        if (localObject2 != null) {
          localArrayList.add(localObject2);
        }
      }
      return localArrayList;
    }
    catch (BufferUnderflowException paramcdm)
    {
      Logging.d("NativeBCommand", "getParamVector() param=" + paramcdj + " " + paramcdm.getMessage());
      return null;
    }
  }
  
  public final <T> List<T> a(cdj paramcdj, cdm<T> paramcdm, int paramInt)
  {
    Object localObject1 = jniGetParam(this.a, paramcdj.a());
    if (localObject1 == null) {
      return null;
    }
    if (localObject1.length % paramInt != 0)
    {
      Logging.d("NativeBCommand", "getParamVectorPOD(): invalid length.");
      return null;
    }
    localArrayList = new ArrayList();
    localObject1 = ByteBuffer.wrap((byte[])localObject1);
    ((ByteBuffer)localObject1).order(ByteOrder.LITTLE_ENDIAN);
    try
    {
      while (((ByteBuffer)localObject1).hasRemaining())
      {
        Object localObject2 = paramcdm.a((ByteBuffer)localObject1, paramInt);
        if (localObject2 != null) {
          localArrayList.add(localObject2);
        }
      }
      return localArrayList;
    }
    catch (BufferUnderflowException paramcdm)
    {
      Logging.d("NativeBCommand", "getParamVectorPOD() param=" + paramcdj + " " + paramcdm.getMessage());
      return null;
    }
  }
  
  public final cdt a(cdj paramcdj)
  {
    paramcdj = jniGetParam(this.a, paramcdj.a());
    if (paramcdj.length > 0) {
      return new cdt(paramcdj.length, paramcdj);
    }
    return cdt.a;
  }
  
  public void a(char paramChar)
  {
    jniSetStreamFlags(this.a, paramChar);
  }
  
  public void a(int paramInt)
  {
    jniSetStreamId(this.a, paramInt);
  }
  
  public void a(ParticipantIdentifier paramParticipantIdentifier)
  {
    jniSetTargetParticipantId(this.a, paramParticipantIdentifier.getValue());
  }
  
  public final void a(cdj paramcdj, byte paramByte)
  {
    a(paramcdj, new byte[] { paramByte });
  }
  
  public final void a(cdj paramcdj, int paramInt)
  {
    a(paramcdj, cho.a(paramInt));
  }
  
  public final void a(cdj paramcdj, long paramLong)
  {
    ByteBuffer localByteBuffer = ByteBuffer.allocate(8);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    localByteBuffer.putLong(paramLong);
    a(paramcdj, localByteBuffer.array());
  }
  
  public final void a(cdj paramcdj, String paramString)
  {
    a(paramcdj, cho.b(paramString + '\000'));
  }
  
  public final <T> void a(cdj paramcdj, List<T> paramList, int paramInt, cdp<T> paramcdp)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return;
    }
    ByteBuffer localByteBuffer = ByteBuffer.allocate(paramList.size() * paramInt);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    paramList = paramList.iterator();
    while (paramList.hasNext()) {
      localByteBuffer.put(paramcdp.a(paramList.next()));
    }
    a(paramcdj, localByteBuffer.array());
  }
  
  public final <T> void a(cdj paramcdj, List<T> paramList, cdp<T> paramcdp)
  {
    if (paramList.isEmpty()) {
      return;
    }
    int i = 0;
    Object localObject = new ArrayList(paramList.size());
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      byte[] arrayOfByte = paramcdp.a(paramList.next());
      if (arrayOfByte != null)
      {
        ((List)localObject).add(arrayOfByte);
        i += arrayOfByte.length + 4;
      }
    }
    paramList = ByteBuffer.allocate(i);
    paramList.order(ByteOrder.LITTLE_ENDIAN);
    paramcdp = ((List)localObject).iterator();
    while (paramcdp.hasNext())
    {
      localObject = (byte[])paramcdp.next();
      paramList.putInt(localObject.length);
      paramList.put((byte[])localObject);
    }
    a(paramcdj, paramList.array());
  }
  
  public final void a(cdj paramcdj, boolean paramBoolean)
  {
    if (paramBoolean) {}
    for (int i = 1;; i = 0)
    {
      a(paramcdj, (byte)i);
      return;
    }
  }
  
  public final void a(cdj paramcdj, byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      throw new NullPointerException("Parameter data must not be null");
    }
    jniAddParam(this.a, paramcdj.a(), paramArrayOfByte);
  }
  
  public void a(cjv paramcjv)
  {
    jniSetKnownStream(this.a, paramcjv.a());
  }
  
  public final byte b()
  {
    return jniGetCommandType(this.a);
  }
  
  public final cdu b(cdj paramcdj)
  {
    paramcdj = jniGetParam(this.a, paramcdj.a());
    if (paramcdj.length == 1) {
      return cdu.a(paramcdj[0]);
    }
    return cdu.a;
  }
  
  public final cds c(cdj paramcdj)
  {
    paramcdj = jniGetParam(this.a, paramcdj.a());
    if (paramcdj.length == 1)
    {
      if (paramcdj[0] == 0) {
        return cds.b;
      }
      return cds.c;
    }
    return cds.a;
  }
  
  public final void c()
  {
    this.b = true;
  }
  
  public final cdw d(cdj paramcdj)
  {
    paramcdj = jniGetParam(this.a, paramcdj.a());
    if (paramcdj.length == 4) {
      return cdw.a(cho.a(paramcdj, 0));
    }
    return cdw.a;
  }
  
  public final boolean d()
  {
    return this.b;
  }
  
  public final bzz e()
  {
    cdu localcdu = b(cdr.c);
    if (localcdu.b > 0) {
      return bzz.a(localcdu.c);
    }
    return bzz.a;
  }
  
  public final cdv e(cdj paramcdj)
  {
    paramcdj = jniGetParam(this.a, paramcdj.a());
    if (paramcdj.length == 8)
    {
      ByteBuffer localByteBuffer = ByteBuffer.wrap(paramcdj);
      localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
      return new cdv(paramcdj.length, localByteBuffer.getLong());
    }
    return cdv.a;
  }
  
  public final boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof BCommand)) {
      return false;
    }
    BCommand localBCommand = (BCommand)paramObject;
    if (a() == localBCommand.a()) {
      return true;
    }
    return super.equals(paramObject);
  }
  
  public final cdx f(cdj paramcdj)
  {
    String str = cho.b(jniGetParam(this.a, paramcdj.a()));
    paramcdj = str;
    if (str.length() > 0)
    {
      paramcdj = str;
      if (str.charAt(str.length() - 1) == 0) {
        paramcdj = str.substring(0, str.length() - 1);
      }
    }
    return new cdx(paramcdj.length(), paramcdj);
  }
  
  public final void f()
  {
    jniDeleteBCommand(this.a);
  }
  
  public long g()
  {
    return jniGetSenderParticipantId(this.a);
  }
  
  public int h()
  {
    return jniGetStreamId(this.a);
  }
  
  public final int hashCode()
  {
    return (int)(this.a ^ this.a >>> 32);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(e());
    localStringBuilder.append(" ptr=0x").append(Long.toHexString(a()));
    localStringBuilder.append(" rct=").append(b());
    return localStringBuilder.toString();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/bcommands/BCommand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */