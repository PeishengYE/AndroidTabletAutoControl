package com.teamviewer.teamviewerlib.compress;

import android.graphics.Bitmap;

public class NativeCompress
{
  public static native void ClearTileCache();
  
  public static native void CopyRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public static native void DecodeInt(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static native void DecodeIntWithTable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static native void DecodeJPEG(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static native void DecodeTilesCombinedCommand(long paramLong, boolean paramBoolean);
  
  public static native void DecodeXor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static native void Init(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong, Bitmap paramBitmap);
  
  public static native boolean OpenGLStep(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2);
  
  public static native boolean OpenGLSurfaceChanged(int paramInt1, int paramInt2);
  
  public static native boolean OpenGLSurfaceCreated();
  
  public static native void Release();
  
  public static native boolean RemoveElementsFromTileCache(long paramLong);
  
  public static native void RleDecodeByte(long paramLong);
  
  public static native void RleDecodeByte128(long paramLong);
  
  public static native void SetEncoding256Params(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static native void SurfaceDestroyed();
  
  public static native void UpdateComplete();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/compress/NativeCompress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */