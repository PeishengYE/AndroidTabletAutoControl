package com.teamviewer.teamviewerlib.event;

import android.util.SparseArray;
import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.NativeLibTvExt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import o.byv;
import o.cfg;
import o.cfh;
import o.cfi;
import o.cfk;
import o.cfl;
import o.cfm;
import o.cfn;
import o.cfo;
import o.cfp;
import o.cfq;
import o.cfr;
import o.cfs;
import o.cft;

public class EventHub
{
  private static EventHub e = null;
  private final Map<cfl, List<cfk>> a = new EnumMap(cfl.class);
  private final Map<cfl, List<cfn>> b = new EnumMap(cfl.class);
  private final SparseArray<cfl> c = new SparseArray();
  private final SparseArray<cfm> d = new SparseArray();
  
  private EventHub()
  {
    Object localObject1 = cfl.values();
    int k = localObject1.length;
    int i = 0;
    Object localObject2;
    while (i < k)
    {
      localObject2 = localObject1[i];
      this.c.put(((cfl)localObject2).a(), localObject2);
      i += 1;
    }
    localObject1 = cfm.values();
    k = localObject1.length;
    i = j;
    while (i < k)
    {
      localObject2 = localObject1[i];
      this.d.put(((cfm)localObject2).a(), localObject2);
      i += 1;
    }
  }
  
  public static EventHub a()
  {
    if (e == null)
    {
      e = new EventHub();
      if (NativeLibTvExt.a()) {
        break label33;
      }
      Logging.d("EventHub", "getInstance(): cannot initialize native EventHub - native library not loaded");
    }
    for (;;)
    {
      return e;
      label33:
      if (!jniInit()) {
        Logging.d("EventHub", "getInstance(): cannot initialize native EventHub - init failed");
      }
    }
  }
  
  private cfl a(int paramInt)
  {
    return (cfl)this.c.get(paramInt);
  }
  
  private void a(int paramInt, cfn paramcfn)
  {
    int i1 = 0;
    Object localObject1 = paramcfn.a().iterator();
    int n = 0;
    int m = 0;
    int i = 0;
    int k = 0;
    int j = 0;
    int i2;
    int i3;
    if (((Iterator)localObject1).hasNext())
    {
      localObject2 = paramcfn.a((cfm)((Iterator)localObject1).next());
      if ((localObject2 instanceof cfg))
      {
        i2 = n;
        i3 = m;
        n = j + 1;
        m = k;
        k = i;
        j = i3;
        i = i2;
      }
      for (;;)
      {
        i2 = i;
        i3 = j;
        i = k;
        k = m;
        j = n;
        m = i3;
        n = i2;
        break;
        if ((localObject2 instanceof cfq))
        {
          i3 = i1 + 1;
          i1 = n;
          i2 = m;
          m = k;
          n = j;
          k = i;
          i = i1;
          j = i2;
          i1 = i3;
        }
        else if ((localObject2 instanceof cfs))
        {
          i2 = n;
          i3 = k + 1;
          n = j;
          k = i;
          i = i2;
          j = m;
          m = i3;
        }
        else if ((localObject2 instanceof cfp))
        {
          i2 = n;
          i3 = m;
          m = k;
          n = j;
          k = i + 1;
          i = i2;
          j = i3;
        }
        else if ((localObject2 instanceof cft))
        {
          i2 = n;
          i3 = m + 1;
          m = k;
          n = j;
          k = i;
          i = i2;
          j = i3;
        }
        else if ((localObject2 instanceof cfh))
        {
          i3 = n + 1;
          i2 = m;
          m = k;
          n = j;
          k = i;
          i = i3;
          j = i2;
        }
        else if ((localObject2 instanceof cfi))
        {
          i2 = n;
          i3 = m;
          m = k;
          n = j;
          k = i;
          i = i2;
          j = i3;
        }
        else if ((localObject2 instanceof cfr))
        {
          i2 = n;
          i3 = m;
          m = k;
          n = j;
          k = i;
          i = i2;
          j = i3;
        }
        else
        {
          Logging.d("EventHub", "triggerNativeEvent(): unknowm EventValue type: " + localObject2.getClass().getName());
          i2 = n;
          i3 = m;
          m = k;
          n = j;
          k = i;
          i = i2;
          j = i3;
        }
      }
    }
    localObject1 = new int[j];
    Object localObject2 = new boolean[j];
    int[] arrayOfInt1 = new int[i1];
    int[] arrayOfInt2 = new int[i1];
    int[] arrayOfInt3 = new int[k];
    long[] arrayOfLong = new long[k];
    int[] arrayOfInt4 = new int[i];
    float[] arrayOfFloat = new float[i];
    int[] arrayOfInt5 = new int[m];
    String[] arrayOfString = new String[m];
    int[] arrayOfInt6 = new int[n];
    Object[] arrayOfObject = new Object[n];
    Iterator localIterator = paramcfn.a().iterator();
    j = 0;
    i = 0;
    m = 0;
    k = 0;
    i1 = 0;
    n = 0;
    if (localIterator.hasNext())
    {
      cfm localcfm = (cfm)localIterator.next();
      cfo localcfo = paramcfn.a(localcfm);
      int i4;
      if ((localcfo instanceof cfg))
      {
        localObject2[i] = ((cfg)localcfo).a();
        localObject1[i] = localcfm.a();
        i2 = i1;
        i3 = n;
        i4 = m;
        i1 = i + 1;
        n = j;
        m = k;
        k = i4;
        j = i3;
        i = i2;
      }
      for (;;)
      {
        i2 = n;
        i3 = i1;
        i4 = m;
        i1 = i;
        n = j;
        m = k;
        k = i4;
        j = i2;
        i = i3;
        break;
        if ((localcfo instanceof cfq))
        {
          arrayOfInt2[j] = ((cfq)localcfo).a();
          arrayOfInt1[j] = localcfm.a();
          i2 = k;
          i4 = j + 1;
          i3 = i;
          i = i1;
          j = n;
          k = m;
          m = i2;
          n = i4;
          i1 = i3;
        }
        else if ((localcfo instanceof cfs))
        {
          arrayOfLong[k] = ((cfs)localcfo).a();
          arrayOfInt3[k] = localcfm.a();
          i4 = k + 1;
          i2 = j;
          i3 = i;
          i = i1;
          j = n;
          k = m;
          m = i4;
          n = i2;
          i1 = i3;
        }
        else if ((localcfo instanceof cfp))
        {
          arrayOfFloat[m] = ((cfp)localcfo).a();
          arrayOfInt4[m] = localcfm.a();
          i4 = m + 1;
          m = k;
          i2 = j;
          i3 = i;
          i = i1;
          j = n;
          k = i4;
          n = i2;
          i1 = i3;
        }
        else if ((localcfo instanceof cft))
        {
          arrayOfString[n] = ((cft)localcfo).a();
          arrayOfInt5[n] = localcfm.a();
          i4 = n + 1;
          n = k;
          i2 = j;
          i3 = i;
          i = i1;
          j = i4;
          k = m;
          m = n;
          n = i2;
          i1 = i3;
        }
        else if ((localcfo instanceof cfh))
        {
          arrayOfObject[i1] = ((cfh)localcfo).a();
          arrayOfInt6[i1] = localcfm.a();
          i4 = i1 + 1;
          i1 = k;
          i2 = j;
          i3 = i;
          i = i4;
          j = n;
          k = m;
          m = i1;
          n = i2;
          i1 = i3;
        }
        else if ((localcfo instanceof cfi))
        {
          i2 = k;
          i3 = j;
          i4 = i;
          i = i1;
          j = n;
          k = m;
          m = i2;
          n = i3;
          i1 = i4;
        }
        else if ((localcfo instanceof cfr))
        {
          i2 = k;
          i3 = j;
          i4 = i;
          i = i1;
          j = n;
          k = m;
          m = i2;
          n = i3;
          i1 = i4;
        }
        else
        {
          Logging.d("EventHub", "triggerNativeEvent(): unknowm EventValue type: " + localcfo.getClass().getName());
          i2 = k;
          i3 = j;
          i4 = i;
          i = i1;
          j = n;
          k = m;
          m = i2;
          n = i3;
          i1 = i4;
        }
      }
    }
    if (NativeLibTvExt.a()) {
      jniTriggerEvent(paramInt, (int[])localObject1, (boolean[])localObject2, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfLong, arrayOfInt4, arrayOfFloat, arrayOfInt5, arrayOfString, arrayOfInt6, arrayOfObject);
    }
  }
  
  private cfm b(int paramInt)
  {
    return (cfm)this.d.get(paramInt);
  }
  
  public static void b()
  {
    if (e != null) {
      if (NativeLibTvExt.a()) {
        jniShutdown();
      }
    }
    synchronized (e.a)
    {
      e.a.clear();
      e.b.clear();
      e = null;
      Logging.b("EventHub", "destroyed");
      return;
    }
  }
  
  @byv
  private static void handleEventCallback(int paramInt, int[] paramArrayOfInt1, boolean[] paramArrayOfBoolean, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, long[] paramArrayOfLong, int[] paramArrayOfInt5, float[] paramArrayOfFloat, int[] paramArrayOfInt6, String[] paramArrayOfString, int[] paramArrayOfInt7, Object[] paramArrayOfObject)
  {
    EventHub localEventHub = a();
    cfl localcfl = localEventHub.a(paramInt);
    cfn localcfn = new cfn();
    paramInt = 0;
    while (paramInt < paramArrayOfInt1.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt1[paramInt]), paramArrayOfBoolean[paramInt]);
      paramInt += 1;
    }
    paramInt = 0;
    while (paramInt < paramArrayOfInt2.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt2[paramInt]), paramArrayOfInt3[paramInt]);
      paramInt += 1;
    }
    paramInt = 0;
    while (paramInt < paramArrayOfInt4.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt4[paramInt]), paramArrayOfLong[paramInt]);
      paramInt += 1;
    }
    paramInt = 0;
    while (paramInt < paramArrayOfInt5.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt5[paramInt]), paramArrayOfFloat[paramInt]);
      paramInt += 1;
    }
    paramInt = 0;
    while (paramInt < paramArrayOfInt6.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt6[paramInt]), paramArrayOfString[paramInt]);
      paramInt += 1;
    }
    paramInt = 0;
    while (paramInt < paramArrayOfInt7.length)
    {
      localcfn.a(localEventHub.b(paramArrayOfInt7[paramInt]), (byte[])paramArrayOfObject[paramInt]);
      paramInt += 1;
    }
    localEventHub.a(localcfl, localcfn);
  }
  
  @byv
  private static boolean isEventRegisteredCallback(int paramInt)
  {
    EventHub localEventHub = a();
    cfl localcfl = localEventHub.a(paramInt);
    return (localcfl != null) && (localEventHub.b(localcfl));
  }
  
  private static native boolean jniInit();
  
  private static native boolean jniIsEventRegistered(int paramInt);
  
  private static native void jniShutdown();
  
  private static native void jniTriggerEvent(int paramInt, int[] paramArrayOfInt1, boolean[] paramArrayOfBoolean, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, long[] paramArrayOfLong, int[] paramArrayOfInt5, float[] paramArrayOfFloat, int[] paramArrayOfInt6, String[] paramArrayOfString, int[] paramArrayOfInt7, Object[] paramArrayOfObject);
  
  public final void a(cfl paramcfl)
  {
    a(paramcfl, cfn.a);
  }
  
  public final void a(cfl paramcfl, cfn paramcfn)
  {
    for (;;)
    {
      synchronized (this.a)
      {
        localObject = (List)this.a.get(paramcfl);
        if (localObject == null) {
          break label132;
        }
        localObject = (ArrayList)((ArrayList)localObject).clone();
        if (localObject != null)
        {
          localObject = ((ArrayList)localObject).iterator();
          if (((Iterator)localObject).hasNext()) {
            ((cfk)((Iterator)localObject).next()).a(paramcfl, paramcfn);
          }
        }
      }
      int i = paramcfl.a();
      if ((NativeLibTvExt.a()) && (i >= 10000) && (i <= 19999) && (jniIsEventRegistered(i))) {
        a(i, paramcfn);
      }
      return;
      label132:
      Object localObject = null;
    }
  }
  
  public final boolean a(cfk paramcfk)
  {
    Map localMap = this.a;
    boolean bool = false;
    for (;;)
    {
      try
      {
        Iterator localIterator1 = this.a.values().iterator();
        if (localIterator1.hasNext())
        {
          List localList = (List)localIterator1.next();
          if (localList != null)
          {
            Iterator localIterator2 = localList.iterator();
            if (localIterator2.hasNext()) {
              if (paramcfk == (cfk)localIterator2.next())
              {
                localList.remove(paramcfk);
                bool = true;
              }
            }
          }
        }
        else
        {
          return bool;
        }
      }
      finally {}
    }
  }
  
  public final boolean a(cfk paramcfk, cfl paramcfl)
  {
    boolean bool = true;
    for (;;)
    {
      synchronized (this.a)
      {
        localObject1 = (List)this.a.get(paramcfl);
        if (localObject1 != null)
        {
          Object localObject2 = ((List)localObject1).iterator();
          if (!((Iterator)localObject2).hasNext()) {
            break label221;
          }
          if ((cfk)((Iterator)localObject2).next() != paramcfk) {
            continue;
          }
          i = 1;
          if (i != 0) {
            break label215;
          }
          ((List)localObject1).add(paramcfk);
          localObject2 = (List)this.b.get(paramcfl);
          if (localObject2 == null) {
            break label209;
          }
          localObject1 = (ArrayList)((ArrayList)localObject2).clone();
          ((List)localObject2).clear();
          if (localObject1 != null)
          {
            localObject1 = ((ArrayList)localObject1).iterator();
            if (((Iterator)localObject1).hasNext())
            {
              paramcfk.a(paramcfl, (cfn)((Iterator)localObject1).next());
              continue;
            }
          }
        }
        else
        {
          localObject1 = new ArrayList(4);
          ((List)localObject1).add(paramcfk);
          this.a.put(paramcfl, localObject1);
        }
      }
      return bool;
      label209:
      Object localObject1 = null;
      continue;
      label215:
      bool = false;
      continue;
      label221:
      int i = 0;
    }
  }
  
  public final void b(cfl paramcfl, cfn paramcfn)
  {
    Object localObject1 = null;
    synchronized (this.a)
    {
      Object localObject2 = (List)this.a.get(paramcfl);
      if (localObject2 != null) {
        localObject1 = (ArrayList)((ArrayList)localObject2).clone();
      }
      if ((localObject2 == null) || (((List)localObject2).size() <= 0))
      {
        localObject2 = (List)this.b.get(paramcfl);
        if (localObject2 != null) {
          ((List)localObject2).add(paramcfn);
        }
      }
      else
      {
        if (localObject1 == null) {
          return;
        }
        localObject1 = ((ArrayList)localObject1).iterator();
        while (((Iterator)localObject1).hasNext()) {
          ((cfk)((Iterator)localObject1).next()).a(paramcfl, paramcfn);
        }
      }
      localObject2 = new ArrayList();
      ((List)localObject2).add(paramcfn);
      this.b.put(paramcfl, localObject2);
    }
  }
  
  public final boolean b(cfl paramcfl)
  {
    for (;;)
    {
      synchronized (this.a)
      {
        paramcfl = (List)this.a.get(paramcfl);
        if ((paramcfl != null) && (paramcfl.size() > 0))
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/event/EventHub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */