package com.teamviewer.teamviewerlib;

import java.util.Locale;

public class NativeResources
{
  public static void a(Locale paramLocale)
  {
    if (NativeLibTvExt.a()) {
      jniUpdateNativeResources(paramLocale.getLanguage(), paramLocale.getCountry());
    }
  }
  
  private static native void jniUpdateNativeResources(String paramString1, String paramString2);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/NativeResources.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */