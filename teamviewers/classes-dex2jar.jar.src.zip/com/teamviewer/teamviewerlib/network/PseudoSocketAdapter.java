package com.teamviewer.teamviewerlib.network;

import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.NativeLibTvExt;
import com.teamviewer.teamviewerlib.bcommands.BCommand;

public class PseudoSocketAdapter
{
  private final long a;
  private volatile boolean b;
  
  public PseudoSocketAdapter(int paramInt)
  {
    if (NativeLibTvExt.a())
    {
      this.b = false;
      this.a = jniCreate(paramInt);
      return;
    }
    this.b = true;
    this.a = 0L;
  }
  
  private static native boolean jniClose(long paramLong);
  
  private static native long jniCreate(int paramInt);
  
  private static native boolean jniIsClosing(long paramLong);
  
  private static native long jniRead(long paramLong);
  
  private static native boolean jniSend(long paramLong1, long paramLong2);
  
  public final BCommand a()
  {
    if (!this.b)
    {
      long l = jniRead(this.a);
      if (l != 0L) {
        return new BCommand(l);
      }
    }
    Logging.c("PseudoSocketAdapter", "read: Socket already closed.");
    return null;
  }
  
  /* Error */
  public final boolean a(BCommand paramBCommand)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 20	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:b	Z
    //   6: ifne +19 -> 25
    //   9: aload_0
    //   10: getfield 26	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:a	J
    //   13: aload_1
    //   14: invokevirtual 56	com/teamviewer/teamviewerlib/bcommands/BCommand:a	()J
    //   17: invokestatic 58	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:jniSend	(JJ)Z
    //   20: istore_2
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_2
    //   24: ireturn
    //   25: ldc 44
    //   27: ldc 60
    //   29: invokestatic 52	com/teamviewer/corelib/logging/Logging:c	(Ljava/lang/String;Ljava/lang/String;)V
    //   32: iconst_0
    //   33: istore_2
    //   34: goto -13 -> 21
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	42	0	this	PseudoSocketAdapter
    //   0	42	1	paramBCommand	BCommand
    //   20	14	2	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   2	21	37	finally
    //   25	32	37	finally
  }
  
  /* Error */
  public final boolean b()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 20	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:b	Z
    //   6: ifne +15 -> 21
    //   9: aload_0
    //   10: getfield 26	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:a	J
    //   13: invokestatic 62	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:jniIsClosing	(J)Z
    //   16: istore_1
    //   17: iload_1
    //   18: ifeq +9 -> 27
    //   21: iconst_1
    //   22: istore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: iload_1
    //   26: ireturn
    //   27: iconst_0
    //   28: istore_1
    //   29: goto -6 -> 23
    //   32: astore_2
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_2
    //   36: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	37	0	this	PseudoSocketAdapter
    //   16	13	1	bool	boolean
    //   32	4	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	17	32	finally
  }
  
  /* Error */
  public final boolean c()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 20	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:b	Z
    //   6: ifne +20 -> 26
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield 20	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:b	Z
    //   14: aload_0
    //   15: getfield 26	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:a	J
    //   18: invokestatic 64	com/teamviewer/teamviewerlib/network/PseudoSocketAdapter:jniClose	(J)Z
    //   21: istore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: iload_1
    //   25: ireturn
    //   26: ldc 44
    //   28: ldc 66
    //   30: invokestatic 52	com/teamviewer/corelib/logging/Logging:c	(Ljava/lang/String;Ljava/lang/String;)V
    //   33: iconst_0
    //   34: istore_1
    //   35: goto -13 -> 22
    //   38: astore_2
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_2
    //   42: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	43	0	this	PseudoSocketAdapter
    //   21	14	1	bool	boolean
    //   38	4	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	22	38	finally
    //   26	33	38	finally
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/network/PseudoSocketAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */