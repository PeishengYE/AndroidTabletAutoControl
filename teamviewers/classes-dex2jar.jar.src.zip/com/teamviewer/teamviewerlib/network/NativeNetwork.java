package com.teamviewer.teamviewerlib.network;

import com.teamviewer.teamviewerlib.NativeLibTvExt;
import com.teamviewer.teamviewerlib.bcommands.BCommand;
import com.teamviewer.teamviewerlib.settings.Settings;
import o.ckc;

public final class NativeNetwork
{
  static
  {
    if (NativeLibTvExt.a())
    {
      Settings localSettings = Settings.a();
      InterProcessGUIConnector.a();
      jniInit(localSettings.j());
    }
  }
  
  public static ConnectionParam a(String paramString1, int paramInt, String paramString2)
  {
    if (!NativeLibTvExt.a()) {
      return null;
    }
    return jniConnectSession(ckc.b.a(), paramString1, paramInt, paramString2);
  }
  
  public static ConnectionParam a(String paramString1, long paramLong1, long paramLong2, int paramInt, String paramString2)
  {
    if (!NativeLibTvExt.a()) {
      return null;
    }
    return jniConnectMeetingSession(paramString1, paramLong1, paramLong2, paramInt, paramString2);
  }
  
  public static void a() {}
  
  public static void a(int paramInt)
  {
    if (NativeLibTvExt.a()) {
      jniEndSession(paramInt);
    }
  }
  
  public static void a(BCommand paramBCommand)
  {
    if (NativeLibTvExt.a()) {
      jniSendToIPCNetwork(paramBCommand.a());
    }
    paramBCommand.f();
  }
  
  public static void b()
  {
    if (NativeLibTvExt.a()) {
      jniStartNetwork();
    }
  }
  
  public static void c()
  {
    if (NativeLibTvExt.a()) {
      jniStartKeepAlive();
    }
  }
  
  public static void d()
  {
    if (NativeLibTvExt.a()) {
      jniStopKeepAlive();
    }
  }
  
  public static void e()
  {
    if (NativeLibTvExt.a()) {
      jniStopNetwork();
    }
  }
  
  private static native ConnectionParam jniConnectMeetingSession(String paramString1, long paramLong1, long paramLong2, int paramInt, String paramString2);
  
  private static native ConnectionParam jniConnectSession(int paramInt1, String paramString1, int paramInt2, String paramString2);
  
  private static native void jniEndSession(int paramInt);
  
  private static native void jniInit(String paramString);
  
  private static native void jniSendToIPCNetwork(long paramLong);
  
  private static native void jniStartKeepAlive();
  
  private static native void jniStartNetwork();
  
  private static native void jniStopKeepAlive();
  
  private static native void jniStopNetwork();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/network/NativeNetwork.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */