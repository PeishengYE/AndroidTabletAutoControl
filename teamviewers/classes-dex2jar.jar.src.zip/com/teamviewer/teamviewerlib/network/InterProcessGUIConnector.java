package com.teamviewer.teamviewerlib.network;

import com.teamviewer.corelib.logging.Logging;
import com.teamviewer.teamviewerlib.NativeLibTvExt;
import com.teamviewer.teamviewerlib.bcommands.BCommand;
import o.byv;
import o.bzs;
import o.bzv;
import o.bzw;
import o.bzz;
import o.cbi;
import o.cbj;
import o.cbp;
import o.cdr;
import o.cdt;
import o.cdw;
import o.ciq;
import o.ciz;
import o.cji;
import o.ckl;

public class InterProcessGUIConnector
{
  private static ciq a = null;
  
  public static void a()
  {
    if (NativeLibTvExt.a()) {
      jniInit();
    }
  }
  
  public static void a(int paramInt, cji paramcji, long paramLong)
  {
    if (NativeLibTvExt.a()) {
      jniSetSessionInfoLong(paramInt, paramcji.a(), paramLong);
    }
  }
  
  public static void a(long paramLong)
  {
    if (NativeLibTvExt.a()) {
      jniSetParticipantManager(paramLong);
    }
  }
  
  private static void a(cbi paramcbi)
  {
    Object localObject = ciz.a();
    if ((((ciz)localObject).i()) || (((ciz)localObject).k()))
    {
      ckl.a(paramcbi.d(cdr.e).c);
      Logging.b("InterProcessGUIConnector", "Cannot create new incoming session. A session is still running.");
      return;
    }
    int i = paramcbi.d(cbp.a).c;
    if (paramcbi.d(cbp.s).c != 0)
    {
      i = paramcbi.d(cbp.r).c;
      localObject = new bzw("" + i, null);
      ((bzw)localObject).a((byte[])paramcbi.a(cbp.u).c);
      ((bzw)localObject).b((byte[])paramcbi.a(cbp.t).c);
      ciz.a().a((bzs)localObject, paramcbi.d(cdr.e).c);
      return;
    }
    localObject = new bzv(i);
    ciz.a().a((bzs)localObject, paramcbi.d(cdr.e).c);
  }
  
  public static void a(ciq paramciq)
  {
    a = paramciq;
  }
  
  public static void a(cji paramcji, long paramLong)
  {
    if (NativeLibTvExt.a()) {
      jniSetGeneralInfoUInt64(paramcji.a(), paramLong);
    }
  }
  
  public static void a(cji paramcji, String paramString)
  {
    if (NativeLibTvExt.a()) {
      jniSetGeneralInfoString(paramcji.a(), paramString);
    }
  }
  
  @byv
  public static void handleSessionCommand(long paramLong)
  {
    Object localObject1 = new BCommand(paramLong);
    if (((BCommand)localObject1).e() == bzz.c)
    {
      localObject1 = new cbi((BCommand)localObject1);
      for (;;)
      {
        try
        {
          ciq localciq = a;
          if (localciq != null)
          {
            localciq.a((cbi)localObject1);
            return;
          }
          if (((cbi)localObject1).i() == cbj.b) {
            a((cbi)localObject1);
          } else {
            Logging.c("InterProcessGUIConnector", "Received SessionCommand (" + ((cbi)localObject1).toString() + ") without registered callback.");
          }
        }
        finally
        {
          if (!((cbi)localObject1).d()) {
            ((cbi)localObject1).f();
          }
        }
      }
    }
    Logging.d("InterProcessGUIConnector", "Invalid command type for handling SessionCommand.");
    ((BCommand)localObject1).f();
  }
  
  private static native void jniInit();
  
  public static native void jniSetGeneralInfoString(int paramInt, String paramString);
  
  public static native void jniSetGeneralInfoUInt64(int paramInt, long paramLong);
  
  private static native void jniSetParticipantManager(long paramLong);
  
  public static native void jniSetSessionInfoLong(int paramInt1, int paramInt2, long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/network/InterProcessGUIConnector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */