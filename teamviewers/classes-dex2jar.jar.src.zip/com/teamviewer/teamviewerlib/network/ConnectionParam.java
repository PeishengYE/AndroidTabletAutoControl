package com.teamviewer.teamviewerlib.network;

import com.teamviewer.teamviewerlib.swig.tvmodellocator.ClientConnectorAndroid.ConnectionParam;
import java.util.BitSet;
import o.byv;
import o.chi;

public class ConnectionParam
{
  public final int a;
  public final String b;
  public final String c;
  public final int d;
  public final int e;
  public final int f;
  public final int g;
  public final BitSet h;
  public final BitSet i;
  public final boolean j;
  public final int k;
  public final int l;
  
  private ConnectionParam(int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, BitSet paramBitSet1, BitSet paramBitSet2, boolean paramBoolean, int paramInt6, int paramInt7)
  {
    this.a = paramInt1;
    this.b = paramString1;
    this.c = paramString2;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = paramInt4;
    this.g = paramInt5;
    this.h = paramBitSet1;
    this.i = paramBitSet2;
    this.j = paramBoolean;
    this.k = paramInt6;
    this.l = paramInt7;
  }
  
  @byv
  public ConnectionParam(int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean, int paramInt6, int paramInt7)
  {
    this(paramInt1, paramString1, paramString2, paramInt2, paramInt3, paramInt4, paramInt5, chi.a(paramArrayOfByte1), chi.a(paramArrayOfByte2), paramBoolean, paramInt6, paramInt7);
  }
  
  public ConnectionParam(ClientConnectorAndroid.ConnectionParam paramConnectionParam)
  {
    this(paramConnectionParam.getDestClientId(), paramConnectionParam.getRouterIp(), paramConnectionParam.getErrorMessage(), paramConnectionParam.getTimeoutSecs(), paramConnectionParam.getTransferRate(), paramConnectionParam.getSessionId(), paramConnectionParam.getActionId(), paramConnectionParam.GetMyLicenseFeatureVector(), paramConnectionParam.GetPartnerLicenseFeatureVector(), paramConnectionParam.getSendStatistics(), paramConnectionParam.getUsedLicense(), paramConnectionParam.getUsedLicenseFull());
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/network/ConnectionParam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */