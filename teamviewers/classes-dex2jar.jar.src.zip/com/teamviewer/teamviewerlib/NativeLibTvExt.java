package com.teamviewer.teamviewerlib;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.provider.Settings.Secure;
import com.teamviewer.corelib.logging.Logging;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import o.bao;
import o.byk;
import o.byt;
import o.cfu;
import o.chk;
import o.chs;
import o.ciy;

public class NativeLibTvExt
{
  private static final boolean a;
  private static boolean b;
  
  static
  {
    boolean bool2 = false;
    boolean bool1 = false;
    b = false;
    Logging.b("NativeLibExt", "Loading tvext");
    try
    {
      bao.a(ciy.a(), "tvext");
      bool2 = true;
      bool1 = true;
      b();
      return;
    }
    catch (Throwable localThrowable)
    {
      bool2 = bool1;
      Logging.d("NativeLibExt", "unable to load tvext! " + localThrowable.getMessage());
      return;
    }
    finally
    {
      a = bool2;
    }
  }
  
  public static byk a(Context paramContext)
  {
    String str = chs.a();
    Object localObject1 = "0000000";
    try
    {
      localObject2 = chs.b();
      localObject1 = localObject2;
    }
    catch (cfu localcfu)
    {
      Object localObject2;
      while (!str.equals("000000000000")) {}
      Logging.d("NativeLibExt", "init: " + localcfu.getMessage());
    }
    localObject2 = Locale.getDefault();
    return new byk(paramContext.getFilesDir().getAbsolutePath(), str, (String)localObject1, false, ((Locale)localObject2).getLanguage(), ((Locale)localObject2).getCountry(), Settings.Secure.getString(paramContext.getContentResolver(), "android_id"), chk.d(), null);
    return null;
  }
  
  public static void a(byk parambyk)
  {
    for (;;)
    {
      try
      {
        if (a)
        {
          bool = jniInit(parambyk.a, parambyk.b, parambyk.c, parambyk.d, parambyk.e, parambyk.f, parambyk.g, parambyk.h);
          b = bool;
          if (!bool)
          {
            Logging.d("NativeLibExt", "Initializing tvext failed.");
            return;
          }
          Logging.b("NativeLibExt", "Initializing tvext succeeded.");
          return;
        }
      }
      finally
      {
        b = false;
        Logging.d("NativeLibExt", "Initializing tvext failed.");
      }
      boolean bool = false;
    }
  }
  
  public static boolean a()
  {
    return (a) && ((byt.b) || (b));
  }
  
  private static void b()
  {
    Object localObject = new File(ciy.a().getApplicationInfo().sourceDir);
    if (!((File)localObject).exists())
    {
      Logging.d("NativeLibExt", "APK not available");
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("<br /><br /><span style=\"color:rgb(0,0,240)\">");
    localStringBuilder.append("Contained libraries: ").append("<br />");
    try
    {
      localObject = new ZipFile((File)localObject, 1);
      Enumeration localEnumeration = ((ZipFile)localObject).entries();
      while (localEnumeration.hasMoreElements())
      {
        ZipEntry localZipEntry = (ZipEntry)localEnumeration.nextElement();
        if (localZipEntry.getName().endsWith(".so")) {
          localStringBuilder.append(localZipEntry.getName()).append('\t').append(localZipEntry.getSize()).append('\t').append(localZipEntry.getCrc()).append("<br />");
        }
      }
      localIOException.append("<br />");
    }
    catch (IOException localIOException)
    {
      Logging.d("NativeLibExt", localIOException.getMessage());
      return;
    }
    Logging.b("NativeLibExt", localIOException.toString());
    ((ZipFile)localObject).close();
  }
  
  private static native boolean jniInit(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5, String paramString6, String paramString7);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/teamviewerlib/NativeLibTvExt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */