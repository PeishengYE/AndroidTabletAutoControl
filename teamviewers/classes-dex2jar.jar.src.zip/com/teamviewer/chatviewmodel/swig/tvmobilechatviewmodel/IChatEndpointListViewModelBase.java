package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointListViewModelBase
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IChatEndpointListViewModelBase(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase)
  {
    if (paramIChatEndpointListViewModelBase == null) {
      return 0L;
    }
    return paramIChatEndpointListViewModelBase.swigCPtr;
  }
  
  public boolean CanSelectMoreEndpoints()
  {
    return IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_CanSelectMoreEndpoints(this.swigCPtr, this);
  }
  
  public void DeselectChatEndpointAtPosition(int paramInt)
  {
    IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_DeselectChatEndpointAtPosition(this.swigCPtr, this, paramInt);
  }
  
  public IChatEndpointViewModel GetChatEndpointViewModelAtPosition(int paramInt)
  {
    long l = IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_GetChatEndpointViewModelAtPosition(this.swigCPtr, this, paramInt);
    if (l == 0L) {
      return null;
    }
    return new IChatEndpointViewModel(l, true);
  }
  
  public int GetNumberOfChatEndpoints()
  {
    return IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_GetNumberOfChatEndpoints(this.swigCPtr, this);
  }
  
  public boolean IsLoggedIn()
  {
    return IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_IsLoggedIn(this.swigCPtr, this);
  }
  
  public void SelectChatEndpointAtPosition(int paramInt)
  {
    IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_SelectChatEndpointAtPosition(this.swigCPtr, this, paramInt);
  }
  
  public void SetFilter(String paramString)
  {
    IChatEndpointListViewModelBaseSWIGJNI.IChatEndpointListViewModelBase_SetFilter(this.swigCPtr, this, paramString);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IChatEndpointListViewModelBaseSWIGJNI.delete_IChatEndpointListViewModelBase(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointListViewModelBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */