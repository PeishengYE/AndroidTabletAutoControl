package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatConversationIDSerializer
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatConversationIDSerializer(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static ChatConversationID Deserialize(String paramString)
  {
    return new ChatConversationID(ChatConversationIDSerializerSWIGJNI.ChatConversationIDSerializer_Deserialize(paramString), true);
  }
  
  public static String Serialize(ChatConversationID paramChatConversationID)
  {
    return ChatConversationIDSerializerSWIGJNI.ChatConversationIDSerializer_Serialize(ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public static long getCPtr(ChatConversationIDSerializer paramChatConversationIDSerializer)
  {
    if (paramChatConversationIDSerializer == null) {
      return 0L;
    }
    return paramChatConversationIDSerializer.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ChatConversationIDSerializerSWIGJNI.delete_ChatConversationIDSerializer(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatConversationIDSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */