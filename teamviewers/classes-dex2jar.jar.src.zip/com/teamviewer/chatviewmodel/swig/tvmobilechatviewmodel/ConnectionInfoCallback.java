package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import com.teamviewer.corelib.logging.Logging;

public abstract class ConnectionInfoCallback
  extends IConnectionInfoCallback
{
  private transient long swigCPtr;
  
  public ConnectionInfoCallback()
  {
    this(ConnectionInfoCallbackSWIGJNI.new_ConnectionInfoCallback(), true);
    ConnectionInfoCallbackSWIGJNI.ConnectionInfoCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public ConnectionInfoCallback(long paramLong, boolean paramBoolean)
  {
    super(ConnectionInfoCallbackSWIGJNI.ConnectionInfoCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ConnectionInfoCallback paramConnectionInfoCallback)
  {
    if (paramConnectionInfoCallback == null) {
      return 0L;
    }
    return paramConnectionInfoCallback.swigCPtr;
  }
  
  public abstract void OnConnectionToAccount(long paramLong);
  
  public abstract void OnConnectionToMachine(long paramLong);
  
  public abstract void OnConnectionToServiceCase(long paramLong);
  
  public abstract void OnError();
  
  public void PerformConnectionToAccount(long paramLong)
  {
    try
    {
      OnConnectionToAccount(paramLong);
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("ConnectionInfoCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void PerformConnectionToMachine(long paramLong)
  {
    try
    {
      OnConnectionToMachine(paramLong);
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("ConnectionInfoCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void PerformConnectionToServiceCase(long paramLong)
  {
    try
    {
      OnConnectionToServiceCase(paramLong);
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("ConnectionInfoCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void PerformError()
  {
    try
    {
      OnError();
      return;
    }
    catch (Throwable localThrowable)
    {
      Logging.a("ConnectionInfoCallback", localThrowable);
      throw localThrowable;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ConnectionInfoCallbackSWIGJNI.delete_ConnectionInfoCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    ConnectionInfoCallbackSWIGJNI.ConnectionInfoCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    ConnectionInfoCallbackSWIGJNI.ConnectionInfoCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ConnectionInfoCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */