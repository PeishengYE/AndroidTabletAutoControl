package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IOwnTextMessageViewModelSWIGJNI
{
  public static final native void IOwnTextMessageViewModel_DeleteMessage(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native boolean IOwnTextMessageViewModel_DeliveryFailed(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native int IOwnTextMessageViewModel_GetDeleteOptions(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native String IOwnTextMessageViewModel_GetMessage(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native int IOwnTextMessageViewModel_GetResendOptions(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native long IOwnTextMessageViewModel_GetTimestamp(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native void IOwnTextMessageViewModel_SendMessageAgain(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native boolean IOwnTextMessageViewModel_WasSent(long paramLong, IOwnTextMessageViewModel paramIOwnTextMessageViewModel);
  
  public static final native void delete_IOwnTextMessageViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IOwnTextMessageViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */