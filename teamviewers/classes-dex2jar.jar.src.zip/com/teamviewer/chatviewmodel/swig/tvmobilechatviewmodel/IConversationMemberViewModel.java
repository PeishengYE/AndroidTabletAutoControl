package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationMemberViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IConversationMemberViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IConversationMemberViewModel paramIConversationMemberViewModel)
  {
    if (paramIConversationMemberViewModel == null) {
      return 0L;
    }
    return paramIConversationMemberViewModel.swigCPtr;
  }
  
  public String GetAccountPictureUrl()
  {
    return IConversationMemberViewModelSWIGJNI.IConversationMemberViewModel_GetAccountPictureUrl(this.swigCPtr, this);
  }
  
  public EndpointUIState GetEndpointState()
  {
    return EndpointUIState.swigToEnum(IConversationMemberViewModelSWIGJNI.IConversationMemberViewModel_GetEndpointState(this.swigCPtr, this));
  }
  
  public ChatEndpointTypeUI GetEndpointType()
  {
    return ChatEndpointTypeUI.swigToEnum(IConversationMemberViewModelSWIGJNI.IConversationMemberViewModel_GetEndpointType(this.swigCPtr, this));
  }
  
  public String GetName()
  {
    return IConversationMemberViewModelSWIGJNI.IConversationMemberViewModel_GetName(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationMemberViewModelSWIGJNI.delete_IConversationMemberViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationMemberViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */