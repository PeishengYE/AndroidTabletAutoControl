package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IOwnTextMessageViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IOwnTextMessageViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IOwnTextMessageViewModel paramIOwnTextMessageViewModel)
  {
    if (paramIOwnTextMessageViewModel == null) {
      return 0L;
    }
    return paramIOwnTextMessageViewModel.swigCPtr;
  }
  
  public void DeleteMessage()
  {
    IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_DeleteMessage(this.swigCPtr, this);
  }
  
  public boolean DeliveryFailed()
  {
    return IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_DeliveryFailed(this.swigCPtr, this);
  }
  
  public DeleteOptions GetDeleteOptions()
  {
    return DeleteOptions.swigToEnum(IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_GetDeleteOptions(this.swigCPtr, this));
  }
  
  public String GetMessage()
  {
    return IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_GetMessage(this.swigCPtr, this);
  }
  
  public ResendOptions GetResendOptions()
  {
    return ResendOptions.swigToEnum(IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_GetResendOptions(this.swigCPtr, this));
  }
  
  public long GetTimestamp()
  {
    return IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_GetTimestamp(this.swigCPtr, this);
  }
  
  public void SendMessageAgain()
  {
    IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_SendMessageAgain(this.swigCPtr, this);
  }
  
  public boolean WasSent()
  {
    return IOwnTextMessageViewModelSWIGJNI.IOwnTextMessageViewModel_WasSent(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IOwnTextMessageViewModelSWIGJNI.delete_IOwnTextMessageViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IOwnTextMessageViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */