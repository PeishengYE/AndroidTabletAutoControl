package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ErrorMessageSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void ErrorMessageSignalCallback_PerformErrorMessage(long paramLong, ErrorMessageSignalCallback paramErrorMessageSignalCallback, int paramInt);
  
  public static final native long ErrorMessageSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void ErrorMessageSignalCallback_change_ownership(ErrorMessageSignalCallback paramErrorMessageSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void ErrorMessageSignalCallback_director_connect(ErrorMessageSignalCallback paramErrorMessageSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_ErrorMessageSignalCallback_PerformErrorMessage(ErrorMessageSignalCallback paramErrorMessageSignalCallback, int paramInt)
  {
    paramErrorMessageSignalCallback.PerformErrorMessage(ErrorMessage.swigToEnum(paramInt));
  }
  
  public static final native void delete_ErrorMessageSignalCallback(long paramLong);
  
  public static final native long new_ErrorMessageSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ErrorMessageSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */