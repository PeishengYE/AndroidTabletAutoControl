package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationViewModelSWIGJNI
{
  public static final native String IConversationViewModel_GetAccountPictureUrl(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native long IConversationViewModel_GetConversationID(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native String IConversationViewModel_GetConversationName(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native int IConversationViewModel_GetConversationType(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native int IConversationViewModel_GetEndpointState(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native long IConversationViewModel_GetLastActivityTimestamp(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native String IConversationViewModel_GetLastMessage(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native boolean IConversationViewModel_HasUnreadMessages(long paramLong, IConversationViewModel paramIConversationViewModel);
  
  public static final native void delete_IConversationViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */