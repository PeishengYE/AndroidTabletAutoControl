package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import java.math.BigInteger;

public class IStartChatViewModelAndroidSWIGJNI
{
  public static final native long IStartChatViewModelAndroid_RequestPrivateRoomWithEndPoint(long paramLong, IStartChatViewModelAndroid paramIStartChatViewModelAndroid, BigInteger paramBigInteger);
  
  public static final native void delete_IStartChatViewModelAndroid(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IStartChatViewModelAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */