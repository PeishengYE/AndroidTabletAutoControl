package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatViewModelLocator
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IChatViewModelLocator(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IChatViewModelLocator paramIChatViewModelLocator)
  {
    if (paramIChatViewModelLocator == null) {
      return 0L;
    }
    return paramIChatViewModelLocator.swigCPtr;
  }
  
  public IAddChatEndpointListViewModel GetAddChatEndpointListViewModel(ChatConversationID paramChatConversationID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetAddChatEndpointListViewModel(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IAddChatEndpointListViewModel(l, true);
  }
  
  public IChatEndpointListViewModel GetChatEndpointListViewModel(ChatConversationID paramChatConversationID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetChatEndpointListViewModel(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IChatEndpointListViewModel(l, true);
  }
  
  public IConversationHistoryListViewModel GetConversationHistoryListViewModelById(ChatConversationID paramChatConversationID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetConversationHistoryListViewModelById(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IConversationHistoryListViewModel(l, true);
  }
  
  public IConversationListViewModel GetConversationListViewModel()
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetConversationListViewModel(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IConversationListViewModel(l, true);
  }
  
  public IConversationMemberListViewModel GetConversationMemberListViewModel(ChatConversationID paramChatConversationID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetConversationMemberListViewModel(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IConversationMemberListViewModel(l, true);
  }
  
  public IConversationViewModel GetConversationViewModelById(ChatConversationID paramChatConversationID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetConversationViewModelById(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IConversationViewModel(l, true);
  }
  
  public IErrorMessageHandler GetErrorMessageHandler()
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetErrorMessageHandler(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IErrorMessageHandler(l, true);
  }
  
  public IEventMessageViewModel GetEventMessageById(ChatConversationID paramChatConversationID, ChatMessageID paramChatMessageID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetEventMessageById(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID, ChatMessageID.getCPtr(paramChatMessageID), paramChatMessageID);
    if (l == 0L) {
      return null;
    }
    return new IEventMessageViewModel(l, true);
  }
  
  public IOwnTextMessageViewModel GetOwnTextMessageById(ChatConversationID paramChatConversationID, ChatMessageID paramChatMessageID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetOwnTextMessageById(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID, ChatMessageID.getCPtr(paramChatMessageID), paramChatMessageID);
    if (l == 0L) {
      return null;
    }
    return new IOwnTextMessageViewModel(l, true);
  }
  
  public IRemoteTextMessageViewModel GetRemoteTextMessageById(ChatConversationID paramChatConversationID, ChatMessageID paramChatMessageID)
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetRemoteTextMessageById(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID, ChatMessageID.getCPtr(paramChatMessageID), paramChatMessageID);
    if (l == 0L) {
      return null;
    }
    return new IRemoteTextMessageViewModel(l, true);
  }
  
  public IUnreadChatMessageHandler GetUnreadChatMessageHandler()
  {
    long l = IChatViewModelLocatorSWIGJNI.IChatViewModelLocator_GetUnreadChatMessageHandler(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IUnreadChatMessageHandler(l, true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IChatViewModelLocatorSWIGJNI.delete_IChatViewModelLocator(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatViewModelLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */