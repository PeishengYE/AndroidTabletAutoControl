package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointListViewModelBaseSWIGJNI
{
  public static final native boolean IChatEndpointListViewModelBase_CanSelectMoreEndpoints(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase);
  
  public static final native void IChatEndpointListViewModelBase_DeselectChatEndpointAtPosition(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, int paramInt);
  
  public static final native long IChatEndpointListViewModelBase_GetChatEndpointViewModelAtPosition(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, int paramInt);
  
  public static final native int IChatEndpointListViewModelBase_GetNumberOfChatEndpoints(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase);
  
  public static final native boolean IChatEndpointListViewModelBase_IsLoggedIn(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase);
  
  public static final native void IChatEndpointListViewModelBase_SelectChatEndpointAtPosition(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, int paramInt);
  
  public static final native void IChatEndpointListViewModelBase_SetFilter(long paramLong, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, String paramString);
  
  public static final native void delete_IChatEndpointListViewModelBase(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointListViewModelBaseSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */