package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationMemberListViewModelSWIGJNI
{
  public static final native long IConversationMemberListViewModel_GetConversationMemberAtPosition(long paramLong, IConversationMemberListViewModel paramIConversationMemberListViewModel, int paramInt);
  
  public static final native String IConversationMemberListViewModel_GetConversationName(long paramLong, IConversationMemberListViewModel paramIConversationMemberListViewModel);
  
  public static final native int IConversationMemberListViewModel_GetMemberCount(long paramLong, IConversationMemberListViewModel paramIConversationMemberListViewModel);
  
  public static final native void delete_IConversationMemberListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationMemberListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */