package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatMessageID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatMessageID()
  {
    this(ChatMessageIDSWIGJNI.new_ChatMessageID(), true);
  }
  
  public ChatMessageID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ChatMessageID paramChatMessageID)
  {
    if (paramChatMessageID == null) {
      return 0L;
    }
    return paramChatMessageID.swigCPtr;
  }
  
  public boolean Equal(ChatMessageID paramChatMessageID)
  {
    return ChatMessageIDSWIGJNI.ChatMessageID_Equal(this.swigCPtr, this, getCPtr(paramChatMessageID), paramChatMessageID);
  }
  
  public ChatMessageUITypes GetType()
  {
    return ChatMessageUITypes.swigToEnum(ChatMessageIDSWIGJNI.ChatMessageID_GetType(this.swigCPtr, this));
  }
  
  public boolean LessThan(ChatMessageID paramChatMessageID)
  {
    return ChatMessageIDSWIGJNI.ChatMessageID_LessThan(this.swigCPtr, this, getCPtr(paramChatMessageID), paramChatMessageID);
  }
  
  public boolean NotEqual(ChatMessageID paramChatMessageID)
  {
    return ChatMessageIDSWIGJNI.ChatMessageID_NotEqual(this.swigCPtr, this, getCPtr(paramChatMessageID), paramChatMessageID);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ChatMessageIDSWIGJNI.delete_ChatMessageID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatMessageID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */