package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IReadSentIndicatorViewModelSWIGJNI
{
  public static final native int IReadSentIndicatorViewModel_GetState(long paramLong, IReadSentIndicatorViewModel paramIReadSentIndicatorViewModel);
  
  public static final native void delete_IReadSentIndicatorViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IReadSentIndicatorViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */