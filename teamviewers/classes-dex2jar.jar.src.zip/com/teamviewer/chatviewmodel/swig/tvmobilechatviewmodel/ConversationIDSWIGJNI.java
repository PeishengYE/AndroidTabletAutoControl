package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ConversationIDSWIGJNI
{
  public static final native boolean ChatConversationID_Equal(long paramLong1, ChatConversationID paramChatConversationID1, long paramLong2, ChatConversationID paramChatConversationID2);
  
  public static final native long ChatConversationID_InvalidConversationID_get();
  
  public static final native boolean ChatConversationID_IsEmptyTemporaryRoom(long paramLong, ChatConversationID paramChatConversationID);
  
  public static final native boolean ChatConversationID_LessThan(long paramLong1, ChatConversationID paramChatConversationID1, long paramLong2, ChatConversationID paramChatConversationID2);
  
  public static final native boolean ChatConversationID_NotEqual(long paramLong1, ChatConversationID paramChatConversationID1, long paramLong2, ChatConversationID paramChatConversationID2);
  
  public static final native void delete_ChatConversationID(long paramLong);
  
  public static final native long new_ChatConversationID();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ConversationIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */