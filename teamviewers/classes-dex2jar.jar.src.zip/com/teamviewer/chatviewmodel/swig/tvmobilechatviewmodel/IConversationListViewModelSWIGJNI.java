package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationListViewModelSWIGJNI
{
  public static final native void ChatConversationIDVector_add(long paramLong1, ChatConversationIDVector paramChatConversationIDVector, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long ChatConversationIDVector_capacity(long paramLong, ChatConversationIDVector paramChatConversationIDVector);
  
  public static final native void ChatConversationIDVector_clear(long paramLong, ChatConversationIDVector paramChatConversationIDVector);
  
  public static final native long ChatConversationIDVector_get(long paramLong, ChatConversationIDVector paramChatConversationIDVector, int paramInt);
  
  public static final native boolean ChatConversationIDVector_isEmpty(long paramLong, ChatConversationIDVector paramChatConversationIDVector);
  
  public static final native void ChatConversationIDVector_reserve(long paramLong1, ChatConversationIDVector paramChatConversationIDVector, long paramLong2);
  
  public static final native void ChatConversationIDVector_set(long paramLong1, ChatConversationIDVector paramChatConversationIDVector, int paramInt, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long ChatConversationIDVector_size(long paramLong, ChatConversationIDVector paramChatConversationIDVector);
  
  public static final native boolean IConversationListViewModel_CanCreateNewConversation(long paramLong, IConversationListViewModel paramIConversationListViewModel);
  
  public static final native long IConversationListViewModel_GetConversationAtPosition(long paramLong, IConversationListViewModel paramIConversationListViewModel, int paramInt);
  
  public static final native long IConversationListViewModel_GetConversationGuidForProviderId(long paramLong, IConversationListViewModel paramIConversationListViewModel, String paramString);
  
  public static final native int IConversationListViewModel_GetNumberOfConversations(long paramLong, IConversationListViewModel paramIConversationListViewModel);
  
  public static final native boolean IConversationListViewModel_HasMoreConversations(long paramLong, IConversationListViewModel paramIConversationListViewModel);
  
  public static final native boolean IConversationListViewModel_IsLoading(long paramLong, IConversationListViewModel paramIConversationListViewModel);
  
  public static final native void IConversationListViewModel_LoadMoreConversations(long paramLong, IConversationListViewModel paramIConversationListViewModel, int paramInt);
  
  public static final native long IConversationListViewModel_RequestNewRoom(long paramLong, IConversationListViewModel paramIConversationListViewModel);
  
  public static final native void delete_ChatConversationIDVector(long paramLong);
  
  public static final native void delete_IConversationListViewModel(long paramLong);
  
  public static final native long new_ChatConversationIDVector__SWIG_0();
  
  public static final native long new_ChatConversationIDVector__SWIG_1(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */