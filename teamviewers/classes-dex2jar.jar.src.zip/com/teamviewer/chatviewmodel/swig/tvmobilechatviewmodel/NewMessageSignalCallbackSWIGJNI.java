package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class NewMessageSignalCallbackSWIGJNI
{
  static {}
  
  public static final native void NewMessageSignalCallback_PerformNewMessage(long paramLong, NewMessageSignalCallback paramNewMessageSignalCallback, String paramString1, String paramString2);
  
  public static final native long NewMessageSignalCallback_SWIGUpcast(long paramLong);
  
  public static final native void NewMessageSignalCallback_change_ownership(NewMessageSignalCallback paramNewMessageSignalCallback, long paramLong, boolean paramBoolean);
  
  public static final native void NewMessageSignalCallback_director_connect(NewMessageSignalCallback paramNewMessageSignalCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_NewMessageSignalCallback_PerformNewMessage(NewMessageSignalCallback paramNewMessageSignalCallback, String paramString1, String paramString2)
  {
    paramNewMessageSignalCallback.PerformNewMessage(paramString1, paramString2);
  }
  
  public static final native void delete_NewMessageSignalCallback(long paramLong);
  
  public static final native long new_NewMessageSignalCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/NewMessageSignalCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */