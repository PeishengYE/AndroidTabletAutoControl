package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationOptionsViewModelAndroid
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IConversationOptionsViewModelAndroid(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid)
  {
    if (paramIConversationOptionsViewModelAndroid == null) {
      return 0L;
    }
    return paramIConversationOptionsViewModelAndroid.swigCPtr;
  }
  
  public boolean CanAddParticipants()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanAddParticipants(this.swigCPtr, this);
  }
  
  public boolean CanDeleteConversation()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanDeleteConversation(this.swigCPtr, this);
  }
  
  public boolean CanDeleteHistory()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanDeleteHistory(this.swigCPtr, this);
  }
  
  public boolean CanLeaveConversation()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanLeaveConversation(this.swigCPtr, this);
  }
  
  public boolean CanRemoteControl()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanRemoteControl(this.swigCPtr, this);
  }
  
  public boolean CanRenameConversation()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanRenameConversation(this.swigCPtr, this);
  }
  
  public boolean CanSendMessage()
  {
    return IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_CanSendMessage(this.swigCPtr, this);
  }
  
  public void DeleteConversation()
  {
    IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_DeleteConversation(this.swigCPtr, this);
  }
  
  public void DeleteHistory()
  {
    IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_DeleteHistory(this.swigCPtr, this);
  }
  
  public void GetConnectionInfoForRemoteControl(IConnectionInfoCallback paramIConnectionInfoCallback)
  {
    IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_GetConnectionInfoForRemoteControl(this.swigCPtr, this, IConnectionInfoCallback.getCPtr(paramIConnectionInfoCallback), paramIConnectionInfoCallback);
  }
  
  public void LeaveConversation()
  {
    IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_LeaveConversation(this.swigCPtr, this);
  }
  
  public void RequestRenameConversation(String paramString)
  {
    IConversationOptionsViewModelAndroidSWIGJNI.IConversationOptionsViewModelAndroid_RequestRenameConversation(this.swigCPtr, this, paramString);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationOptionsViewModelAndroidSWIGJNI.delete_IConversationOptionsViewModelAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationOptionsViewModelAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */