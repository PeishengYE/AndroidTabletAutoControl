package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointListViewModel
  extends IChatEndpointListViewModelBase
{
  private boolean swigCMemOwnDerived;
  private transient long swigCPtr;
  
  public IChatEndpointListViewModel(long paramLong, boolean paramBoolean)
  {
    super(IChatEndpointListViewModelSWIGJNI.IChatEndpointListViewModel_SWIGSmartPtrUpcast(paramLong), true);
    this.swigCMemOwnDerived = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IChatEndpointListViewModel paramIChatEndpointListViewModel)
  {
    if (paramIChatEndpointListViewModel == null) {
      return 0L;
    }
    return paramIChatEndpointListViewModel.swigCPtr;
  }
  
  public boolean CanRequestConversation()
  {
    return IChatEndpointListViewModelSWIGJNI.IChatEndpointListViewModel_CanRequestConversation(this.swigCPtr, this);
  }
  
  public void RemoveNewConversation()
  {
    IChatEndpointListViewModelSWIGJNI.IChatEndpointListViewModel_RemoveNewConversation(this.swigCPtr, this);
  }
  
  public ChatConversationID RequestConversation()
  {
    return new ChatConversationID(IChatEndpointListViewModelSWIGJNI.IChatEndpointListViewModel_RequestConversation(this.swigCPtr, this), true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwnDerived)
        {
          this.swigCMemOwnDerived = false;
          IChatEndpointListViewModelSWIGJNI.delete_IChatEndpointListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */