package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.IListChangeSignalCallback;

public class ChatSignalsHelper
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatSignalsHelper(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static void RegisterChatEndpointChangedSlot(IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterChatEndpointChangedSlot(IChatEndpointListViewModelBase.getCPtr(paramIChatEndpointListViewModelBase), paramIChatEndpointListViewModelBase, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterChatEndpointListChangedSlot(IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, IListChangeSignalCallback paramIListChangeSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterChatEndpointListChangedSlot(IChatEndpointListViewModelBase.getCPtr(paramIChatEndpointListViewModelBase), paramIChatEndpointListViewModelBase, IListChangeSignalCallback.getCPtr(paramIListChangeSignalCallback), paramIListChangeSignalCallback);
  }
  
  public static void RegisterConversationChangedSlot(IConversationViewModel paramIConversationViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationChangedSlot(IConversationViewModel.getCPtr(paramIConversationViewModel), paramIConversationViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterConversationHistoryListListChangedSlot(IConversationHistoryListViewModel paramIConversationHistoryListViewModel, IListChangeSignalCallback paramIListChangeSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationHistoryListListChangedSlot(IConversationHistoryListViewModel.getCPtr(paramIConversationHistoryListViewModel), paramIConversationHistoryListViewModel, IListChangeSignalCallback.getCPtr(paramIListChangeSignalCallback), paramIListChangeSignalCallback);
  }
  
  public static void RegisterConversationHistoryListRemovedChangedSlot(IConversationHistoryListViewModel paramIConversationHistoryListViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationHistoryListRemovedChangedSlot(IConversationHistoryListViewModel.getCPtr(paramIConversationHistoryListViewModel), paramIConversationHistoryListViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterConversationHistoryListStatusChangedSlot(IConversationHistoryListViewModel paramIConversationHistoryListViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationHistoryListStatusChangedSlot(IConversationHistoryListViewModel.getCPtr(paramIConversationHistoryListViewModel), paramIConversationHistoryListViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterConversationListListChangedSlot(IConversationListViewModel paramIConversationListViewModel, IListChangeSignalCallback paramIListChangeSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationListListChangedSlot(IConversationListViewModel.getCPtr(paramIConversationListViewModel), paramIConversationListViewModel, IListChangeSignalCallback.getCPtr(paramIListChangeSignalCallback), paramIListChangeSignalCallback);
  }
  
  public static void RegisterConversationListStatusChangedSlot(IConversationListViewModel paramIConversationListViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationListStatusChangedSlot(IConversationListViewModel.getCPtr(paramIConversationListViewModel), paramIConversationListViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterConversationOptionsChangedSlot(IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterConversationOptionsChangedSlot(IConversationOptionsViewModelAndroid.getCPtr(paramIConversationOptionsViewModelAndroid), paramIConversationOptionsViewModelAndroid, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterErrorMessagesChangedSlot(IErrorMessageHandler paramIErrorMessageHandler, ErrorMessageSignalCallback paramErrorMessageSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterErrorMessagesChangedSlot(IErrorMessageHandler.getCPtr(paramIErrorMessageHandler), paramIErrorMessageHandler, ErrorMessageSignalCallback.getCPtr(paramErrorMessageSignalCallback), paramErrorMessageSignalCallback);
  }
  
  public static void RegisterNewMessagesSignalSlot(IUnreadChatMessageHandler paramIUnreadChatMessageHandler, NewMessageSignalCallback paramNewMessageSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterNewMessagesSignalSlot(IUnreadChatMessageHandler.getCPtr(paramIUnreadChatMessageHandler), paramIUnreadChatMessageHandler, NewMessageSignalCallback.getCPtr(paramNewMessageSignalCallback), paramNewMessageSignalCallback);
  }
  
  public static void RegisterOwnTextMessageChangedSlot(IOwnTextMessageViewModel paramIOwnTextMessageViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterOwnTextMessageChangedSlot(IOwnTextMessageViewModel.getCPtr(paramIOwnTextMessageViewModel), paramIOwnTextMessageViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterReadSentStateChangedSlot(IReadSentIndicatorViewModel paramIReadSentIndicatorViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterReadSentStateChangedSlot(IReadSentIndicatorViewModel.getCPtr(paramIReadSentIndicatorViewModel), paramIReadSentIndicatorViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static void RegisterRemoteTextMessageChangedSlot(IRemoteTextMessageViewModel paramIRemoteTextMessageViewModel, IGenericSignalCallback paramIGenericSignalCallback)
  {
    ChatSignalsHelperSWIGJNI.ChatSignalsHelper_RegisterRemoteTextMessageChangedSlot(IRemoteTextMessageViewModel.getCPtr(paramIRemoteTextMessageViewModel), paramIRemoteTextMessageViewModel, IGenericSignalCallback.getCPtr(paramIGenericSignalCallback), paramIGenericSignalCallback);
  }
  
  public static long getCPtr(ChatSignalsHelper paramChatSignalsHelper)
  {
    if (paramChatSignalsHelper == null) {
      return 0L;
    }
    return paramChatSignalsHelper.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ChatSignalsHelperSWIGJNI.delete_ChatSignalsHelper(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatSignalsHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */