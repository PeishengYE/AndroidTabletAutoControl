package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointListViewModelSWIGJNI
{
  public static final native boolean IChatEndpointListViewModel_CanRequestConversation(long paramLong, IChatEndpointListViewModel paramIChatEndpointListViewModel);
  
  public static final native void IChatEndpointListViewModel_RemoveNewConversation(long paramLong, IChatEndpointListViewModel paramIChatEndpointListViewModel);
  
  public static final native long IChatEndpointListViewModel_RequestConversation(long paramLong, IChatEndpointListViewModel paramIChatEndpointListViewModel);
  
  public static final native long IChatEndpointListViewModel_SWIGSmartPtrUpcast(long paramLong);
  
  public static final native void delete_IChatEndpointListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */