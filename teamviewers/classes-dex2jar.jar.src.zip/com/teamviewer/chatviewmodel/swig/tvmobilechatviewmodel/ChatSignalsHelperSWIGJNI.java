package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import com.teamviewer.commonviewmodel.swig.IGenericSignalCallback;
import com.teamviewer.commonviewmodel.swig.IListChangeSignalCallback;

public class ChatSignalsHelperSWIGJNI
{
  public static final native void ChatSignalsHelper_RegisterChatEndpointChangedSlot(long paramLong1, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterChatEndpointListChangedSlot(long paramLong1, IChatEndpointListViewModelBase paramIChatEndpointListViewModelBase, long paramLong2, IListChangeSignalCallback paramIListChangeSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationChangedSlot(long paramLong1, IConversationViewModel paramIConversationViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationHistoryListListChangedSlot(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2, IListChangeSignalCallback paramIListChangeSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationHistoryListRemovedChangedSlot(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationHistoryListStatusChangedSlot(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationListListChangedSlot(long paramLong1, IConversationListViewModel paramIConversationListViewModel, long paramLong2, IListChangeSignalCallback paramIListChangeSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationListStatusChangedSlot(long paramLong1, IConversationListViewModel paramIConversationListViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterConversationOptionsChangedSlot(long paramLong1, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterErrorMessagesChangedSlot(long paramLong1, IErrorMessageHandler paramIErrorMessageHandler, long paramLong2, ErrorMessageSignalCallback paramErrorMessageSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterNewMessagesSignalSlot(long paramLong1, IUnreadChatMessageHandler paramIUnreadChatMessageHandler, long paramLong2, NewMessageSignalCallback paramNewMessageSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterOwnTextMessageChangedSlot(long paramLong1, IOwnTextMessageViewModel paramIOwnTextMessageViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterReadSentStateChangedSlot(long paramLong1, IReadSentIndicatorViewModel paramIReadSentIndicatorViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void ChatSignalsHelper_RegisterRemoteTextMessageChangedSlot(long paramLong1, IRemoteTextMessageViewModel paramIRemoteTextMessageViewModel, long paramLong2, IGenericSignalCallback paramIGenericSignalCallback);
  
  public static final native void delete_ChatSignalsHelper(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatSignalsHelperSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */