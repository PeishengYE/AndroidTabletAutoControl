package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatConversationIDVector
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatConversationIDVector()
  {
    this(IConversationListViewModelSWIGJNI.new_ChatConversationIDVector__SWIG_0(), true);
  }
  
  public ChatConversationIDVector(long paramLong)
  {
    this(IConversationListViewModelSWIGJNI.new_ChatConversationIDVector__SWIG_1(paramLong), true);
  }
  
  public ChatConversationIDVector(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ChatConversationIDVector paramChatConversationIDVector)
  {
    if (paramChatConversationIDVector == null) {
      return 0L;
    }
    return paramChatConversationIDVector.swigCPtr;
  }
  
  public void add(ChatConversationID paramChatConversationID)
  {
    IConversationListViewModelSWIGJNI.ChatConversationIDVector_add(this.swigCPtr, this, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public long capacity()
  {
    return IConversationListViewModelSWIGJNI.ChatConversationIDVector_capacity(this.swigCPtr, this);
  }
  
  public void clear()
  {
    IConversationListViewModelSWIGJNI.ChatConversationIDVector_clear(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationListViewModelSWIGJNI.delete_ChatConversationIDVector(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  public ChatConversationID get(int paramInt)
  {
    return new ChatConversationID(IConversationListViewModelSWIGJNI.ChatConversationIDVector_get(this.swigCPtr, this, paramInt), false);
  }
  
  public boolean isEmpty()
  {
    return IConversationListViewModelSWIGJNI.ChatConversationIDVector_isEmpty(this.swigCPtr, this);
  }
  
  public void reserve(long paramLong)
  {
    IConversationListViewModelSWIGJNI.ChatConversationIDVector_reserve(this.swigCPtr, this, paramLong);
  }
  
  public void set(int paramInt, ChatConversationID paramChatConversationID)
  {
    IConversationListViewModelSWIGJNI.ChatConversationIDVector_set(this.swigCPtr, this, paramInt, ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public long size()
  {
    return IConversationListViewModelSWIGJNI.ChatConversationIDVector_size(this.swigCPtr, this);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatConversationIDVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */