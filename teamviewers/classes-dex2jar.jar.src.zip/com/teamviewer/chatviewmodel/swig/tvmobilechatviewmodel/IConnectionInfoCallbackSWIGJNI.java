package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConnectionInfoCallbackSWIGJNI
{
  public static final native void delete_IConnectionInfoCallback(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConnectionInfoCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */