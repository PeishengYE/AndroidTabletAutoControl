package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import com.teamviewer.commonviewmodel.swig.SignalCallbackBase;
import com.teamviewer.corelib.logging.Logging;

public abstract class ErrorMessageSignalCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public ErrorMessageSignalCallback()
  {
    this(ErrorMessageSignalCallbackSWIGJNI.new_ErrorMessageSignalCallback(), true);
    ErrorMessageSignalCallbackSWIGJNI.ErrorMessageSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public ErrorMessageSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(ErrorMessageSignalCallbackSWIGJNI.ErrorMessageSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ErrorMessageSignalCallback paramErrorMessageSignalCallback)
  {
    if (paramErrorMessageSignalCallback == null) {
      return 0L;
    }
    return paramErrorMessageSignalCallback.swigCPtr;
  }
  
  public abstract void OnErrorMessage(ErrorMessage paramErrorMessage);
  
  public void PerformErrorMessage(ErrorMessage paramErrorMessage)
  {
    try
    {
      OnErrorMessage(paramErrorMessage);
      return;
    }
    catch (Throwable paramErrorMessage)
    {
      Logging.a("ErrorMessageSignalCallback", paramErrorMessage);
      throw paramErrorMessage;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ErrorMessageSignalCallbackSWIGJNI.delete_ErrorMessageSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    ErrorMessageSignalCallbackSWIGJNI.ErrorMessageSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    ErrorMessageSignalCallbackSWIGJNI.ErrorMessageSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ErrorMessageSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */