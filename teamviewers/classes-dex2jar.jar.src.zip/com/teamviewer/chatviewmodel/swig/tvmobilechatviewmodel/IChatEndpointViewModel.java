package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IChatEndpointViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IChatEndpointViewModel paramIChatEndpointViewModel)
  {
    if (paramIChatEndpointViewModel == null) {
      return 0L;
    }
    return paramIChatEndpointViewModel.swigCPtr;
  }
  
  public String GetAccountPictureUrl()
  {
    return IChatEndpointViewModelSWIGJNI.IChatEndpointViewModel_GetAccountPictureUrl(this.swigCPtr, this);
  }
  
  public String GetDisplayName()
  {
    return IChatEndpointViewModelSWIGJNI.IChatEndpointViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public EndpointUIState GetState()
  {
    return EndpointUIState.swigToEnum(IChatEndpointViewModelSWIGJNI.IChatEndpointViewModel_GetState(this.swigCPtr, this));
  }
  
  public ChatEndpointTypeUI GetType()
  {
    return ChatEndpointTypeUI.swigToEnum(IChatEndpointViewModelSWIGJNI.IChatEndpointViewModel_GetType(this.swigCPtr, this));
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IChatEndpointViewModelSWIGJNI.delete_IChatEndpointViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */