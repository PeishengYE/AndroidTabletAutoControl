package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatViewModelLocatorAndroid
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatViewModelLocatorAndroid(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static IChatViewModelLocator GetChatViewModelLocator()
  {
    long l = ChatViewModelLocatorAndroidSWIGJNI.ChatViewModelLocatorAndroid_GetChatViewModelLocator();
    if (l == 0L) {
      return null;
    }
    return new IChatViewModelLocator(l, true);
  }
  
  public static IConversationOptionsViewModelAndroid GetConversationOptionsViewModelAndroid(ChatConversationID paramChatConversationID)
  {
    long l = ChatViewModelLocatorAndroidSWIGJNI.ChatViewModelLocatorAndroid_GetConversationOptionsViewModelAndroid(ChatConversationID.getCPtr(paramChatConversationID), paramChatConversationID);
    if (l == 0L) {
      return null;
    }
    return new IConversationOptionsViewModelAndroid(l, true);
  }
  
  public static IStartChatViewModelAndroid GetStartChatViewModelAndroid()
  {
    long l = ChatViewModelLocatorAndroidSWIGJNI.ChatViewModelLocatorAndroid_GetStartChatViewModelAndroid();
    if (l == 0L) {
      return null;
    }
    return new IStartChatViewModelAndroid(l, true);
  }
  
  public static long getCPtr(ChatViewModelLocatorAndroid paramChatViewModelLocatorAndroid)
  {
    if (paramChatViewModelLocatorAndroid == null) {
      return 0L;
    }
    return paramChatViewModelLocatorAndroid.swigCPtr;
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ChatViewModelLocatorAndroidSWIGJNI.delete_ChatViewModelLocatorAndroid(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatViewModelLocatorAndroid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */