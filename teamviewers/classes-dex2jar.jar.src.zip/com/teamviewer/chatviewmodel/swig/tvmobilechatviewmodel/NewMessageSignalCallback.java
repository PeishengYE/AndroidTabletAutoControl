package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

import com.teamviewer.commonviewmodel.swig.SignalCallbackBase;
import com.teamviewer.corelib.logging.Logging;

public abstract class NewMessageSignalCallback
  extends SignalCallbackBase
{
  private transient long swigCPtr;
  
  public NewMessageSignalCallback()
  {
    this(NewMessageSignalCallbackSWIGJNI.new_NewMessageSignalCallback(), true);
    NewMessageSignalCallbackSWIGJNI.NewMessageSignalCallback_director_connect(this, this.swigCPtr, this.swigCMemOwn, true);
  }
  
  public NewMessageSignalCallback(long paramLong, boolean paramBoolean)
  {
    super(NewMessageSignalCallbackSWIGJNI.NewMessageSignalCallback_SWIGUpcast(paramLong), paramBoolean);
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(NewMessageSignalCallback paramNewMessageSignalCallback)
  {
    if (paramNewMessageSignalCallback == null) {
      return 0L;
    }
    return paramNewMessageSignalCallback.swigCPtr;
  }
  
  public abstract void OnNewMessage(String paramString1, String paramString2);
  
  public void PerformNewMessage(String paramString1, String paramString2)
  {
    try
    {
      OnNewMessage(paramString1, paramString2);
      return;
    }
    catch (Throwable paramString1)
    {
      Logging.a("NewMessageSignalCallback", paramString1);
      throw paramString1;
    }
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          NewMessageSignalCallbackSWIGJNI.delete_NewMessageSignalCallback(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      super.delete();
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
  
  protected void swigDirectorDisconnect()
  {
    this.swigCMemOwn = false;
    delete();
  }
  
  public void swigReleaseOwnership()
  {
    this.swigCMemOwn = false;
    NewMessageSignalCallbackSWIGJNI.NewMessageSignalCallback_change_ownership(this, this.swigCPtr, false);
  }
  
  public void swigTakeOwnership()
  {
    this.swigCMemOwn = true;
    NewMessageSignalCallbackSWIGJNI.NewMessageSignalCallback_change_ownership(this, this.swigCPtr, true);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/NewMessageSignalCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */