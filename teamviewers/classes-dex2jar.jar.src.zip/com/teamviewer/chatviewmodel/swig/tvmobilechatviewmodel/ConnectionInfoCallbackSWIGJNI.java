package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ConnectionInfoCallbackSWIGJNI
{
  static {}
  
  public static final native void ConnectionInfoCallback_PerformConnectionToAccount(long paramLong1, ConnectionInfoCallback paramConnectionInfoCallback, long paramLong2);
  
  public static final native void ConnectionInfoCallback_PerformConnectionToMachine(long paramLong1, ConnectionInfoCallback paramConnectionInfoCallback, long paramLong2);
  
  public static final native void ConnectionInfoCallback_PerformConnectionToServiceCase(long paramLong1, ConnectionInfoCallback paramConnectionInfoCallback, long paramLong2);
  
  public static final native void ConnectionInfoCallback_PerformError(long paramLong, ConnectionInfoCallback paramConnectionInfoCallback);
  
  public static final native long ConnectionInfoCallback_SWIGUpcast(long paramLong);
  
  public static final native void ConnectionInfoCallback_change_ownership(ConnectionInfoCallback paramConnectionInfoCallback, long paramLong, boolean paramBoolean);
  
  public static final native void ConnectionInfoCallback_director_connect(ConnectionInfoCallback paramConnectionInfoCallback, long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  public static void SwigDirector_ConnectionInfoCallback_PerformConnectionToAccount(ConnectionInfoCallback paramConnectionInfoCallback, long paramLong)
  {
    paramConnectionInfoCallback.PerformConnectionToAccount(paramLong);
  }
  
  public static void SwigDirector_ConnectionInfoCallback_PerformConnectionToMachine(ConnectionInfoCallback paramConnectionInfoCallback, long paramLong)
  {
    paramConnectionInfoCallback.PerformConnectionToMachine(paramLong);
  }
  
  public static void SwigDirector_ConnectionInfoCallback_PerformConnectionToServiceCase(ConnectionInfoCallback paramConnectionInfoCallback, long paramLong)
  {
    paramConnectionInfoCallback.PerformConnectionToServiceCase(paramLong);
  }
  
  public static void SwigDirector_ConnectionInfoCallback_PerformError(ConnectionInfoCallback paramConnectionInfoCallback)
  {
    paramConnectionInfoCallback.PerformError();
  }
  
  public static final native void delete_ConnectionInfoCallback(long paramLong);
  
  public static final native long new_ConnectionInfoCallback();
  
  private static final native void swig_module_init();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ConnectionInfoCallbackSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */