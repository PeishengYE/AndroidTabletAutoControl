package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationHistoryListViewModelSWIGJNI
{
  public static final native long IConversationHistoryListViewModel_GetConversationID(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native long IConversationHistoryListViewModel_GetConversationMemberViewModel(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native long IConversationHistoryListViewModel_GetDateSeparatorViewModelById(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2, ChatMessageID paramChatMessageID);
  
  public static final native String IConversationHistoryListViewModel_GetLastTypedMessage(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native long IConversationHistoryListViewModel_GetMessageAtPosition(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, int paramInt);
  
  public static final native int IConversationHistoryListViewModel_GetNumberOfMessages(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native long IConversationHistoryListViewModel_GetReadSentIndicatorViewModelById(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2, ChatMessageID paramChatMessageID);
  
  public static final native String IConversationHistoryListViewModel_GetTitle(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native boolean IConversationHistoryListViewModel_HasMoreMessages(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native boolean IConversationHistoryListViewModel_IsGroupChat(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native boolean IConversationHistoryListViewModel_IsLoading(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native boolean IConversationHistoryListViewModel_IsRemoved(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native void IConversationHistoryListViewModel_LoadMoreMessages(long paramLong1, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, long paramLong2);
  
  public static final native void IConversationHistoryListViewModel_MessagesRead(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel);
  
  public static final native boolean IConversationHistoryListViewModel_SendMessage(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, String paramString);
  
  public static final native void IConversationHistoryListViewModel_SendTypingEvent(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, boolean paramBoolean);
  
  public static final native void IConversationHistoryListViewModel_SetLastTypedMessage(long paramLong, IConversationHistoryListViewModel paramIConversationHistoryListViewModel, String paramString);
  
  public static final native void delete_IConversationHistoryListViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationHistoryListViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */