package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatConversationID
{
  protected transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public ChatConversationID()
  {
    this(ConversationIDSWIGJNI.new_ChatConversationID(), true);
  }
  
  public ChatConversationID(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(ChatConversationID paramChatConversationID)
  {
    if (paramChatConversationID == null) {
      return 0L;
    }
    return paramChatConversationID.swigCPtr;
  }
  
  public static ChatConversationID getInvalidConversationID()
  {
    long l = ConversationIDSWIGJNI.ChatConversationID_InvalidConversationID_get();
    if (l == 0L) {
      return null;
    }
    return new ChatConversationID(l, false);
  }
  
  public boolean Equal(ChatConversationID paramChatConversationID)
  {
    return ConversationIDSWIGJNI.ChatConversationID_Equal(this.swigCPtr, this, getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public boolean IsEmptyTemporaryRoom()
  {
    return ConversationIDSWIGJNI.ChatConversationID_IsEmptyTemporaryRoom(this.swigCPtr, this);
  }
  
  public boolean LessThan(ChatConversationID paramChatConversationID)
  {
    return ConversationIDSWIGJNI.ChatConversationID_LessThan(this.swigCPtr, this, getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public boolean NotEqual(ChatConversationID paramChatConversationID)
  {
    return ConversationIDSWIGJNI.ChatConversationID_NotEqual(this.swigCPtr, this, getCPtr(paramChatConversationID), paramChatConversationID);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          ConversationIDSWIGJNI.delete_ChatConversationID(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatConversationID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */