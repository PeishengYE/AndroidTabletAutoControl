package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatMessageIDSWIGJNI
{
  public static final native boolean ChatMessageID_Equal(long paramLong1, ChatMessageID paramChatMessageID1, long paramLong2, ChatMessageID paramChatMessageID2);
  
  public static final native int ChatMessageID_GetType(long paramLong, ChatMessageID paramChatMessageID);
  
  public static final native boolean ChatMessageID_LessThan(long paramLong1, ChatMessageID paramChatMessageID1, long paramLong2, ChatMessageID paramChatMessageID2);
  
  public static final native boolean ChatMessageID_NotEqual(long paramLong1, ChatMessageID paramChatMessageID1, long paramLong2, ChatMessageID paramChatMessageID2);
  
  public static final native void delete_ChatMessageID(long paramLong);
  
  public static final native long new_ChatMessageID();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatMessageIDSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */