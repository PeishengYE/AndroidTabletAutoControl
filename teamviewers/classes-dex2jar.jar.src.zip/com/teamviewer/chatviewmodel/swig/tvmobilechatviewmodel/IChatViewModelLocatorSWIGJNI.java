package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatViewModelLocatorSWIGJNI
{
  public static final native long IChatViewModelLocator_GetAddChatEndpointListViewModel(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long IChatViewModelLocator_GetChatEndpointListViewModel(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long IChatViewModelLocator_GetConversationHistoryListViewModelById(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long IChatViewModelLocator_GetConversationListViewModel(long paramLong, IChatViewModelLocator paramIChatViewModelLocator);
  
  public static final native long IChatViewModelLocator_GetConversationMemberListViewModel(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long IChatViewModelLocator_GetConversationViewModelById(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID);
  
  public static final native long IChatViewModelLocator_GetErrorMessageHandler(long paramLong, IChatViewModelLocator paramIChatViewModelLocator);
  
  public static final native long IChatViewModelLocator_GetEventMessageById(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID, long paramLong3, ChatMessageID paramChatMessageID);
  
  public static final native long IChatViewModelLocator_GetOwnTextMessageById(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID, long paramLong3, ChatMessageID paramChatMessageID);
  
  public static final native long IChatViewModelLocator_GetRemoteTextMessageById(long paramLong1, IChatViewModelLocator paramIChatViewModelLocator, long paramLong2, ChatConversationID paramChatConversationID, long paramLong3, ChatMessageID paramChatMessageID);
  
  public static final native long IChatViewModelLocator_GetUnreadChatMessageHandler(long paramLong, IChatViewModelLocator paramIChatViewModelLocator);
  
  public static final native void delete_IChatViewModelLocator(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatViewModelLocatorSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */