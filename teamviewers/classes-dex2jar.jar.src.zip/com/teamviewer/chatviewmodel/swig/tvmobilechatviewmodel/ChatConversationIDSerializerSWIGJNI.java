package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class ChatConversationIDSerializerSWIGJNI
{
  public static final native long ChatConversationIDSerializer_Deserialize(String paramString);
  
  public static final native String ChatConversationIDSerializer_Serialize(long paramLong, ChatConversationID paramChatConversationID);
  
  public static final native void delete_ChatConversationIDSerializer(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/ChatConversationIDSerializerSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */