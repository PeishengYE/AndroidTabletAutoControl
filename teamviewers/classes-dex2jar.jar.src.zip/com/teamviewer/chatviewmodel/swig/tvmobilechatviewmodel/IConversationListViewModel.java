package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IConversationListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IConversationListViewModel paramIConversationListViewModel)
  {
    if (paramIConversationListViewModel == null) {
      return 0L;
    }
    return paramIConversationListViewModel.swigCPtr;
  }
  
  public boolean CanCreateNewConversation()
  {
    return IConversationListViewModelSWIGJNI.IConversationListViewModel_CanCreateNewConversation(this.swigCPtr, this);
  }
  
  public ChatConversationID GetConversationAtPosition(int paramInt)
  {
    return new ChatConversationID(IConversationListViewModelSWIGJNI.IConversationListViewModel_GetConversationAtPosition(this.swigCPtr, this, paramInt), true);
  }
  
  public ChatConversationID GetConversationGuidForProviderId(String paramString)
  {
    return new ChatConversationID(IConversationListViewModelSWIGJNI.IConversationListViewModel_GetConversationGuidForProviderId(this.swigCPtr, this, paramString), true);
  }
  
  public int GetNumberOfConversations()
  {
    return IConversationListViewModelSWIGJNI.IConversationListViewModel_GetNumberOfConversations(this.swigCPtr, this);
  }
  
  public boolean HasMoreConversations()
  {
    return IConversationListViewModelSWIGJNI.IConversationListViewModel_HasMoreConversations(this.swigCPtr, this);
  }
  
  public boolean IsLoading()
  {
    return IConversationListViewModelSWIGJNI.IConversationListViewModel_IsLoading(this.swigCPtr, this);
  }
  
  public void LoadMoreConversations(int paramInt)
  {
    IConversationListViewModelSWIGJNI.IConversationListViewModel_LoadMoreConversations(this.swigCPtr, this, paramInt);
  }
  
  public ChatConversationID RequestNewRoom()
  {
    return new ChatConversationID(IConversationListViewModelSWIGJNI.IConversationListViewModel_RequestNewRoom(this.swigCPtr, this), true);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationListViewModelSWIGJNI.delete_IConversationListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */