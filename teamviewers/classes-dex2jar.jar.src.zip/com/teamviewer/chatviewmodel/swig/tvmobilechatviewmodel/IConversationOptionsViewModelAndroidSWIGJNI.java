package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationOptionsViewModelAndroidSWIGJNI
{
  public static final native boolean IConversationOptionsViewModelAndroid_CanAddParticipants(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanDeleteConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanDeleteHistory(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanLeaveConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanRemoteControl(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanRenameConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native boolean IConversationOptionsViewModelAndroid_CanSendMessage(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native void IConversationOptionsViewModelAndroid_DeleteConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native void IConversationOptionsViewModelAndroid_DeleteHistory(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native void IConversationOptionsViewModelAndroid_GetConnectionInfoForRemoteControl(long paramLong1, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid, long paramLong2, IConnectionInfoCallback paramIConnectionInfoCallback);
  
  public static final native void IConversationOptionsViewModelAndroid_LeaveConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid);
  
  public static final native void IConversationOptionsViewModelAndroid_RequestRenameConversation(long paramLong, IConversationOptionsViewModelAndroid paramIConversationOptionsViewModelAndroid, String paramString);
  
  public static final native void delete_IConversationOptionsViewModelAndroid(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationOptionsViewModelAndroidSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */