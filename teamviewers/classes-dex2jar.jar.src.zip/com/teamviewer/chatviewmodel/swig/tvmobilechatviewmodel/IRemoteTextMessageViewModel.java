package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IRemoteTextMessageViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IRemoteTextMessageViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IRemoteTextMessageViewModel paramIRemoteTextMessageViewModel)
  {
    if (paramIRemoteTextMessageViewModel == null) {
      return 0L;
    }
    return paramIRemoteTextMessageViewModel.swigCPtr;
  }
  
  public String GetAccountPictureUrl()
  {
    return IRemoteTextMessageViewModelSWIGJNI.IRemoteTextMessageViewModel_GetAccountPictureUrl(this.swigCPtr, this);
  }
  
  public String GetDisplayName()
  {
    return IRemoteTextMessageViewModelSWIGJNI.IRemoteTextMessageViewModel_GetDisplayName(this.swigCPtr, this);
  }
  
  public String GetMessage()
  {
    return IRemoteTextMessageViewModelSWIGJNI.IRemoteTextMessageViewModel_GetMessage(this.swigCPtr, this);
  }
  
  public long GetTimestamp()
  {
    return IRemoteTextMessageViewModelSWIGJNI.IRemoteTextMessageViewModel_GetTimestamp(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IRemoteTextMessageViewModelSWIGJNI.delete_IRemoteTextMessageViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IRemoteTextMessageViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */