package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationMemberListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IConversationMemberListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IConversationMemberListViewModel paramIConversationMemberListViewModel)
  {
    if (paramIConversationMemberListViewModel == null) {
      return 0L;
    }
    return paramIConversationMemberListViewModel.swigCPtr;
  }
  
  public IConversationMemberViewModel GetConversationMemberAtPosition(int paramInt)
  {
    long l = IConversationMemberListViewModelSWIGJNI.IConversationMemberListViewModel_GetConversationMemberAtPosition(this.swigCPtr, this, paramInt);
    if (l == 0L) {
      return null;
    }
    return new IConversationMemberViewModel(l, true);
  }
  
  public String GetConversationName()
  {
    return IConversationMemberListViewModelSWIGJNI.IConversationMemberListViewModel_GetConversationName(this.swigCPtr, this);
  }
  
  public int GetMemberCount()
  {
    return IConversationMemberListViewModelSWIGJNI.IConversationMemberListViewModel_GetMemberCount(this.swigCPtr, this);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationMemberListViewModelSWIGJNI.delete_IConversationMemberListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationMemberListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */