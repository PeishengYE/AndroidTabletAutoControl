package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationHistoryListViewModel
{
  private transient boolean swigCMemOwn;
  private transient long swigCPtr;
  
  public IConversationHistoryListViewModel(long paramLong, boolean paramBoolean)
  {
    this.swigCMemOwn = paramBoolean;
    this.swigCPtr = paramLong;
  }
  
  public static long getCPtr(IConversationHistoryListViewModel paramIConversationHistoryListViewModel)
  {
    if (paramIConversationHistoryListViewModel == null) {
      return 0L;
    }
    return paramIConversationHistoryListViewModel.swigCPtr;
  }
  
  public ChatConversationID GetConversationID()
  {
    return new ChatConversationID(IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetConversationID(this.swigCPtr, this), true);
  }
  
  public IConversationMemberViewModel GetConversationMemberViewModel()
  {
    long l = IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetConversationMemberViewModel(this.swigCPtr, this);
    if (l == 0L) {
      return null;
    }
    return new IConversationMemberViewModel(l, true);
  }
  
  public IDateSeparatorViewModel GetDateSeparatorViewModelById(ChatMessageID paramChatMessageID)
  {
    long l = IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetDateSeparatorViewModelById(this.swigCPtr, this, ChatMessageID.getCPtr(paramChatMessageID), paramChatMessageID);
    if (l == 0L) {
      return null;
    }
    return new IDateSeparatorViewModel(l, true);
  }
  
  public String GetLastTypedMessage()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetLastTypedMessage(this.swigCPtr, this);
  }
  
  public ChatMessageID GetMessageAtPosition(int paramInt)
  {
    return new ChatMessageID(IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetMessageAtPosition(this.swigCPtr, this, paramInt), true);
  }
  
  public int GetNumberOfMessages()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetNumberOfMessages(this.swigCPtr, this);
  }
  
  public IReadSentIndicatorViewModel GetReadSentIndicatorViewModelById(ChatMessageID paramChatMessageID)
  {
    long l = IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetReadSentIndicatorViewModelById(this.swigCPtr, this, ChatMessageID.getCPtr(paramChatMessageID), paramChatMessageID);
    if (l == 0L) {
      return null;
    }
    return new IReadSentIndicatorViewModel(l, true);
  }
  
  public String GetTitle()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_GetTitle(this.swigCPtr, this);
  }
  
  public boolean HasMoreMessages()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_HasMoreMessages(this.swigCPtr, this);
  }
  
  public boolean IsGroupChat()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_IsGroupChat(this.swigCPtr, this);
  }
  
  public boolean IsLoading()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_IsLoading(this.swigCPtr, this);
  }
  
  public boolean IsRemoved()
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_IsRemoved(this.swigCPtr, this);
  }
  
  public void LoadMoreMessages(long paramLong)
  {
    IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_LoadMoreMessages(this.swigCPtr, this, paramLong);
  }
  
  public void MessagesRead()
  {
    IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_MessagesRead(this.swigCPtr, this);
  }
  
  public boolean SendMessage(String paramString)
  {
    return IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_SendMessage(this.swigCPtr, this, paramString);
  }
  
  public void SendTypingEvent(boolean paramBoolean)
  {
    IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_SendTypingEvent(this.swigCPtr, this, paramBoolean);
  }
  
  public void SetLastTypedMessage(String paramString)
  {
    IConversationHistoryListViewModelSWIGJNI.IConversationHistoryListViewModel_SetLastTypedMessage(this.swigCPtr, this, paramString);
  }
  
  public void delete()
  {
    try
    {
      if (this.swigCPtr != 0L)
      {
        if (this.swigCMemOwn)
        {
          this.swigCMemOwn = false;
          IConversationHistoryListViewModelSWIGJNI.delete_IConversationHistoryListViewModel(this.swigCPtr);
        }
        this.swigCPtr = 0L;
      }
      return;
    }
    finally {}
  }
  
  protected void finalize()
  {
    delete();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationHistoryListViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */