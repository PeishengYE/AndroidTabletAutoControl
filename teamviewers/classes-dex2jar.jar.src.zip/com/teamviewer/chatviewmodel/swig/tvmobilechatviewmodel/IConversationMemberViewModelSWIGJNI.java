package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IConversationMemberViewModelSWIGJNI
{
  public static final native String IConversationMemberViewModel_GetAccountPictureUrl(long paramLong, IConversationMemberViewModel paramIConversationMemberViewModel);
  
  public static final native int IConversationMemberViewModel_GetEndpointState(long paramLong, IConversationMemberViewModel paramIConversationMemberViewModel);
  
  public static final native int IConversationMemberViewModel_GetEndpointType(long paramLong, IConversationMemberViewModel paramIConversationMemberViewModel);
  
  public static final native String IConversationMemberViewModel_GetName(long paramLong, IConversationMemberViewModel paramIConversationMemberViewModel);
  
  public static final native void delete_IConversationMemberViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IConversationMemberViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */