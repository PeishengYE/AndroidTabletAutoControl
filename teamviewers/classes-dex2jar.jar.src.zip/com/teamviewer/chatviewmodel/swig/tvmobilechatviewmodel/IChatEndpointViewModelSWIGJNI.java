package com.teamviewer.chatviewmodel.swig.tvmobilechatviewmodel;

public class IChatEndpointViewModelSWIGJNI
{
  public static final native String IChatEndpointViewModel_GetAccountPictureUrl(long paramLong, IChatEndpointViewModel paramIChatEndpointViewModel);
  
  public static final native String IChatEndpointViewModel_GetDisplayName(long paramLong, IChatEndpointViewModel paramIChatEndpointViewModel);
  
  public static final native int IChatEndpointViewModel_GetState(long paramLong, IChatEndpointViewModel paramIChatEndpointViewModel);
  
  public static final native int IChatEndpointViewModel_GetType(long paramLong, IChatEndpointViewModel paramIChatEndpointViewModel);
  
  public static final native void delete_IChatEndpointViewModel(long paramLong);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/com/teamviewer/chatviewmodel/swig/tvmobilechatviewmodel/IChatEndpointViewModelSWIGJNI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */