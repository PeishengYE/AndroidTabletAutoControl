package android.support.design.widget;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import o.aa;
import o.b;
import o.bd;
import o.be;
import o.bf;
import o.bg;
import o.bi;
import o.bj;
import o.bk;
import o.bl;
import o.bm;
import o.bn;
import o.bq;
import o.bs;
import o.j;
import o.pe;
import o.qr;

public final class Snackbar
{
  private static final Handler a = new Handler(Looper.getMainLooper(), new bd());
  private final ViewGroup b;
  private final Snackbar.SnackbarLayout c;
  private bn d;
  private final AccessibilityManager e;
  private final bs f;
  
  private void b(int paramInt)
  {
    bq.a().a(this.f, paramInt);
  }
  
  private void c(int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      pe.r(this.c).c(this.c.getHeight()).a(j.b).a(250L).a(new bl(this, paramInt)).b();
      return;
    }
    Animation localAnimation = AnimationUtils.loadAnimation(this.c.getContext(), b.design_snackbar_out);
    localAnimation.setInterpolator(j.b);
    localAnimation.setDuration(250L);
    localAnimation.setAnimationListener(new be(this, paramInt));
    this.c.startAnimation(localAnimation);
  }
  
  private void d()
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      pe.b(this.c, this.c.getHeight());
      pe.r(this.c).c(0.0F).a(j.b).a(250L).a(new bj(this)).b();
      return;
    }
    Animation localAnimation = AnimationUtils.loadAnimation(this.c.getContext(), b.design_snackbar_in);
    localAnimation.setInterpolator(j.b);
    localAnimation.setDuration(250L);
    localAnimation.setAnimationListener(new bk(this));
    this.c.startAnimation(localAnimation);
  }
  
  private void d(int paramInt)
  {
    bq.a().a(this.f);
    if (this.d != null) {
      this.d.a(this, paramInt);
    }
    ViewParent localViewParent = this.c.getParent();
    if ((localViewParent instanceof ViewGroup)) {
      ((ViewGroup)localViewParent).removeView(this.c);
    }
  }
  
  private void e()
  {
    bq.a().b(this.f);
    if (this.d != null) {
      this.d.a(this);
    }
  }
  
  private boolean f()
  {
    return !this.e.isEnabled();
  }
  
  public final void a(int paramInt)
  {
    if ((f()) && (this.c.getVisibility() == 0))
    {
      c(paramInt);
      return;
    }
    d(paramInt);
  }
  
  public boolean a()
  {
    return bq.a().e(this.f);
  }
  
  public final void b()
  {
    if (this.c.getParent() == null)
    {
      ViewGroup.LayoutParams localLayoutParams = this.c.getLayoutParams();
      if ((localLayoutParams instanceof aa))
      {
        bm localbm = new bm(this);
        localbm.a(0.1F);
        localbm.b(0.6F);
        localbm.a(0);
        localbm.a(new bf(this));
        ((aa)localLayoutParams).a(localbm);
      }
      this.b.addView(this.c);
    }
    this.c.setOnAttachStateChangeListener(new bg(this));
    if (pe.B(this.c))
    {
      if (f())
      {
        d();
        return;
      }
      e();
      return;
    }
    this.c.setOnLayoutChangeListener(new bi(this));
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/design/widget/Snackbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */