package android.support.design.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import o.bo;
import o.bp;
import o.d;
import o.e;
import o.f;
import o.h;
import o.pe;
import o.qr;

public class Snackbar$SnackbarLayout
  extends LinearLayout
{
  private TextView a;
  private Button b;
  private int c;
  private int d;
  private bp e;
  private bo f;
  
  public Snackbar$SnackbarLayout(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public Snackbar$SnackbarLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, h.SnackbarLayout);
    this.c = paramAttributeSet.getDimensionPixelSize(h.SnackbarLayout_android_maxWidth, -1);
    this.d = paramAttributeSet.getDimensionPixelSize(h.SnackbarLayout_maxActionInlineWidth, -1);
    if (paramAttributeSet.hasValue(h.SnackbarLayout_elevation)) {
      pe.d(this, paramAttributeSet.getDimensionPixelSize(h.SnackbarLayout_elevation, 0));
    }
    paramAttributeSet.recycle();
    setClickable(true);
    LayoutInflater.from(paramContext).inflate(f.design_layout_snackbar_include, this);
    pe.d(this, 1);
    pe.c(this, 1);
  }
  
  private static void a(View paramView, int paramInt1, int paramInt2)
  {
    if (pe.x(paramView))
    {
      pe.a(paramView, pe.l(paramView), paramInt1, pe.m(paramView), paramInt2);
      return;
    }
    paramView.setPadding(paramView.getPaddingLeft(), paramInt1, paramView.getPaddingRight(), paramInt2);
  }
  
  private boolean a(int paramInt1, int paramInt2, int paramInt3)
  {
    boolean bool = false;
    if (paramInt1 != getOrientation())
    {
      setOrientation(paramInt1);
      bool = true;
    }
    if ((this.a.getPaddingTop() != paramInt2) || (this.a.getPaddingBottom() != paramInt3))
    {
      a(this.a, paramInt2, paramInt3);
      bool = true;
    }
    return bool;
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    pe.c(this.a, 0.0F);
    pe.r(this.a).a(1.0F).a(paramInt2).b(paramInt1).b();
    if (this.b.getVisibility() == 0)
    {
      pe.c(this.b, 0.0F);
      pe.r(this.b).a(1.0F).a(paramInt2).b(paramInt1).b();
    }
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    pe.c(this.a, 1.0F);
    pe.r(this.a).a(0.0F).a(paramInt2).b(paramInt1).b();
    if (this.b.getVisibility() == 0)
    {
      pe.c(this.b, 1.0F);
      pe.r(this.b).a(0.0F).a(paramInt2).b(paramInt1).b();
    }
  }
  
  Button getActionView()
  {
    return this.b;
  }
  
  TextView getMessageView()
  {
    return this.a;
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if (this.f != null) {
      this.f.a(this);
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.f != null) {
      this.f.b(this);
    }
  }
  
  protected void onFinishInflate()
  {
    super.onFinishInflate();
    this.a = ((TextView)findViewById(e.snackbar_text));
    this.b = ((Button)findViewById(e.snackbar_action));
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.e != null) {
      this.e.a(this, paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    int i = paramInt1;
    if (this.c > 0)
    {
      i = paramInt1;
      if (getMeasuredWidth() > this.c)
      {
        i = View.MeasureSpec.makeMeasureSpec(this.c, 1073741824);
        super.onMeasure(i, paramInt2);
      }
    }
    int j = getResources().getDimensionPixelSize(d.design_snackbar_padding_vertical_2lines);
    int k = getResources().getDimensionPixelSize(d.design_snackbar_padding_vertical);
    if (this.a.getLayout().getLineCount() > 1)
    {
      paramInt1 = 1;
      if ((paramInt1 == 0) || (this.d <= 0) || (this.b.getMeasuredWidth() <= this.d)) {
        break label142;
      }
      if (!a(1, j, j - k)) {
        break label170;
      }
      paramInt1 = 1;
    }
    for (;;)
    {
      if (paramInt1 != 0) {
        super.onMeasure(i, paramInt2);
      }
      return;
      paramInt1 = 0;
      break;
      label142:
      if (paramInt1 != 0) {}
      for (paramInt1 = j;; paramInt1 = k)
      {
        if (!a(0, paramInt1, paramInt1)) {
          break label170;
        }
        paramInt1 = 1;
        break;
      }
      label170:
      paramInt1 = 0;
    }
  }
  
  void setOnAttachStateChangeListener(bo parambo)
  {
    this.f = parambo;
  }
  
  public void setOnLayoutChangeListener(bp parambp)
  {
    this.e = parambp;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/design/widget/Snackbar$SnackbarLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */