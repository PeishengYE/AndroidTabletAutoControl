package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.View.MeasureSpec;
import o.ag;
import o.ai;
import o.aj;
import o.ak;
import o.aq;
import o.at;
import o.av;
import o.aw;
import o.cz;
import o.d;
import o.y;
import o.zd;

@y(a=FloatingActionButton.Behavior.class)
public class FloatingActionButton
  extends cz
{
  private ColorStateList a;
  private PorterDuff.Mode b;
  private int c;
  private int d;
  private int e;
  private boolean f;
  private final Rect g;
  private zd h;
  private at i;
  
  private static int a(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    switch (j)
    {
    case 0: 
    default: 
      return paramInt1;
    case -2147483648: 
      return Math.min(paramInt1, paramInt2);
    }
    return paramInt2;
  }
  
  private at a()
  {
    int j = Build.VERSION.SDK_INT;
    if (j >= 21) {
      return new aw(this, new aj(this, null));
    }
    if (j >= 14) {
      return new aq(this, new aj(this, null));
    }
    return new ak(this, new aj(this, null));
  }
  
  private av a(ai paramai)
  {
    if (paramai == null) {
      return null;
    }
    return new ag(this, paramai);
  }
  
  private void a(ai paramai, boolean paramBoolean)
  {
    getImpl().b(a(paramai), paramBoolean);
  }
  
  private void b(ai paramai, boolean paramBoolean)
  {
    getImpl().a(a(paramai), paramBoolean);
  }
  
  private at getImpl()
  {
    if (this.i == null) {
      this.i = a();
    }
    return this.i;
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    getImpl().a(getDrawableState());
  }
  
  public ColorStateList getBackgroundTintList()
  {
    return this.a;
  }
  
  public PorterDuff.Mode getBackgroundTintMode()
  {
    return this.b;
  }
  
  public float getCompatElevation()
  {
    return getImpl().a();
  }
  
  public Drawable getContentBackground()
  {
    return getImpl().f();
  }
  
  public final int getSizeDimension()
  {
    switch (this.d)
    {
    default: 
      return getResources().getDimensionPixelSize(d.design_fab_size_normal);
    }
    return getResources().getDimensionPixelSize(d.design_fab_size_mini);
  }
  
  public boolean getUseCompatPadding()
  {
    return this.f;
  }
  
  @TargetApi(11)
  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    getImpl().b();
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    getImpl().h();
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    getImpl().i();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int j = getSizeDimension();
    paramInt1 = Math.min(a(j, paramInt1), a(j, paramInt2));
    setMeasuredDimension(this.g.left + paramInt1 + this.g.right, paramInt1 + this.g.top + this.g.bottom);
  }
  
  public void setBackgroundColor(int paramInt)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundResource(int paramInt)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList)
  {
    if (this.a != paramColorStateList)
    {
      this.a = paramColorStateList;
      getImpl().a(paramColorStateList);
    }
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    if (this.b != paramMode)
    {
      this.b = paramMode;
      getImpl().a(paramMode);
    }
  }
  
  public void setCompatElevation(float paramFloat)
  {
    getImpl().b(paramFloat);
  }
  
  public void setImageResource(int paramInt)
  {
    this.h.a(paramInt);
  }
  
  public void setRippleColor(int paramInt)
  {
    if (this.c != paramInt)
    {
      this.c = paramInt;
      getImpl().a(paramInt);
    }
  }
  
  public void setUseCompatPadding(boolean paramBoolean)
  {
    if (this.f != paramBoolean)
    {
      this.f = paramBoolean;
      getImpl().c();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/design/widget/FloatingActionButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */