package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import o.eu;
import o.ey;
import o.fa;
import o.ff;
import o.fr;

public final class BackStackState
  implements Parcelable
{
  public static final Parcelable.Creator<BackStackState> CREATOR = new fa();
  final int[] a;
  final int b;
  final int c;
  final String d;
  final int e;
  final int f;
  final CharSequence g;
  final int h;
  final CharSequence i;
  final ArrayList<String> j;
  final ArrayList<String> k;
  
  public BackStackState(Parcel paramParcel)
  {
    this.a = paramParcel.createIntArray();
    this.b = paramParcel.readInt();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readString();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readInt();
    this.g = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.h = paramParcel.readInt();
    this.i = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.j = paramParcel.createStringArrayList();
    this.k = paramParcel.createStringArrayList();
  }
  
  public BackStackState(eu parameu)
  {
    ey localey = parameu.c;
    int n;
    for (int m = 0; localey != null; m = n)
    {
      n = m;
      if (localey.i != null) {
        n = m + localey.i.size();
      }
      localey = localey.a;
    }
    this.a = new int[m + parameu.e * 7];
    if (!parameu.l) {
      throw new IllegalStateException("Not on back stack");
    }
    localey = parameu.c;
    m = 0;
    if (localey != null)
    {
      int[] arrayOfInt = this.a;
      n = m + 1;
      arrayOfInt[m] = localey.c;
      arrayOfInt = this.a;
      int i1 = n + 1;
      if (localey.d != null) {}
      for (m = localey.d.p;; m = -1)
      {
        arrayOfInt[n] = m;
        arrayOfInt = this.a;
        m = i1 + 1;
        arrayOfInt[i1] = localey.e;
        arrayOfInt = this.a;
        n = m + 1;
        arrayOfInt[m] = localey.f;
        arrayOfInt = this.a;
        m = n + 1;
        arrayOfInt[n] = localey.g;
        arrayOfInt = this.a;
        n = m + 1;
        arrayOfInt[m] = localey.h;
        if (localey.i == null) {
          break label314;
        }
        i1 = localey.i.size();
        arrayOfInt = this.a;
        m = n + 1;
        arrayOfInt[n] = i1;
        n = 0;
        while (n < i1)
        {
          this.a[m] = ((ff)localey.i.get(n)).p;
          n += 1;
          m += 1;
        }
      }
      for (;;)
      {
        localey = localey.a;
        break;
        label314:
        arrayOfInt = this.a;
        m = n + 1;
        arrayOfInt[n] = 0;
      }
    }
    this.b = parameu.j;
    this.c = parameu.k;
    this.d = parameu.n;
    this.e = parameu.p;
    this.f = parameu.q;
    this.g = parameu.r;
    this.h = parameu.s;
    this.i = parameu.t;
    this.j = parameu.u;
    this.k = parameu.v;
  }
  
  public eu a(fr paramfr)
  {
    eu localeu = new eu(paramfr);
    int i1 = 0;
    int m = 0;
    while (m < this.a.length)
    {
      ey localey = new ey();
      Object localObject = this.a;
      int n = m + 1;
      localey.c = localObject[m];
      if (fr.a) {
        Log.v("FragmentManager", "Instantiate " + localeu + " op #" + i1 + " base fragment #" + this.a[n]);
      }
      localObject = this.a;
      m = n + 1;
      n = localObject[n];
      if (n >= 0) {}
      for (localey.d = ((ff)paramfr.f.get(n));; localey.d = null)
      {
        localObject = this.a;
        n = m + 1;
        localey.e = localObject[m];
        localObject = this.a;
        m = n + 1;
        localey.f = localObject[n];
        localObject = this.a;
        n = m + 1;
        localey.g = localObject[m];
        localObject = this.a;
        m = n + 1;
        localey.h = localObject[n];
        localObject = this.a;
        n = m + 1;
        int i3 = localObject[m];
        m = n;
        if (i3 <= 0) {
          break;
        }
        localey.i = new ArrayList(i3);
        int i2 = 0;
        for (;;)
        {
          m = n;
          if (i2 >= i3) {
            break;
          }
          if (fr.a) {
            Log.v("FragmentManager", "Instantiate " + localeu + " set remove fragment #" + this.a[n]);
          }
          localObject = (ff)paramfr.f.get(this.a[n]);
          localey.i.add(localObject);
          i2 += 1;
          n += 1;
        }
      }
      localeu.f = localey.e;
      localeu.g = localey.f;
      localeu.h = localey.g;
      localeu.i = localey.h;
      localeu.a(localey);
      i1 += 1;
    }
    localeu.j = this.b;
    localeu.k = this.c;
    localeu.n = this.d;
    localeu.p = this.e;
    localeu.l = true;
    localeu.q = this.f;
    localeu.r = this.g;
    localeu.s = this.h;
    localeu.t = this.i;
    localeu.u = this.j;
    localeu.v = this.k;
    localeu.b(1);
    return localeu;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeString(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
    TextUtils.writeToParcel(this.g, paramParcel, 0);
    paramParcel.writeInt(this.h);
    TextUtils.writeToParcel(this.i, paramParcel, 0);
    paramParcel.writeStringList(this.j);
    paramParcel.writeStringList(this.k);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/v4/app/BackStackState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */