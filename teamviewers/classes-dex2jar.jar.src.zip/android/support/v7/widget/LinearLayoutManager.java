package android.support.v7.widget;

import android.content.Context;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;
import o.aar;
import o.aas;
import o.aat;
import o.abm;
import o.acf;
import o.acg;
import o.ach;
import o.acm;
import o.acs;
import o.acv;
import o.ada;
import o.rk;
import o.st;

public class LinearLayoutManager
  extends acf
{
  private aat a;
  private boolean b;
  private boolean c = false;
  private boolean d = false;
  private boolean e = true;
  private boolean f;
  int i;
  public abm j;
  boolean k = false;
  int l = -1;
  int m = Integer.MIN_VALUE;
  LinearLayoutManager.SavedState n = null;
  final aar o = new aar(this);
  
  public LinearLayoutManager(Context paramContext)
  {
    this(paramContext, 1, false);
  }
  
  public LinearLayoutManager(Context paramContext, int paramInt, boolean paramBoolean)
  {
    b(paramInt);
    b(paramBoolean);
    c(true);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    paramContext = a(paramContext, paramAttributeSet, paramInt1, paramInt2);
    b(paramContext.a);
    b(paramContext.c);
    a(paramContext.d);
    c(true);
  }
  
  private void K()
  {
    boolean bool = true;
    if ((this.i == 1) || (!h()))
    {
      this.k = this.c;
      return;
    }
    if (!this.c) {}
    for (;;)
    {
      this.k = bool;
      return;
      bool = false;
    }
  }
  
  private View L()
  {
    if (this.k) {}
    for (int i1 = v() - 1;; i1 = 0) {
      return h(i1);
    }
  }
  
  private View M()
  {
    if (this.k) {}
    for (int i1 = 0;; i1 = v() - 1) {
      return h(i1);
    }
  }
  
  private int a(int paramInt, acm paramacm, acs paramacs, boolean paramBoolean)
  {
    int i1 = this.j.d() - paramInt;
    if (i1 > 0)
    {
      int i2 = -c(-i1, paramacm, paramacs);
      i1 = i2;
      if (paramBoolean)
      {
        paramInt = this.j.d() - (paramInt + i2);
        i1 = i2;
        if (paramInt > 0)
        {
          this.j.a(paramInt);
          i1 = i2 + paramInt;
        }
      }
      return i1;
    }
    return 0;
  }
  
  private View a(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.k) {
      return a(v() - 1, -1, paramBoolean1, paramBoolean2);
    }
    return a(0, v(), paramBoolean1, paramBoolean2);
  }
  
  private void a(int paramInt1, int paramInt2, boolean paramBoolean, acs paramacs)
  {
    int i1 = -1;
    int i2 = 1;
    this.a.l = k();
    this.a.h = a(paramacs);
    this.a.f = paramInt1;
    if (paramInt1 == 1)
    {
      paramacs = this.a;
      paramacs.h += this.j.g();
      paramacs = M();
      localaat = this.a;
      if (this.k) {}
      for (paramInt1 = i1;; paramInt1 = 1)
      {
        localaat.e = paramInt1;
        this.a.d = (d(paramacs) + this.a.e);
        this.a.b = this.j.b(paramacs);
        paramInt1 = this.j.b(paramacs) - this.j.d();
        this.a.c = paramInt2;
        if (paramBoolean)
        {
          paramacs = this.a;
          paramacs.c -= paramInt1;
        }
        this.a.g = paramInt1;
        return;
      }
    }
    paramacs = L();
    aat localaat = this.a;
    localaat.h += this.j.c();
    localaat = this.a;
    if (this.k) {}
    for (paramInt1 = i2;; paramInt1 = -1)
    {
      localaat.e = paramInt1;
      this.a.d = (d(paramacs) + this.a.e);
      this.a.b = this.j.a(paramacs);
      paramInt1 = -this.j.a(paramacs) + this.j.c();
      break;
    }
  }
  
  private void a(aar paramaar)
  {
    f(paramaar.a, paramaar.b);
  }
  
  private void a(acm paramacm, int paramInt)
  {
    if (paramInt < 0) {}
    for (;;)
    {
      return;
      int i2 = v();
      int i1;
      View localView;
      if (this.k)
      {
        i1 = i2 - 1;
        while (i1 >= 0)
        {
          localView = h(i1);
          if (this.j.b(localView) > paramInt)
          {
            a(paramacm, i2 - 1, i1);
            return;
          }
          i1 -= 1;
        }
      }
      else
      {
        i1 = 0;
        while (i1 < i2)
        {
          localView = h(i1);
          if (this.j.b(localView) > paramInt)
          {
            a(paramacm, 0, i1);
            return;
          }
          i1 += 1;
        }
      }
    }
  }
  
  private void a(acm paramacm, int paramInt1, int paramInt2)
  {
    if (paramInt1 == paramInt2) {}
    for (;;)
    {
      return;
      int i1 = paramInt1;
      if (paramInt2 > paramInt1)
      {
        paramInt2 -= 1;
        while (paramInt2 >= paramInt1)
        {
          a(paramInt2, paramacm);
          paramInt2 -= 1;
        }
      }
      else
      {
        while (i1 > paramInt2)
        {
          a(i1, paramacm);
          i1 -= 1;
        }
      }
    }
  }
  
  private void a(acm paramacm, aat paramaat)
  {
    if ((!paramaat.a) || (paramaat.l)) {
      return;
    }
    if (paramaat.f == -1)
    {
      b(paramacm, paramaat.g);
      return;
    }
    a(paramacm, paramaat.g);
  }
  
  private void a(acm paramacm, acs paramacs, aar paramaar)
  {
    if (a(paramacs, paramaar)) {}
    while (b(paramacm, paramacs, paramaar)) {
      return;
    }
    paramaar.b();
    if (this.d) {}
    for (int i1 = paramacs.e() - 1;; i1 = 0)
    {
      paramaar.a = i1;
      return;
    }
  }
  
  private boolean a(acs paramacs, aar paramaar)
  {
    boolean bool = false;
    if ((paramacs.a()) || (this.l == -1)) {
      return false;
    }
    if ((this.l < 0) || (this.l >= paramacs.e()))
    {
      this.l = -1;
      this.m = Integer.MIN_VALUE;
      return false;
    }
    paramaar.a = this.l;
    if ((this.n != null) && (this.n.a()))
    {
      paramaar.c = this.n.c;
      if (paramaar.c)
      {
        paramaar.b = (this.j.d() - this.n.b);
        return true;
      }
      paramaar.b = (this.j.c() + this.n.b);
      return true;
    }
    if (this.m == Integer.MIN_VALUE)
    {
      paramacs = c(this.l);
      int i1;
      if (paramacs != null)
      {
        if (this.j.c(paramacs) > this.j.f())
        {
          paramaar.b();
          return true;
        }
        if (this.j.a(paramacs) - this.j.c() < 0)
        {
          paramaar.b = this.j.c();
          paramaar.c = false;
          return true;
        }
        if (this.j.d() - this.j.b(paramacs) < 0)
        {
          paramaar.b = this.j.d();
          paramaar.c = true;
          return true;
        }
        if (paramaar.c) {}
        for (i1 = this.j.b(paramacs) + this.j.b();; i1 = this.j.a(paramacs))
        {
          paramaar.b = i1;
          return true;
        }
      }
      if (v() > 0)
      {
        i1 = d(h(0));
        if (this.l >= i1) {
          break label351;
        }
      }
      label351:
      for (int i2 = 1;; i2 = 0)
      {
        if (i2 == this.k) {
          bool = true;
        }
        paramaar.c = bool;
        paramaar.b();
        return true;
      }
    }
    paramaar.c = this.k;
    if (this.k)
    {
      paramaar.b = (this.j.d() - this.m);
      return true;
    }
    paramaar.b = (this.j.c() + this.m);
    return true;
  }
  
  private int b(int paramInt, acm paramacm, acs paramacs, boolean paramBoolean)
  {
    int i1 = paramInt - this.j.c();
    if (i1 > 0)
    {
      int i2 = -c(i1, paramacm, paramacs);
      i1 = i2;
      if (paramBoolean)
      {
        paramInt = paramInt + i2 - this.j.c();
        i1 = i2;
        if (paramInt > 0)
        {
          this.j.a(-paramInt);
          i1 = i2 - paramInt;
        }
      }
      return i1;
    }
    return 0;
  }
  
  private View b(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.k) {
      return a(0, v(), paramBoolean1, paramBoolean2);
    }
    return a(v() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  private void b(aar paramaar)
  {
    g(paramaar.a, paramaar.b);
  }
  
  private void b(acm paramacm, int paramInt)
  {
    int i1 = v();
    if (paramInt < 0) {}
    for (;;)
    {
      return;
      int i2 = this.j.e() - paramInt;
      View localView;
      if (this.k)
      {
        paramInt = 0;
        while (paramInt < i1)
        {
          localView = h(paramInt);
          if (this.j.a(localView) < i2)
          {
            a(paramacm, 0, paramInt);
            return;
          }
          paramInt += 1;
        }
      }
      else
      {
        paramInt = i1 - 1;
        while (paramInt >= 0)
        {
          localView = h(paramInt);
          if (this.j.a(localView) < i2)
          {
            a(paramacm, i1 - 1, paramInt);
            return;
          }
          paramInt -= 1;
        }
      }
    }
  }
  
  private void b(acm paramacm, acs paramacs, int paramInt1, int paramInt2)
  {
    if ((!paramacs.b()) || (v() == 0) || (paramacs.a()) || (!b())) {
      return;
    }
    int i1 = 0;
    int i2 = 0;
    List localList = paramacm.b();
    int i5 = localList.size();
    int i6 = d(h(0));
    int i3 = 0;
    if (i3 < i5)
    {
      acv localacv = (acv)localList.get(i3);
      int i4;
      if (localacv.q())
      {
        i4 = i2;
        i2 = i1;
        i1 = i4;
      }
      for (;;)
      {
        i4 = i3 + 1;
        i3 = i2;
        i2 = i1;
        i1 = i3;
        i3 = i4;
        break;
        int i7;
        if (localacv.d() < i6)
        {
          i7 = 1;
          label143:
          if (i7 == this.k) {
            break label195;
          }
        }
        label195:
        for (i4 = -1;; i4 = 1)
        {
          if (i4 != -1) {
            break label201;
          }
          i4 = this.j.c(localacv.a) + i1;
          i1 = i2;
          i2 = i4;
          break;
          i7 = 0;
          break label143;
        }
        label201:
        i4 = this.j.c(localacv.a) + i2;
        i2 = i1;
        i1 = i4;
      }
    }
    this.a.k = localList;
    if (i1 > 0)
    {
      g(d(L()), paramInt1);
      this.a.h = i1;
      this.a.c = 0;
      this.a.a();
      a(paramacm, this.a, paramacs, false);
    }
    if (i2 > 0)
    {
      f(d(M()), paramInt2);
      this.a.h = i2;
      this.a.c = 0;
      this.a.a();
      a(paramacm, this.a, paramacs, false);
    }
    this.a.k = null;
  }
  
  private boolean b(acm paramacm, acs paramacs, aar paramaar)
  {
    int i1 = 0;
    if (v() == 0) {}
    do
    {
      return false;
      View localView = E();
      if ((localView != null) && (aar.a(paramaar, localView, paramacs)))
      {
        paramaar.a(localView);
        return true;
      }
    } while (this.b != this.d);
    if (paramaar.c)
    {
      paramacm = f(paramacm, paramacs);
      label66:
      if (paramacm == null) {
        break label165;
      }
      paramaar.b(paramacm);
      if ((!paramacs.a()) && (b()))
      {
        if ((this.j.a(paramacm) >= this.j.d()) || (this.j.b(paramacm) < this.j.c())) {
          i1 = 1;
        }
        if (i1 != 0) {
          if (!paramaar.c) {
            break label167;
          }
        }
      }
    }
    label165:
    label167:
    for (i1 = this.j.d();; i1 = this.j.c())
    {
      paramaar.b = i1;
      return true;
      paramacm = g(paramacm, paramacs);
      break label66;
      break;
    }
  }
  
  private View f(acm paramacm, acs paramacs)
  {
    if (this.k) {
      return h(paramacm, paramacs);
    }
    return i(paramacm, paramacs);
  }
  
  private void f(int paramInt1, int paramInt2)
  {
    this.a.c = (this.j.d() - paramInt2);
    aat localaat = this.a;
    if (this.k) {}
    for (int i1 = -1;; i1 = 1)
    {
      localaat.e = i1;
      this.a.d = paramInt1;
      this.a.f = 1;
      this.a.b = paramInt2;
      this.a.g = Integer.MIN_VALUE;
      return;
    }
  }
  
  private View g(acm paramacm, acs paramacs)
  {
    if (this.k) {
      return i(paramacm, paramacs);
    }
    return h(paramacm, paramacs);
  }
  
  private void g(int paramInt1, int paramInt2)
  {
    this.a.c = (paramInt2 - this.j.c());
    this.a.d = paramInt1;
    aat localaat = this.a;
    if (this.k) {}
    for (paramInt1 = 1;; paramInt1 = -1)
    {
      localaat.e = paramInt1;
      this.a.f = -1;
      this.a.b = paramInt2;
      this.a.g = Integer.MIN_VALUE;
      return;
    }
  }
  
  private int h(acs paramacs)
  {
    boolean bool2 = false;
    if (v() == 0) {
      return 0;
    }
    i();
    abm localabm = this.j;
    if (!this.e) {}
    for (boolean bool1 = true;; bool1 = false)
    {
      View localView = a(bool1, true);
      bool1 = bool2;
      if (!this.e) {
        bool1 = true;
      }
      return ada.a(paramacs, localabm, localView, b(bool1, true), this, this.e, this.k);
    }
  }
  
  private View h(acm paramacm, acs paramacs)
  {
    return a(paramacm, paramacs, 0, v(), paramacs.e());
  }
  
  private int i(acs paramacs)
  {
    boolean bool2 = false;
    if (v() == 0) {
      return 0;
    }
    i();
    abm localabm = this.j;
    if (!this.e) {}
    for (boolean bool1 = true;; bool1 = false)
    {
      View localView = a(bool1, true);
      bool1 = bool2;
      if (!this.e) {
        bool1 = true;
      }
      return ada.a(paramacs, localabm, localView, b(bool1, true), this, this.e);
    }
  }
  
  private View i(acm paramacm, acs paramacs)
  {
    return a(paramacm, paramacs, v() - 1, -1, paramacs.e());
  }
  
  private int j(acs paramacs)
  {
    boolean bool2 = false;
    if (v() == 0) {
      return 0;
    }
    i();
    abm localabm = this.j;
    if (!this.e) {}
    for (boolean bool1 = true;; bool1 = false)
    {
      View localView = a(bool1, true);
      bool1 = bool2;
      if (!this.e) {
        bool1 = true;
      }
      return ada.b(paramacs, localabm, localView, b(bool1, true), this, this.e);
    }
  }
  
  public int a(int paramInt, acm paramacm, acs paramacs)
  {
    if (this.i == 1) {
      return 0;
    }
    return c(paramInt, paramacm, paramacs);
  }
  
  int a(acm paramacm, aat paramaat, acs paramacs, boolean paramBoolean)
  {
    int i3 = paramaat.c;
    if (paramaat.g != Integer.MIN_VALUE)
    {
      if (paramaat.c < 0) {
        paramaat.g += paramaat.c;
      }
      a(paramacm, paramaat);
    }
    int i1 = paramaat.c + paramaat.h;
    aas localaas = new aas();
    if (((paramaat.l) || (i1 > 0)) && (paramaat.a(paramacs)))
    {
      localaas.a();
      a(paramacm, paramacs, paramaat, localaas);
      if (!localaas.b) {
        break label111;
      }
    }
    for (;;)
    {
      return i3 - paramaat.c;
      label111:
      paramaat.b += localaas.a * paramaat.f;
      int i2;
      if ((localaas.c) && (this.a.k == null))
      {
        i2 = i1;
        if (paramacs.a()) {}
      }
      else
      {
        paramaat.c -= localaas.a;
        i2 = i1 - localaas.a;
      }
      if (paramaat.g != Integer.MIN_VALUE)
      {
        paramaat.g += localaas.a;
        if (paramaat.c < 0) {
          paramaat.g += paramaat.c;
        }
        a(paramacm, paramaat);
      }
      i1 = i2;
      if (!paramBoolean) {
        break;
      }
      i1 = i2;
      if (!localaas.d) {
        break;
      }
    }
  }
  
  protected int a(acs paramacs)
  {
    if (paramacs.d()) {
      return this.j.f();
    }
    return 0;
  }
  
  View a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    i();
    int i2 = this.j.c();
    int i3 = this.j.d();
    if (paramInt2 > paramInt1) {}
    Object localObject;
    View localView;
    for (int i1 = 1;; i1 = -1)
    {
      localObject = null;
      if (paramInt1 == paramInt2) {
        break label130;
      }
      localView = h(paramInt1);
      int i4 = this.j.a(localView);
      int i5 = this.j.b(localView);
      if ((i4 >= i3) || (i5 <= i2)) {
        break label133;
      }
      if ((paramBoolean1) && ((i4 < i2) || (i5 > i3))) {
        break;
      }
      return localView;
    }
    if ((paramBoolean2) && (localObject == null)) {
      localObject = localView;
    }
    label130:
    label133:
    for (;;)
    {
      paramInt1 += i1;
      break;
      return (View)localObject;
    }
  }
  
  public View a(View paramView, int paramInt, acm paramacm, acs paramacs)
  {
    K();
    if (v() == 0) {}
    label42:
    label134:
    label136:
    label142:
    for (;;)
    {
      return null;
      paramInt = e(paramInt);
      if (paramInt != Integer.MIN_VALUE)
      {
        i();
        if (paramInt == -1)
        {
          paramView = g(paramacm, paramacs);
          if (paramView == null) {
            break label134;
          }
          i();
          a(paramInt, (int)(0.33333334F * this.j.f()), false, paramacs);
          this.a.g = Integer.MIN_VALUE;
          this.a.a = false;
          a(paramacm, this.a, paramacs, true);
          if (paramInt != -1) {
            break label136;
          }
        }
        for (paramacm = L();; paramacm = M())
        {
          if ((paramacm == paramView) || (!paramacm.isFocusable())) {
            break label142;
          }
          return paramacm;
          paramView = f(paramacm, paramacs);
          break label42;
          break;
        }
      }
    }
  }
  
  View a(acm paramacm, acs paramacs, int paramInt1, int paramInt2, int paramInt3)
  {
    paramacs = null;
    i();
    int i2 = this.j.c();
    int i3 = this.j.d();
    int i1;
    label35:
    Object localObject1;
    if (paramInt2 > paramInt1)
    {
      i1 = 1;
      paramacm = null;
      if (paramInt1 == paramInt2) {
        break label157;
      }
      localObject1 = h(paramInt1);
      int i4 = d((View)localObject1);
      if ((i4 < 0) || (i4 >= paramInt3)) {
        break label172;
      }
      if (!((ach)((View)localObject1).getLayoutParams()).c()) {
        break label113;
      }
      if (paramacm != null) {
        break label172;
      }
      paramacm = paramacs;
      paramacs = (acs)localObject1;
    }
    for (;;)
    {
      paramInt1 += i1;
      localObject1 = paramacs;
      paramacs = paramacm;
      paramacm = (acm)localObject1;
      break label35;
      i1 = -1;
      break;
      label113:
      Object localObject2;
      if (this.j.a((View)localObject1) < i3)
      {
        localObject2 = localObject1;
        if (this.j.b((View)localObject1) >= i2) {}
      }
      else
      {
        if (paramacs != null) {
          break label172;
        }
        paramacs = paramacm;
        paramacm = (acm)localObject1;
        continue;
        label157:
        if (paramacs == null) {
          break label167;
        }
      }
      for (;;)
      {
        localObject2 = paramacs;
        return (View)localObject2;
        label167:
        paramacs = paramacm;
      }
      label172:
      localObject1 = paramacm;
      paramacm = paramacs;
      paramacs = (acs)localObject1;
    }
  }
  
  public ach a()
  {
    return new ach(-2, -2);
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    this.l = paramInt1;
    this.m = paramInt2;
    if (this.n != null) {
      this.n.b();
    }
    p();
  }
  
  public void a(Parcelable paramParcelable)
  {
    if ((paramParcelable instanceof LinearLayoutManager.SavedState))
    {
      this.n = ((LinearLayoutManager.SavedState)paramParcelable);
      p();
    }
  }
  
  public void a(RecyclerView paramRecyclerView, acm paramacm)
  {
    super.a(paramRecyclerView, paramacm);
    if (this.f)
    {
      c(paramacm);
      paramacm.a();
    }
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent)
  {
    super.a(paramAccessibilityEvent);
    if (v() > 0)
    {
      paramAccessibilityEvent = rk.a(paramAccessibilityEvent);
      paramAccessibilityEvent.b(m());
      paramAccessibilityEvent.c(o());
    }
  }
  
  public void a(String paramString)
  {
    if (this.n == null) {
      super.a(paramString);
    }
  }
  
  void a(acm paramacm, acs paramacs, aar paramaar, int paramInt) {}
  
  void a(acm paramacm, acs paramacs, aat paramaat, aas paramaas)
  {
    paramacm = paramaat.a(paramacm);
    if (paramacm == null)
    {
      paramaas.b = true;
      return;
    }
    paramacs = (ach)paramacm.getLayoutParams();
    boolean bool2;
    boolean bool1;
    label61:
    int i1;
    int i2;
    label120:
    int i3;
    int i4;
    if (paramaat.k == null)
    {
      bool2 = this.k;
      if (paramaat.f == -1)
      {
        bool1 = true;
        if (bool2 != bool1) {
          break label215;
        }
        b(paramacm);
        a(paramacm, 0, 0);
        paramaas.a = this.j.c(paramacm);
        if (this.i != 1) {
          break label322;
        }
        if (!h()) {
          break label271;
        }
        i1 = y() - C();
        i2 = i1 - this.j.d(paramacm);
        if (paramaat.f != -1) {
          break label293;
        }
        i3 = paramaat.b;
        i4 = paramaat.b - paramaas.a;
      }
    }
    for (;;)
    {
      a(paramacm, i2 + paramacs.leftMargin, i4 + paramacs.topMargin, i1 - paramacs.rightMargin, i3 - paramacs.bottomMargin);
      if ((paramacs.c()) || (paramacs.d())) {
        paramaas.c = true;
      }
      paramaas.d = paramacm.isFocusable();
      return;
      bool1 = false;
      break;
      label215:
      b(paramacm, 0);
      break label61;
      bool2 = this.k;
      if (paramaat.f == -1) {}
      for (bool1 = true;; bool1 = false)
      {
        if (bool2 != bool1) {
          break label262;
        }
        a(paramacm);
        break;
      }
      label262:
      a(paramacm, 0);
      break label61;
      label271:
      i2 = A();
      i1 = this.j.d(paramacm) + i2;
      break label120;
      label293:
      i4 = paramaat.b;
      i3 = paramaat.b;
      int i5 = paramaas.a;
      i3 += i5;
      continue;
      label322:
      i4 = B();
      i3 = this.j.d(paramacm) + i4;
      if (paramaat.f == -1)
      {
        i1 = paramaat.b;
        i2 = paramaat.b - paramaas.a;
      }
      else
      {
        i2 = paramaat.b;
        i1 = paramaat.b;
        i5 = paramaas.a;
        i1 += i5;
      }
    }
  }
  
  public void a(boolean paramBoolean)
  {
    a(null);
    if (this.d == paramBoolean) {
      return;
    }
    this.d = paramBoolean;
    p();
  }
  
  public int b(int paramInt, acm paramacm, acs paramacs)
  {
    if (this.i == 0) {
      return 0;
    }
    return c(paramInt, paramacm, paramacs);
  }
  
  public int b(acs paramacs)
  {
    return h(paramacs);
  }
  
  public void b(int paramInt)
  {
    if ((paramInt != 0) && (paramInt != 1)) {
      throw new IllegalArgumentException("invalid orientation:" + paramInt);
    }
    a(null);
    if (paramInt == this.i) {
      return;
    }
    this.i = paramInt;
    this.j = null;
    p();
  }
  
  public void b(boolean paramBoolean)
  {
    a(null);
    if (paramBoolean == this.c) {
      return;
    }
    this.c = paramBoolean;
    p();
  }
  
  public boolean b()
  {
    return (this.n == null) && (this.b == this.d);
  }
  
  int c(int paramInt, acm paramacm, acs paramacs)
  {
    if ((v() == 0) || (paramInt == 0)) {
      return 0;
    }
    this.a.a = true;
    i();
    if (paramInt > 0) {}
    int i2;
    int i3;
    for (int i1 = 1;; i1 = -1)
    {
      i2 = Math.abs(paramInt);
      a(i1, i2, true, paramacs);
      i3 = this.a.g + a(paramacm, this.a, paramacs, false);
      if (i3 >= 0) {
        break;
      }
      return 0;
    }
    if (i2 > i3) {
      paramInt = i1 * i3;
    }
    this.j.a(-paramInt);
    this.a.j = paramInt;
    return paramInt;
  }
  
  public int c(acs paramacs)
  {
    return h(paramacs);
  }
  
  public Parcelable c()
  {
    if (this.n != null) {
      return new LinearLayoutManager.SavedState(this.n);
    }
    LinearLayoutManager.SavedState localSavedState = new LinearLayoutManager.SavedState();
    if (v() > 0)
    {
      i();
      boolean bool = this.b ^ this.k;
      localSavedState.c = bool;
      if (bool)
      {
        localView = M();
        localSavedState.b = (this.j.d() - this.j.b(localView));
        localSavedState.a = d(localView);
        return localSavedState;
      }
      View localView = L();
      localSavedState.a = d(localView);
      localSavedState.b = (this.j.a(localView) - this.j.c());
      return localSavedState;
    }
    localSavedState.b();
    return localSavedState;
  }
  
  public View c(int paramInt)
  {
    int i1 = v();
    Object localObject;
    if (i1 == 0) {
      localObject = null;
    }
    View localView;
    do
    {
      return (View)localObject;
      int i2 = paramInt - d(h(0));
      if ((i2 < 0) || (i2 >= i1)) {
        break;
      }
      localView = h(i2);
      localObject = localView;
    } while (d(localView) == paramInt);
    return super.c(paramInt);
  }
  
  public void c(acm paramacm, acs paramacs)
  {
    if (((this.n != null) || (this.l != -1)) && (paramacs.e() == 0))
    {
      c(paramacm);
      return;
    }
    if ((this.n != null) && (this.n.a())) {
      this.l = this.n.a;
    }
    i();
    this.a.a = false;
    K();
    this.o.a();
    this.o.c = (this.k ^ this.d);
    a(paramacm, paramacs, this.o);
    int i1 = a(paramacs);
    int i2;
    int i4;
    int i5;
    int i3;
    Object localObject;
    if (this.a.j >= 0)
    {
      i2 = 0;
      i4 = i2 + this.j.c();
      i5 = i1 + this.j.g();
      i2 = i5;
      i3 = i4;
      if (paramacs.a())
      {
        i2 = i5;
        i3 = i4;
        if (this.l != -1)
        {
          i2 = i5;
          i3 = i4;
          if (this.m != Integer.MIN_VALUE)
          {
            localObject = c(this.l);
            i2 = i5;
            i3 = i4;
            if (localObject != null)
            {
              if (!this.k) {
                break label648;
              }
              i1 = this.j.d() - this.j.b((View)localObject) - this.m;
              label248:
              if (i1 <= 0) {
                break label680;
              }
              i3 = i4 + i1;
              i2 = i5;
            }
          }
        }
      }
      label262:
      if (!this.o.c) {
        break label698;
      }
      if (!this.k) {
        break label693;
      }
      i1 = 1;
      label281:
      a(paramacm, paramacs, this.o, i1);
      a(paramacm);
      this.a.l = k();
      this.a.i = paramacs.a();
      if (!this.o.c) {
        break label715;
      }
      b(this.o);
      this.a.h = i3;
      a(paramacm, this.a, paramacs, false);
      i4 = this.a.b;
      i5 = this.a.d;
      i1 = i2;
      if (this.a.c > 0) {
        i1 = i2 + this.a.c;
      }
      a(this.o);
      this.a.h = i1;
      localObject = this.a;
      ((aat)localObject).d += this.a.e;
      a(paramacm, this.a, paramacs, false);
      i3 = this.a.b;
      if (this.a.c <= 0) {
        break label960;
      }
      i1 = this.a.c;
      g(i5, i4);
      this.a.h = i1;
      a(paramacm, this.a, paramacs, false);
    }
    label521:
    label648:
    label680:
    label693:
    label698:
    label715:
    label915:
    label960:
    for (i1 = this.a.b;; i1 = i4)
    {
      i2 = i1;
      i1 = i3;
      i3 = i1;
      i4 = i2;
      if (v() > 0)
      {
        if (!(this.k ^ this.d)) {
          break label915;
        }
        i3 = a(i1, paramacm, paramacs, true);
        i4 = i2 + i3;
        i2 = b(i4, paramacm, paramacs, false);
        i4 += i2;
      }
      for (i3 = i1 + i3 + i2;; i3 = i1 + i5)
      {
        b(paramacm, paramacs, i4, i3);
        if (!paramacs.a())
        {
          this.l = -1;
          this.m = Integer.MIN_VALUE;
          this.j.a();
        }
        this.b = this.d;
        this.n = null;
        return;
        i2 = i1;
        i1 = 0;
        break;
        i1 = this.j.a((View)localObject);
        i2 = this.j.c();
        i1 = this.m - (i1 - i2);
        break label248;
        i2 = i5 - i1;
        i3 = i4;
        break label262;
        i1 = -1;
        break label281;
        if (this.k)
        {
          i1 = -1;
          break label281;
        }
        i1 = 1;
        break label281;
        a(this.o);
        this.a.h = i2;
        a(paramacm, this.a, paramacs, false);
        i4 = this.a.b;
        i5 = this.a.d;
        i1 = i3;
        if (this.a.c > 0) {
          i1 = i3 + this.a.c;
        }
        b(this.o);
        this.a.h = i1;
        localObject = this.a;
        ((aat)localObject).d += this.a.e;
        a(paramacm, this.a, paramacs, false);
        i3 = this.a.b;
        i1 = i4;
        i2 = i3;
        if (this.a.c <= 0) {
          break label521;
        }
        i1 = this.a.c;
        f(i5, i4);
        this.a.h = i1;
        a(paramacm, this.a, paramacs, false);
        i1 = this.a.b;
        i2 = i3;
        break label521;
        i3 = b(i2, paramacm, paramacs, true);
        i1 += i3;
        i5 = a(i1, paramacm, paramacs, false);
        i4 = i2 + i3 + i5;
      }
    }
  }
  
  public int d(acs paramacs)
  {
    return i(paramacs);
  }
  
  public void d(int paramInt)
  {
    this.l = paramInt;
    this.m = Integer.MIN_VALUE;
    if (this.n != null) {
      this.n.b();
    }
    p();
  }
  
  public boolean d()
  {
    return this.i == 0;
  }
  
  int e(int paramInt)
  {
    int i2 = -1;
    int i3 = 1;
    int i4 = Integer.MIN_VALUE;
    int i1 = i2;
    switch (paramInt)
    {
    default: 
      i1 = Integer.MIN_VALUE;
    case 1: 
    case 2: 
    case 33: 
    case 130: 
    case 17: 
      do
      {
        do
        {
          return i1;
          return 1;
          i1 = i2;
        } while (this.i == 1);
        return Integer.MIN_VALUE;
        paramInt = i4;
        if (this.i == 1) {
          paramInt = 1;
        }
        return paramInt;
        i1 = i2;
      } while (this.i == 0);
      return Integer.MIN_VALUE;
    }
    if (this.i == 0) {}
    for (paramInt = i3;; paramInt = Integer.MIN_VALUE) {
      return paramInt;
    }
  }
  
  public int e(acs paramacs)
  {
    return i(paramacs);
  }
  
  public boolean e()
  {
    return this.i == 1;
  }
  
  public int f(acs paramacs)
  {
    return j(paramacs);
  }
  
  public boolean f()
  {
    return this.d;
  }
  
  public int g()
  {
    return this.i;
  }
  
  public int g(acs paramacs)
  {
    return j(paramacs);
  }
  
  protected boolean h()
  {
    return t() == 1;
  }
  
  void i()
  {
    if (this.a == null) {
      this.a = j();
    }
    if (this.j == null) {
      this.j = abm.a(this, this.i);
    }
  }
  
  aat j()
  {
    return new aat();
  }
  
  boolean k()
  {
    return (this.j.h() == 0) && (this.j.e() == 0);
  }
  
  boolean l()
  {
    return (x() != 1073741824) && (w() != 1073741824) && (J());
  }
  
  public int m()
  {
    View localView = a(0, v(), false, true);
    if (localView == null) {
      return -1;
    }
    return d(localView);
  }
  
  public int n()
  {
    View localView = a(0, v(), true, false);
    if (localView == null) {
      return -1;
    }
    return d(localView);
  }
  
  public int o()
  {
    View localView = a(v() - 1, -1, false, true);
    if (localView == null) {
      return -1;
    }
    return d(localView);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/v7/widget/LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */