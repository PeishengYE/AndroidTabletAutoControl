package android.support.v7.widget;

import android.content.Context;
import android.util.AttributeSet;
import o.aap;
import o.adz;

public class ActivityChooserView$InnerLayout
  extends aap
{
  private static final int[] a = { 16842964 };
  
  public ActivityChooserView$InnerLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = adz.a(paramContext, paramAttributeSet, a);
    setBackgroundDrawable(paramContext.a(0));
    paramContext.a();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/v7/widget/ActivityChooserView$InnerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */