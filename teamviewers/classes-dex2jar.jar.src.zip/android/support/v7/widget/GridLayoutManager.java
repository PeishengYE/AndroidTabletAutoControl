package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.Arrays;
import o.aal;
import o.aam;
import o.aan;
import o.aar;
import o.aas;
import o.aat;
import o.abm;
import o.acg;
import o.ach;
import o.acm;
import o.acs;
import o.rq;
import o.sb;

public class GridLayoutManager
  extends LinearLayoutManager
{
  boolean a = false;
  int b = -1;
  int[] c;
  View[] d;
  final SparseIntArray e = new SparseIntArray();
  final SparseIntArray f = new SparseIntArray();
  aan g = new aal();
  final Rect h = new Rect();
  
  public GridLayoutManager(Context paramContext, int paramInt)
  {
    super(paramContext);
    a(paramInt);
  }
  
  public GridLayoutManager(Context paramContext, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    super(paramContext, paramInt2, paramBoolean);
    a(paramInt1);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    a(a(paramContext, paramAttributeSet, paramInt1, paramInt2).b);
  }
  
  private void K()
  {
    this.e.clear();
    this.f.clear();
  }
  
  private void L()
  {
    int j = v();
    int i = 0;
    while (i < j)
    {
      aam localaam = (aam)h(i).getLayoutParams();
      int k = localaam.e();
      this.e.put(k, localaam.b());
      this.f.put(k, localaam.a());
      i += 1;
    }
  }
  
  private void M()
  {
    if (g() == 1) {}
    for (int i = y() - C() - A();; i = z() - D() - B())
    {
      l(i);
      return;
    }
  }
  
  private void N()
  {
    if ((this.d == null) || (this.d.length != this.b)) {
      this.d = new View[this.b];
    }
  }
  
  private int a(acm paramacm, acs paramacs, int paramInt)
  {
    if (!paramacs.a()) {
      return this.g.c(paramInt, this.b);
    }
    int i = paramacm.b(paramInt);
    if (i == -1)
    {
      Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + paramInt);
      return 0;
    }
    return this.g.c(i, this.b);
  }
  
  private void a(float paramFloat, int paramInt)
  {
    l(Math.max(Math.round(this.b * paramFloat), paramInt));
  }
  
  private void a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    a(paramView, this.h);
    ach localach = (ach)paramView.getLayoutParams();
    int i;
    if (!paramBoolean1)
    {
      i = paramInt1;
      if (this.i != 1) {}
    }
    else
    {
      i = b(paramInt1, localach.leftMargin + this.h.left, localach.rightMargin + this.h.right);
    }
    if (!paramBoolean1)
    {
      paramInt1 = paramInt2;
      if (this.i != 0) {}
    }
    else
    {
      paramInt1 = b(paramInt2, localach.topMargin + this.h.top, localach.bottomMargin + this.h.bottom);
    }
    if (paramBoolean2) {}
    for (paramBoolean1 = a(paramView, i, paramInt1, localach);; paramBoolean1 = b(paramView, i, paramInt1, localach))
    {
      if (paramBoolean1) {
        paramView.measure(i, paramInt1);
      }
      return;
    }
  }
  
  private void a(acm paramacm, acs paramacs, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i;
    int j;
    int k;
    label43:
    aam localaam;
    if (paramBoolean)
    {
      i = 1;
      paramInt2 = 0;
      j = paramInt1;
      paramInt1 = paramInt2;
      if ((this.i != 1) || (!h())) {
        break label150;
      }
      paramInt2 = this.b - 1;
      k = -1;
      if (paramInt1 == j) {
        return;
      }
      View localView = this.d[paramInt1];
      localaam = (aam)localView.getLayoutParams();
      aam.a(localaam, c(paramacm, paramacs, d(localView)));
      if ((k != -1) || (aam.b(localaam) <= 1)) {
        break label159;
      }
      aam.b(localaam, paramInt2 - (aam.b(localaam) - 1));
    }
    for (;;)
    {
      paramInt2 += aam.b(localaam) * k;
      paramInt1 += i;
      break label43;
      paramInt1 -= 1;
      i = -1;
      j = -1;
      break;
      label150:
      paramInt2 = 0;
      k = 1;
      break label43;
      label159:
      aam.b(localaam, paramInt2);
    }
  }
  
  static int[] a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int k = 0;
    int[] arrayOfInt;
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length == paramInt1 + 1))
    {
      arrayOfInt = paramArrayOfInt;
      if (paramArrayOfInt[(paramArrayOfInt.length - 1)] == paramInt2) {}
    }
    else
    {
      arrayOfInt = new int[paramInt1 + 1];
    }
    arrayOfInt[0] = 0;
    int m = paramInt2 / paramInt1;
    int n = paramInt2 % paramInt1;
    int i = 1;
    int j = 0;
    paramInt2 = k;
    if (i <= paramInt1)
    {
      paramInt2 += n;
      if ((paramInt2 <= 0) || (paramInt1 - paramInt2 >= n)) {
        break label113;
      }
      k = m + 1;
      paramInt2 -= paramInt1;
    }
    for (;;)
    {
      j += k;
      arrayOfInt[i] = j;
      i += 1;
      break;
      return arrayOfInt;
      label113:
      k = m;
    }
  }
  
  private int b(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt2 == 0) && (paramInt3 == 0)) {}
    int i;
    do
    {
      return paramInt1;
      i = View.MeasureSpec.getMode(paramInt1);
    } while ((i != Integer.MIN_VALUE) && (i != 1073741824));
    return View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i);
  }
  
  private int b(acm paramacm, acs paramacs, int paramInt)
  {
    if (!paramacs.a()) {
      i = this.g.b(paramInt, this.b);
    }
    int j;
    do
    {
      return i;
      j = this.f.get(paramInt, -1);
      i = j;
    } while (j != -1);
    int i = paramacm.b(paramInt);
    if (i == -1)
    {
      Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + paramInt);
      return 0;
    }
    return this.g.b(i, this.b);
  }
  
  private void b(acm paramacm, acs paramacs, aar paramaar, int paramInt)
  {
    int i = 1;
    if (paramInt == 1) {}
    for (;;)
    {
      paramInt = b(paramacm, paramacs, paramaar.a);
      if (i == 0) {
        break;
      }
      while ((paramInt > 0) && (paramaar.a > 0))
      {
        paramaar.a -= 1;
        paramInt = b(paramacm, paramacs, paramaar.a);
      }
      i = 0;
    }
    int k = paramacs.e();
    i = paramaar.a;
    while (i < k - 1)
    {
      int j = b(paramacm, paramacs, i + 1);
      if (j <= paramInt) {
        break;
      }
      i += 1;
      paramInt = j;
    }
    paramaar.a = i;
  }
  
  private int c(acm paramacm, acs paramacs, int paramInt)
  {
    if (!paramacs.a()) {
      i = this.g.a(paramInt);
    }
    int j;
    do
    {
      return i;
      j = this.e.get(paramInt, -1);
      i = j;
    } while (j != -1);
    int i = paramacm.b(paramInt);
    if (i == -1)
    {
      Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + paramInt);
      return 1;
    }
    return this.g.a(i);
  }
  
  private void l(int paramInt)
  {
    this.c = a(this.c, this.b, paramInt);
  }
  
  public int a(int paramInt, acm paramacm, acs paramacs)
  {
    M();
    N();
    return super.a(paramInt, paramacm, paramacs);
  }
  
  public int a(acm paramacm, acs paramacs)
  {
    if (this.i == 0) {
      return this.b;
    }
    if (paramacs.e() < 1) {
      return 0;
    }
    return a(paramacm, paramacs, paramacs.e() - 1) + 1;
  }
  
  public View a(View paramView, int paramInt, acm paramacm, acs paramacs)
  {
    View localView = e(paramView);
    if (localView == null)
    {
      paramacm = null;
      return paramacm;
    }
    aam localaam = (aam)localView.getLayoutParams();
    int i4 = aam.a(localaam);
    int i5 = aam.a(localaam) + aam.b(localaam);
    if (super.a(paramView, paramInt, paramacm, paramacs) == null) {
      return null;
    }
    int i8;
    label83:
    int m;
    int k;
    if (e(paramInt) == 1)
    {
      i8 = 1;
      if (i8 == this.k) {
        break label162;
      }
      paramInt = 1;
      if (paramInt == 0) {
        break label167;
      }
      paramInt = v() - 1;
      m = -1;
      k = -1;
      label100:
      if ((this.i != 1) || (!h())) {
        break label181;
      }
    }
    int j;
    int i;
    int i1;
    label132:
    label162:
    label167:
    label181:
    for (int n = 1;; n = 0)
    {
      paramView = null;
      j = -1;
      i = 0;
      i1 = paramInt;
      paramInt = j;
      if (i1 != k)
      {
        paramacs = h(i1);
        if (paramacs != localView) {
          break label187;
        }
      }
      return paramView;
      i8 = 0;
      break;
      paramInt = 0;
      break label83;
      k = v();
      paramInt = 0;
      m = 1;
      break label100;
    }
    label187:
    if (!paramacs.isFocusable())
    {
      j = i;
      i = paramInt;
      paramInt = j;
    }
    for (;;)
    {
      i1 += m;
      j = i;
      i = paramInt;
      paramInt = j;
      break label132;
      localaam = (aam)paramacs.getLayoutParams();
      int i6 = aam.a(localaam);
      int i7 = aam.a(localaam) + aam.b(localaam);
      if (i6 == i4)
      {
        paramacm = paramacs;
        if (i7 == i5) {
          break;
        }
      }
      int i3 = 0;
      if (paramView == null) {
        j = 1;
      }
      for (;;)
      {
        if (j != 0)
        {
          i = aam.a(localaam);
          paramInt = Math.min(i7, i5) - Math.max(i6, i4);
          paramView = paramacs;
          break;
          j = Math.max(i6, i4);
          int i2 = Math.min(i7, i5) - j;
          if (i2 > i)
          {
            j = 1;
          }
          else
          {
            j = i3;
            if (i2 == i)
            {
              if (i6 > paramInt) {}
              for (i2 = 1;; i2 = 0)
              {
                j = i3;
                if (n != i2) {
                  break;
                }
                j = 1;
                break;
              }
            }
          }
        }
      }
      j = paramInt;
      paramInt = i;
      i = j;
    }
  }
  
  View a(acm paramacm, acs paramacs, int paramInt1, int paramInt2, int paramInt3)
  {
    Object localObject2 = null;
    i();
    int j = this.j.c();
    int k = this.j.d();
    int i;
    Object localObject1;
    label37:
    Object localObject3;
    if (paramInt2 > paramInt1)
    {
      i = 1;
      localObject1 = null;
      if (paramInt1 == paramInt2) {
        break label197;
      }
      localObject3 = h(paramInt1);
      int m = d((View)localObject3);
      if ((m < 0) || (m >= paramInt3)) {
        break label216;
      }
      if (b(paramacm, paramacs, m) == 0) {
        break label119;
      }
      localObject3 = localObject2;
      localObject2 = localObject1;
      localObject1 = localObject3;
    }
    for (;;)
    {
      paramInt1 += i;
      localObject3 = localObject2;
      localObject2 = localObject1;
      localObject1 = localObject3;
      break label37;
      i = -1;
      break;
      label119:
      if (((ach)((View)localObject3).getLayoutParams()).c())
      {
        if (localObject1 == null)
        {
          localObject1 = localObject2;
          localObject2 = localObject3;
        }
      }
      else
      {
        Object localObject4;
        if (this.j.a((View)localObject3) < k)
        {
          localObject4 = localObject3;
          if (this.j.b((View)localObject3) >= j) {}
        }
        else
        {
          if (localObject2 != null) {
            break label216;
          }
          localObject2 = localObject1;
          localObject1 = localObject3;
          continue;
          label197:
          if (localObject2 == null) {
            break label209;
          }
        }
        for (;;)
        {
          localObject4 = localObject2;
          return (View)localObject4;
          label209:
          localObject2 = localObject1;
        }
      }
      label216:
      localObject3 = localObject1;
      localObject1 = localObject2;
      localObject2 = localObject3;
    }
  }
  
  public ach a()
  {
    if (this.i == 0) {
      return new aam(-2, -1);
    }
    return new aam(-1, -2);
  }
  
  public ach a(Context paramContext, AttributeSet paramAttributeSet)
  {
    return new aam(paramContext, paramAttributeSet);
  }
  
  public ach a(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new aam((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new aam(paramLayoutParams);
  }
  
  public void a(int paramInt)
  {
    if (paramInt == this.b) {
      return;
    }
    this.a = true;
    if (paramInt < 1) {
      throw new IllegalArgumentException("Span count should be at least 1. Provided " + paramInt);
    }
    this.b = paramInt;
    this.g.a();
  }
  
  public void a(Rect paramRect, int paramInt1, int paramInt2)
  {
    if (this.c == null) {
      super.a(paramRect, paramInt1, paramInt2);
    }
    int i = A();
    int j = C() + i;
    int k = B() + D();
    if (this.i == 1)
    {
      i = a(paramInt2, k + paramRect.height(), G());
      paramInt2 = a(paramInt1, j + this.c[(this.c.length - 1)], F());
      paramInt1 = i;
    }
    for (;;)
    {
      e(paramInt2, paramInt1);
      return;
      i = a(paramInt1, j + paramRect.width(), F());
      paramInt1 = a(paramInt2, k + this.c[(this.c.length - 1)], G());
      paramInt2 = i;
    }
  }
  
  public void a(RecyclerView paramRecyclerView)
  {
    this.g.a();
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    this.g.a();
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3)
  {
    this.g.a();
  }
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject)
  {
    this.g.a();
  }
  
  public void a(acm paramacm, acs paramacs, View paramView, rq paramrq)
  {
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    if (!(localLayoutParams instanceof aam))
    {
      super.a(paramView, paramrq);
      return;
    }
    paramView = (aam)localLayoutParams;
    int i = a(paramacm, paramacs, paramView.e());
    if (this.i == 0)
    {
      j = paramView.a();
      k = paramView.b();
      if ((this.b > 1) && (paramView.b() == this.b)) {}
      for (bool = true;; bool = false)
      {
        paramrq.b(sb.a(j, k, i, 1, bool, false));
        return;
      }
    }
    int j = paramView.a();
    int k = paramView.b();
    if ((this.b > 1) && (paramView.b() == this.b)) {}
    for (boolean bool = true;; bool = false)
    {
      paramrq.b(sb.a(i, 1, j, k, bool, false));
      return;
    }
  }
  
  void a(acm paramacm, acs paramacs, aar paramaar, int paramInt)
  {
    super.a(paramacm, paramacs, paramaar, paramInt);
    M();
    if ((paramacs.e() > 0) && (!paramacs.a())) {
      b(paramacm, paramacs, paramaar, paramInt);
    }
    N();
  }
  
  void a(acm paramacm, acs paramacs, aat paramaat, aas paramaas)
  {
    int i3 = this.j.i();
    int j;
    int k;
    label37:
    boolean bool1;
    label57:
    int i1;
    int i2;
    int n;
    if (i3 != 1073741824)
    {
      j = 1;
      if (v() <= 0) {
        break label225;
      }
      k = this.c[this.b];
      if (j != 0) {
        M();
      }
      if (paramaat.e != 1) {
        break label231;
      }
      bool1 = true;
      i1 = 0;
      i2 = 0;
      i = this.b;
      n = i1;
      m = i2;
      if (!bool1)
      {
        i = b(paramacm, paramacs, paramaat.d) + c(paramacm, paramacs, paramaat.d);
        m = i2;
        n = i1;
      }
    }
    for (;;)
    {
      if ((n < this.b) && (paramaat.a(paramacs)) && (i > 0))
      {
        i2 = paramaat.d;
        i1 = c(paramacm, paramacs, i2);
        if (i1 > this.b)
        {
          throw new IllegalArgumentException("Item at position " + i2 + " requires " + i1 + " spans but GridLayoutManager has only " + this.b + " spans.");
          j = 0;
          break;
          label225:
          k = 0;
          break label37;
          label231:
          bool1 = false;
          break label57;
        }
        i -= i1;
        if (i >= 0) {
          break label261;
        }
      }
      label261:
      View localView;
      do
      {
        if (n != 0) {
          break;
        }
        paramaas.b = true;
        return;
        localView = paramaat.a(paramacm);
      } while (localView == null);
      m += i1;
      this.d[n] = localView;
      n += 1;
    }
    a(paramacm, paramacs, n, m, bool1);
    int m = 0;
    float f1 = 0.0F;
    int i = 0;
    label351:
    label399:
    label447:
    boolean bool2;
    if (m < n)
    {
      paramacm = this.d[m];
      if (paramaat.k == null) {
        if (bool1)
        {
          b(paramacm);
          paramacs = (aam)paramacm.getLayoutParams();
          i2 = this.c[(aam.a(paramacs) + aam.b(paramacs))];
          int i4 = this.c[aam.a(paramacs)];
          if (this.i != 0) {
            break label583;
          }
          i1 = paramacs.height;
          i2 = a(i2 - i4, i3, 0, i1, false);
          i4 = this.j.f();
          int i5 = this.j.h();
          if (this.i != 1) {
            break label592;
          }
          i1 = paramacs.height;
          i1 = a(i4, i5, 0, i1, true);
          if (this.i != 1) {
            break label607;
          }
          if (paramacs.height != -1) {
            break label601;
          }
          bool2 = true;
          label479:
          a(paramacm, i2, i1, bool2, false);
          i1 = this.j.c(paramacm);
          if (i1 <= i) {
            break label1459;
          }
          i = i1;
        }
      }
    }
    label583:
    label592:
    label601:
    label607:
    label729:
    label777:
    label809:
    label848:
    label857:
    label959:
    label1003:
    label1012:
    label1101:
    label1360:
    label1396:
    label1444:
    label1453:
    label1459:
    for (;;)
    {
      float f2 = 1.0F * this.j.d(paramacm) / aam.b(paramacs);
      if (f2 > f1) {
        f1 = f2;
      }
      for (;;)
      {
        m += 1;
        break;
        b(paramacm, 0);
        break label351;
        if (bool1)
        {
          a(paramacm);
          break label351;
        }
        a(paramacm, 0);
        break label351;
        i1 = paramacs.width;
        break label399;
        i1 = paramacs.width;
        break label447;
        bool2 = false;
        break label479;
        if (paramacs.width == -1) {}
        for (bool2 = true;; bool2 = false)
        {
          a(paramacm, i1, i2, bool2, false);
          break;
        }
        m = i;
        if (j != 0)
        {
          a(f1, k);
          i = 0;
          j = 0;
          m = i;
          if (j < n)
          {
            paramacm = this.d[j];
            paramacs = (aam)paramacm.getLayoutParams();
            m = this.c[(aam.a(paramacs) + aam.b(paramacs))];
            i1 = this.c[aam.a(paramacs)];
            if (this.i == 0)
            {
              k = paramacs.height;
              m = a(m - i1, 1073741824, 0, k, false);
              i1 = this.j.f();
              i2 = this.j.h();
              if (this.i != 1) {
                break label848;
              }
              k = paramacs.height;
              k = a(i1, i2, 0, k, true);
              if (this.i != 1) {
                break label857;
              }
              a(paramacm, m, k, false, true);
              k = this.j.c(paramacm);
              if (k <= i) {
                break label1453;
              }
              i = k;
            }
          }
        }
        for (;;)
        {
          j += 1;
          break;
          k = paramacs.width;
          break label729;
          k = paramacs.width;
          break label777;
          a(paramacm, k, m, false, true);
          break label809;
          k = View.MeasureSpec.makeMeasureSpec(m, 1073741824);
          i = 0;
          if (i < n)
          {
            paramacm = this.d[i];
            if (this.j.c(paramacm) != m)
            {
              paramacs = (aam)paramacm.getLayoutParams();
              i1 = this.c[(aam.a(paramacs) + aam.b(paramacs))];
              i2 = this.c[aam.a(paramacs)];
              if (this.i != 0) {
                break label1003;
              }
              j = paramacs.height;
              j = a(i1 - i2, 1073741824, 0, j, false);
              if (this.i != 1) {
                break label1012;
              }
              a(paramacm, j, k, true, true);
            }
            for (;;)
            {
              i += 1;
              break;
              j = paramacs.width;
              break label959;
              a(paramacm, k, j, true, true);
            }
          }
          paramaas.a = m;
          j = 0;
          k = 0;
          if (this.i == 1) {
            if (paramaat.f == -1)
            {
              k = paramaat.b;
              m = k - m;
              i = 0;
              j = 0;
              i3 = 0;
              i1 = i;
              i2 = k;
              k = i3;
              i = j;
              j = i1;
              i1 = i2;
              if (k >= n) {
                break label1444;
              }
              paramacm = this.d[k];
              paramacs = (aam)paramacm.getLayoutParams();
              if (this.i != 1) {
                break label1396;
              }
              if (!h()) {
                break label1360;
              }
              j = A() + this.c[(aam.a(paramacs) + aam.b(paramacs))];
              i2 = this.j.d(paramacm);
              i = j;
              j -= i2;
            }
          }
          for (;;)
          {
            a(paramacm, j + paramacs.leftMargin, m + paramacs.topMargin, i - paramacs.rightMargin, i1 - paramacs.bottomMargin);
            if ((paramacs.c()) || (paramacs.d())) {
              paramaas.c = true;
            }
            paramaas.d |= paramacm.isFocusable();
            i2 = k + 1;
            k = j;
            j = i;
            i = k;
            k = i2;
            break label1101;
            i = paramaat.b;
            k = i + m;
            i1 = 0;
            j = 0;
            m = i;
            i = i1;
            break;
            if (paramaat.f == -1)
            {
              i = paramaat.b;
              i1 = i - m;
              m = j;
              j = i1;
              break;
            }
            i1 = paramaat.b;
            i = m + i1;
            m = j;
            j = i1;
            break;
            i = A();
            j = this.c[aam.a(paramacs)] + i;
            i = this.j.d(paramacm) + j;
            continue;
            m = B();
            m = this.c[aam.a(paramacs)] + m;
            i1 = this.j.d(paramacm) + m;
            i2 = i;
            i = j;
            j = i2;
          }
          Arrays.fill(this.d, null);
          return;
        }
      }
    }
  }
  
  public void a(boolean paramBoolean)
  {
    if (paramBoolean) {
      throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }
    super.a(false);
  }
  
  public boolean a(ach paramach)
  {
    return paramach instanceof aam;
  }
  
  public int b(int paramInt, acm paramacm, acs paramacs)
  {
    M();
    N();
    return super.b(paramInt, paramacm, paramacs);
  }
  
  public int b(acm paramacm, acs paramacs)
  {
    if (this.i == 1) {
      return this.b;
    }
    if (paramacs.e() < 1) {
      return 0;
    }
    return a(paramacm, paramacs, paramacs.e() - 1) + 1;
  }
  
  public void b(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    this.g.a();
  }
  
  public boolean b()
  {
    return (this.n == null) && (!this.a);
  }
  
  public void c(acm paramacm, acs paramacs)
  {
    if (paramacs.a()) {
      L();
    }
    super.c(paramacm, paramacs);
    K();
    if (!paramacs.a()) {
      this.a = false;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/android/support/v7/widget/GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */