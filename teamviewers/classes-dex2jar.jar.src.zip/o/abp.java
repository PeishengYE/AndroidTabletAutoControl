package o;

import android.support.v7.widget.RecyclerView;

public class abp
  implements Runnable
{
  public abp(RecyclerView paramRecyclerView) {}
  
  public void run()
  {
    if ((!RecyclerView.a(this.a)) || (this.a.isLayoutRequested())) {
      return;
    }
    if (RecyclerView.b(this.a))
    {
      RecyclerView.a(this.a, true);
      return;
    }
    RecyclerView.c(this.a);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */