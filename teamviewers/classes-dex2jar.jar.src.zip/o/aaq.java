package o;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class aaq
  extends ViewGroup.MarginLayoutParams
{
  public float g;
  public int h = -1;
  
  public aaq(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
    this.g = 0.0F;
  }
  
  public aaq(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, vx.LinearLayoutCompat_Layout);
    this.g = paramContext.getFloat(vx.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
    this.h = paramContext.getInt(vx.LinearLayoutCompat_Layout_android_layout_gravity, -1);
    paramContext.recycle();
  }
  
  public aaq(ViewGroup.LayoutParams paramLayoutParams)
  {
    super(paramLayoutParams);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aaq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */