package o;

import android.view.View;
import java.util.ArrayList;

class aab
  extends aah
{
  aab(zw paramzw, acv paramacv, qr paramqr)
  {
    super(null);
  }
  
  public void a(View paramView)
  {
    this.c.m(this.a);
  }
  
  public void b(View paramView)
  {
    this.b.a(null);
    this.c.j(this.a);
    zw.f(this.c).remove(this.a);
    zw.e(this.c);
  }
  
  public void c(View paramView)
  {
    pe.c(paramView, 1.0F);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */