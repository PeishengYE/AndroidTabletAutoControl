package o;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;

class aay
  implements AdapterView.OnItemSelectedListener
{
  aay(aav paramaav) {}
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramInt != -1)
    {
      paramAdapterView = aav.a(this.a);
      if (paramAdapterView != null) {
        aaz.a(paramAdapterView, false);
      }
    }
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */