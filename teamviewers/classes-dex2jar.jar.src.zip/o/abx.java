package o;

public abstract class abx
{
  public void a() {}
  
  public void a(int paramInt1, int paramInt2) {}
  
  public void a(int paramInt1, int paramInt2, int paramInt3) {}
  
  public void a(int paramInt1, int paramInt2, Object paramObject)
  {
    a(paramInt1, paramInt2);
  }
  
  public void b(int paramInt1, int paramInt2) {}
  
  public void c(int paramInt1, int paramInt2) {}
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */