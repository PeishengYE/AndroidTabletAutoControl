package o;

import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;

public abstract interface acj
{
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean a(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent);
  
  public abstract void b(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */