package o;

import android.view.View;

class aax
  implements Runnable
{
  aax(aav paramaav) {}
  
  public void run()
  {
    View localView = this.a.e();
    if ((localView != null) && (localView.getWindowToken() != null)) {
      this.a.c();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */