package o;

import android.database.DataSetObserver;

class abe
  extends DataSetObserver
{
  private abe(aav paramaav) {}
  
  public void onChanged()
  {
    if (this.a.k()) {
      this.a.c();
    }
  }
  
  public void onInvalidated()
  {
    this.a.i();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */