package o;

import android.widget.PopupWindow;

class abh
  implements Runnable
{
  private abh(aav paramaav) {}
  
  public void run()
  {
    if ((aav.a(this.a) != null) && (pe.D(aav.a(this.a))) && (aav.a(this.a).getCount() > aav.a(this.a).getChildCount()) && (aav.a(this.a).getChildCount() <= this.a.b))
    {
      aav.b(this.a).setInputMethodMode(2);
      this.a.c();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */