package o;

import android.support.v7.widget.RecyclerView;

public class aco
  extends abx
{
  private aco(RecyclerView paramRecyclerView) {}
  
  public void a()
  {
    this.a.a(null);
    if (RecyclerView.f(this.a).b())
    {
      acs.a(this.a.h, true);
      RecyclerView.l(this.a);
    }
    for (;;)
    {
      if (!this.a.c.d()) {
        this.a.requestLayout();
      }
      return;
      acs.a(this.a.h, true);
      RecyclerView.l(this.a);
    }
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3)
  {
    this.a.a(null);
    if (this.a.c.a(paramInt1, paramInt2, paramInt3)) {
      b();
    }
  }
  
  public void a(int paramInt1, int paramInt2, Object paramObject)
  {
    this.a.a(null);
    if (this.a.c.a(paramInt1, paramInt2, paramObject)) {
      b();
    }
  }
  
  void b()
  {
    if ((RecyclerView.m(this.a)) && (RecyclerView.n(this.a)) && (RecyclerView.o(this.a)))
    {
      pe.a(this.a, RecyclerView.p(this.a));
      return;
    }
    RecyclerView.c(this.a, true);
    this.a.requestLayout();
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    this.a.a(null);
    if (this.a.c.b(paramInt1, paramInt2)) {
      b();
    }
  }
  
  public void c(int paramInt1, int paramInt2)
  {
    this.a.a(null);
    if (this.a.c.c(paramInt1, paramInt2)) {
      b();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aco.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */