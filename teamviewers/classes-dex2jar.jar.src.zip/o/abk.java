package o;

import java.util.List;

class abk
{
  final abl a;
  
  public abk(abl paramabl)
  {
    this.a = paramabl;
  }
  
  private void a(List<yu> paramList, int paramInt1, int paramInt2)
  {
    yu localyu1 = (yu)paramList.get(paramInt1);
    yu localyu2 = (yu)paramList.get(paramInt2);
    switch (localyu2.a)
    {
    case 3: 
    default: 
      return;
    case 2: 
      a(paramList, paramInt1, localyu1, paramInt2, localyu2);
      return;
    case 1: 
      c(paramList, paramInt1, localyu1, paramInt2, localyu2);
      return;
    }
    b(paramList, paramInt1, localyu1, paramInt2, localyu2);
  }
  
  private int b(List<yu> paramList)
  {
    int i = 0;
    int j = paramList.size() - 1;
    if (j >= 0)
    {
      if (((yu)paramList.get(j)).a == 8)
      {
        if (i == 0) {
          break label50;
        }
        return j;
      }
      i = 1;
    }
    label50:
    for (;;)
    {
      j -= 1;
      break;
      return -1;
    }
  }
  
  private void c(List<yu> paramList, int paramInt1, yu paramyu1, int paramInt2, yu paramyu2)
  {
    int i = 0;
    if (paramyu1.d < paramyu2.b) {
      i = -1;
    }
    int j = i;
    if (paramyu1.b < paramyu2.b) {
      j = i + 1;
    }
    if (paramyu2.b <= paramyu1.b) {
      paramyu1.b += paramyu2.d;
    }
    if (paramyu2.b <= paramyu1.d) {
      paramyu1.d += paramyu2.d;
    }
    paramyu2.b = (j + paramyu2.b);
    paramList.set(paramInt1, paramyu2);
    paramList.set(paramInt2, paramyu1);
  }
  
  void a(List<yu> paramList)
  {
    for (;;)
    {
      int i = b(paramList);
      if (i == -1) {
        break;
      }
      a(paramList, i, i + 1);
    }
  }
  
  void a(List<yu> paramList, int paramInt1, yu paramyu1, int paramInt2, yu paramyu2)
  {
    int j = 0;
    int i;
    if (paramyu1.b < paramyu1.d)
    {
      if ((paramyu2.b != paramyu1.b) || (paramyu2.d != paramyu1.d - paramyu1.b)) {
        break label623;
      }
      i = 1;
    }
    for (;;)
    {
      label70:
      yu localyu;
      if (paramyu1.d < paramyu2.b)
      {
        paramyu2.b -= 1;
        if (paramyu1.b > paramyu2.b) {
          break label241;
        }
        paramyu2.b += 1;
        localyu = null;
      }
      for (;;)
      {
        label97:
        if (i != 0)
        {
          paramList.set(paramInt1, paramyu2);
          paramList.remove(paramInt2);
          this.a.a(paramyu1);
        }
        label241:
        label596:
        label606:
        for (;;)
        {
          return;
          if ((paramyu2.b != paramyu1.d + 1) || (paramyu2.d != paramyu1.b - paramyu1.d)) {
            break label614;
          }
          j = 1;
          i = 1;
          break;
          if (paramyu1.d >= paramyu2.b + paramyu2.d) {
            break label70;
          }
          paramyu2.d -= 1;
          paramyu1.a = 2;
          paramyu1.d = 1;
          if (paramyu2.d == 0)
          {
            paramList.remove(paramInt2);
            this.a.a(paramyu2);
            return;
            if (paramyu1.b >= paramyu2.b + paramyu2.d) {
              break label608;
            }
            int k = paramyu2.b;
            int m = paramyu2.d;
            int n = paramyu1.b;
            localyu = this.a.a(2, paramyu1.b + 1, k + m - n, null);
            paramyu2.d = (paramyu1.b - paramyu2.b);
            break label97;
            if (j != 0)
            {
              if (localyu != null)
              {
                if (paramyu1.b > localyu.b) {
                  paramyu1.b -= localyu.d;
                }
                if (paramyu1.d > localyu.b) {
                  paramyu1.d -= localyu.d;
                }
              }
              if (paramyu1.b > paramyu2.b) {
                paramyu1.b -= paramyu2.d;
              }
              if (paramyu1.d > paramyu2.b) {
                paramyu1.d -= paramyu2.d;
              }
              paramList.set(paramInt1, paramyu2);
              if (paramyu1.b == paramyu1.d) {
                break label596;
              }
              paramList.set(paramInt2, paramyu1);
            }
            for (;;)
            {
              if (localyu == null) {
                break label606;
              }
              paramList.add(paramInt1, localyu);
              return;
              if (localyu != null)
              {
                if (paramyu1.b >= localyu.b) {
                  paramyu1.b -= localyu.d;
                }
                if (paramyu1.d >= localyu.b) {
                  paramyu1.d -= localyu.d;
                }
              }
              if (paramyu1.b >= paramyu2.b) {
                paramyu1.b -= paramyu2.d;
              }
              if (paramyu1.d < paramyu2.b) {
                break;
              }
              paramyu1.d -= paramyu2.d;
              break;
              paramList.remove(paramInt2);
            }
          }
        }
        label608:
        localyu = null;
      }
      label614:
      i = 0;
      j = 1;
      continue;
      label623:
      i = 0;
    }
  }
  
  void b(List<yu> paramList, int paramInt1, yu paramyu1, int paramInt2, yu paramyu2)
  {
    Object localObject2 = null;
    Object localObject1;
    if (paramyu1.d < paramyu2.b)
    {
      paramyu2.b -= 1;
      localObject1 = null;
    }
    for (;;)
    {
      if (paramyu1.b <= paramyu2.b)
      {
        paramyu2.b += 1;
        label54:
        paramList.set(paramInt2, paramyu1);
        if (paramyu2.d <= 0) {
          break label243;
        }
        paramList.set(paramInt1, paramyu2);
      }
      for (;;)
      {
        if (localObject1 != null) {
          paramList.add(paramInt1, localObject1);
        }
        if (localObject2 != null) {
          paramList.add(paramInt1, localObject2);
        }
        return;
        if (paramyu1.d >= paramyu2.b + paramyu2.d) {
          break label265;
        }
        paramyu2.d -= 1;
        localObject1 = this.a.a(4, paramyu1.b, 1, paramyu2.c);
        break;
        if (paramyu1.b >= paramyu2.b + paramyu2.d) {
          break label54;
        }
        int i = paramyu2.b + paramyu2.d - paramyu1.b;
        localObject2 = this.a.a(4, paramyu1.b + 1, i, paramyu2.c);
        paramyu2.d -= i;
        break label54;
        label243:
        paramList.remove(paramInt1);
        this.a.a(paramyu2);
      }
      label265:
      localObject1 = null;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */