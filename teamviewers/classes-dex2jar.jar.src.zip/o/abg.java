package o;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.PopupWindow;

class abg
  implements View.OnTouchListener
{
  private abg(aav paramaav) {}
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getAction();
    int j = (int)paramMotionEvent.getX();
    int k = (int)paramMotionEvent.getY();
    if ((i == 0) && (aav.b(this.a) != null) && (aav.b(this.a).isShowing()) && (j >= 0) && (j < aav.b(this.a).getWidth()) && (k >= 0) && (k < aav.b(this.a).getHeight())) {
      aav.d(this.a).postDelayed(aav.c(this.a), 250L);
    }
    for (;;)
    {
      return false;
      if (i == 1) {
        aav.d(this.a).removeCallbacks(aav.c(this.a));
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */