package o;

import android.os.Parcel;
import android.support.design.widget.CoordinatorLayout.SavedState;

public final class ac
  implements kj<CoordinatorLayout.SavedState>
{
  public CoordinatorLayout.SavedState a(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return new CoordinatorLayout.SavedState(paramParcel, paramClassLoader);
  }
  
  public CoordinatorLayout.SavedState[] a(int paramInt)
  {
    return new CoordinatorLayout.SavedState[paramInt];
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */