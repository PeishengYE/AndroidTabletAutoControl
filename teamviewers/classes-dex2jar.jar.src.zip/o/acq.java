package o;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

public abstract class acq
{
  private int a;
  private RecyclerView b;
  private acf c;
  private boolean d;
  private boolean e;
  private View f;
  private final acr g;
  
  private void a(int paramInt1, int paramInt2)
  {
    RecyclerView localRecyclerView = this.b;
    if ((!this.e) || (this.a == -1) || (localRecyclerView == null)) {
      a();
    }
    this.d = false;
    if (this.f != null)
    {
      if (a(this.f) != this.a) {
        break label151;
      }
      a(this.f, localRecyclerView.h, this.g);
      acr.a(this.g, localRecyclerView);
      a();
    }
    for (;;)
    {
      if (this.e)
      {
        a(paramInt1, paramInt2, localRecyclerView.h, this.g);
        boolean bool = this.g.a();
        acr.a(this.g, localRecyclerView);
        if (bool)
        {
          if (!this.e) {
            break;
          }
          this.d = true;
          RecyclerView.u(localRecyclerView).a();
        }
      }
      return;
      label151:
      Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
      this.f = null;
    }
    a();
  }
  
  public int a(View paramView)
  {
    return this.b.d(paramView);
  }
  
  protected final void a()
  {
    if (!this.e) {
      return;
    }
    e();
    acs.e(this.b.h, -1);
    this.f = null;
    this.a = -1;
    this.d = false;
    this.e = false;
    acf.a(this.c, this);
    this.c = null;
    this.b = null;
  }
  
  public void a(int paramInt)
  {
    this.a = paramInt;
  }
  
  protected abstract void a(int paramInt1, int paramInt2, acs paramacs, acr paramacr);
  
  protected abstract void a(View paramView, acs paramacs, acr paramacr);
  
  protected void b(View paramView)
  {
    if (a(paramView) == d()) {
      this.f = paramView;
    }
  }
  
  public boolean b()
  {
    return this.d;
  }
  
  public boolean c()
  {
    return this.e;
  }
  
  public int d()
  {
    return this.a;
  }
  
  protected abstract void e();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */