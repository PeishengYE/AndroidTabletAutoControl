package o;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public class acw
  extends mf
{
  final RecyclerView b;
  final mf c = new acx(this);
  
  public acw(RecyclerView paramRecyclerView)
  {
    this.b = paramRecyclerView;
  }
  
  private boolean c()
  {
    return this.b.p();
  }
  
  public void a(View paramView, rq paramrq)
  {
    super.a(paramView, paramrq);
    paramrq.a(RecyclerView.class.getName());
    if ((!c()) && (this.b.getLayoutManager() != null)) {
      this.b.getLayoutManager().a(paramrq);
    }
  }
  
  public boolean a(View paramView, int paramInt, Bundle paramBundle)
  {
    if (super.a(paramView, paramInt, paramBundle)) {
      return true;
    }
    if ((!c()) && (this.b.getLayoutManager() != null)) {
      return this.b.getLayoutManager().a(paramInt, paramBundle);
    }
    return false;
  }
  
  mf b()
  {
    return this.c;
  }
  
  public void d(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    super.d(paramView, paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(RecyclerView.class.getName());
    if (((paramView instanceof RecyclerView)) && (!c()))
    {
      paramView = (RecyclerView)paramView;
      if (paramView.getLayoutManager() != null) {
        paramView.getLayoutManager().a(paramAccessibilityEvent);
      }
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */