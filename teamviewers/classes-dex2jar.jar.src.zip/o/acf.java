package o;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;

public abstract class acf
{
  private boolean a = false;
  private boolean b = false;
  private boolean c = true;
  private int d;
  private int e;
  private int f;
  private int g;
  zr p;
  public RecyclerView q;
  acq r;
  boolean s = false;
  
  public static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    paramInt1 = i;
    switch (j)
    {
    default: 
      paramInt1 = Math.max(paramInt2, paramInt3);
    case 1073741824: 
      return paramInt1;
    }
    return Math.min(i, Math.max(paramInt2, paramInt3));
  }
  
  public static int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    int j = 0;
    int k = 0;
    int i = Math.max(0, paramInt1 - paramInt3);
    if (paramBoolean) {
      if (paramInt4 >= 0)
      {
        paramInt1 = 1073741824;
        paramInt3 = paramInt4;
      }
    }
    for (;;)
    {
      return View.MeasureSpec.makeMeasureSpec(paramInt3, paramInt1);
      if (paramInt4 == -1)
      {
        switch (paramInt2)
        {
        default: 
          paramInt2 = 0;
          paramInt1 = j;
        }
        for (;;)
        {
          paramInt3 = paramInt1;
          paramInt1 = paramInt2;
          break;
          paramInt1 = i;
          continue;
          paramInt2 = 0;
          paramInt1 = j;
        }
      }
      if (paramInt4 == -2)
      {
        paramInt3 = 0;
        paramInt1 = k;
        continue;
        if (paramInt4 >= 0)
        {
          paramInt1 = 1073741824;
          paramInt3 = paramInt4;
          continue;
        }
        if (paramInt4 == -1)
        {
          paramInt1 = paramInt2;
          paramInt3 = i;
          continue;
        }
        if (paramInt4 == -2)
        {
          if (paramInt2 != Integer.MIN_VALUE)
          {
            paramInt1 = k;
            paramInt3 = i;
            if (paramInt2 != 1073741824) {
              continue;
            }
          }
          paramInt1 = Integer.MIN_VALUE;
          paramInt3 = i;
          continue;
        }
      }
      paramInt3 = 0;
      paramInt1 = k;
    }
  }
  
  public static acg a(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    acg localacg = new acg();
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, wa.RecyclerView, paramInt1, paramInt2);
    localacg.a = paramContext.getInt(wa.RecyclerView_android_orientation, 1);
    localacg.b = paramContext.getInt(wa.RecyclerView_spanCount, 1);
    localacg.c = paramContext.getBoolean(wa.RecyclerView_reverseLayout, false);
    localacg.d = paramContext.getBoolean(wa.RecyclerView_stackFromEnd, false);
    paramContext.recycle();
    return localacg;
  }
  
  private void a(int paramInt, View paramView)
  {
    this.p.d(paramInt);
  }
  
  private void a(View paramView, int paramInt, boolean paramBoolean)
  {
    acv localacv = RecyclerView.c(paramView);
    ach localach;
    if ((paramBoolean) || (localacv.q()))
    {
      this.q.e.e(localacv);
      localach = (ach)paramView.getLayoutParams();
      if ((!localacv.k()) && (!localacv.i())) {
        break label128;
      }
      if (!localacv.i()) {
        break label120;
      }
      localacv.j();
      label68:
      this.p.a(paramView, paramInt, paramView.getLayoutParams(), false);
    }
    for (;;)
    {
      if (localach.d)
      {
        localacv.a.invalidate();
        localach.d = false;
      }
      return;
      this.q.e.f(localacv);
      break;
      label120:
      localacv.l();
      break label68;
      label128:
      if (paramView.getParent() == this.q)
      {
        int j = this.p.b(paramView);
        int i = paramInt;
        if (paramInt == -1) {
          i = this.p.b();
        }
        if (j == -1) {
          throw new IllegalStateException("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:" + this.q.indexOfChild(paramView));
        }
        if (j != i) {
          this.q.f.d(j, i);
        }
      }
      else
      {
        this.p.a(paramView, paramInt, false);
        localach.c = true;
        if ((this.r != null) && (this.r.c())) {
          this.r.b(paramView);
        }
      }
    }
  }
  
  private void a(acm paramacm, int paramInt, View paramView)
  {
    acv localacv = RecyclerView.c(paramView);
    if (localacv.c()) {
      return;
    }
    if ((localacv.n()) && (!localacv.q()) && (!RecyclerView.f(this.q).b()))
    {
      f(paramInt);
      paramacm.b(localacv);
      return;
    }
    g(paramInt);
    paramacm.c(paramView);
    this.q.e.h(localacv);
  }
  
  private void a(acq paramacq)
  {
    if (this.r == paramacq) {
      this.r = null;
    }
  }
  
  private static boolean b(int paramInt1, int paramInt2, int paramInt3)
  {
    boolean bool2 = true;
    int i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    boolean bool1;
    if ((paramInt3 > 0) && (paramInt1 != paramInt3)) {
      bool1 = false;
    }
    do
    {
      do
      {
        return bool1;
        bool1 = bool2;
        switch (i)
        {
        case 0: 
        default: 
          return false;
        case -2147483648: 
          bool1 = bool2;
        }
      } while (paramInt2 >= paramInt1);
      return false;
      bool1 = bool2;
    } while (paramInt2 == paramInt1);
    return false;
  }
  
  public int A()
  {
    if (this.q != null) {
      return this.q.getPaddingLeft();
    }
    return 0;
  }
  
  public int B()
  {
    if (this.q != null) {
      return this.q.getPaddingTop();
    }
    return 0;
  }
  
  public int C()
  {
    if (this.q != null) {
      return this.q.getPaddingRight();
    }
    return 0;
  }
  
  public int D()
  {
    if (this.q != null) {
      return this.q.getPaddingBottom();
    }
    return 0;
  }
  
  public View E()
  {
    if (this.q == null) {}
    View localView;
    do
    {
      return null;
      localView = this.q.getFocusedChild();
    } while ((localView == null) || (this.p.c(localView)));
    return localView;
  }
  
  public int F()
  {
    return pe.p(this.q);
  }
  
  public int G()
  {
    return pe.q(this.q);
  }
  
  public void H()
  {
    if (this.r != null) {
      this.r.a();
    }
  }
  
  public void I()
  {
    this.a = true;
  }
  
  public boolean J()
  {
    boolean bool2 = false;
    int j = v();
    int i = 0;
    for (;;)
    {
      boolean bool1 = bool2;
      if (i < j)
      {
        ViewGroup.LayoutParams localLayoutParams = h(i).getLayoutParams();
        if ((localLayoutParams.width < 0) && (localLayoutParams.height < 0)) {
          bool1 = true;
        }
      }
      else
      {
        return bool1;
      }
      i += 1;
    }
  }
  
  public int a(int paramInt, acm paramacm, acs paramacs)
  {
    return 0;
  }
  
  public int a(acm paramacm, acs paramacs)
  {
    if ((this.q == null) || (RecyclerView.f(this.q) == null)) {}
    while (!e()) {
      return 1;
    }
    return RecyclerView.f(this.q).a();
  }
  
  public View a(View paramView, int paramInt, acm paramacm, acs paramacs)
  {
    return null;
  }
  
  public abstract ach a();
  
  public ach a(Context paramContext, AttributeSet paramAttributeSet)
  {
    return new ach(paramContext, paramAttributeSet);
  }
  
  public ach a(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof ach)) {
      return new ach((ach)paramLayoutParams);
    }
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new ach((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new ach(paramLayoutParams);
  }
  
  public void a(int paramInt, acm paramacm)
  {
    View localView = h(paramInt);
    f(paramInt);
    paramacm.a(localView);
  }
  
  public void a(Rect paramRect, int paramInt1, int paramInt2)
  {
    int i = paramRect.width();
    int j = A();
    int k = C();
    int m = paramRect.height();
    int n = B();
    int i1 = D();
    e(a(paramInt1, i + j + k, F()), a(paramInt2, m + n + i1, G()));
  }
  
  public void a(Parcelable paramParcelable) {}
  
  public void a(RecyclerView paramRecyclerView) {}
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject)
  {
    c(paramRecyclerView, paramInt1, paramInt2);
  }
  
  public void a(RecyclerView paramRecyclerView, acm paramacm)
  {
    e(paramRecyclerView);
  }
  
  public void a(View paramView)
  {
    a(paramView, -1);
  }
  
  public void a(View paramView, int paramInt)
  {
    a(paramView, paramInt, true);
  }
  
  public void a(View paramView, int paramInt1, int paramInt2)
  {
    ach localach = (ach)paramView.getLayoutParams();
    Rect localRect = this.q.g(paramView);
    int k = localRect.left;
    int m = localRect.right;
    int i = localRect.top;
    int j = localRect.bottom;
    paramInt1 = a(y(), w(), k + m + paramInt1 + (A() + C() + localach.leftMargin + localach.rightMargin), localach.width, d());
    paramInt2 = a(z(), x(), j + i + paramInt2 + (B() + D() + localach.topMargin + localach.bottomMargin), localach.height, e());
    if (b(paramView, paramInt1, paramInt2, localach)) {
      paramView.measure(paramInt1, paramInt2);
    }
  }
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Rect localRect = ((ach)paramView.getLayoutParams()).b;
    paramView.layout(localRect.left + paramInt1, localRect.top + paramInt2, paramInt3 - localRect.right, paramInt4 - localRect.bottom);
  }
  
  public void a(View paramView, int paramInt, ach paramach)
  {
    acv localacv = RecyclerView.c(paramView);
    if (localacv.q()) {
      this.q.e.e(localacv);
    }
    for (;;)
    {
      this.p.a(paramView, paramInt, paramach, localacv.q());
      return;
      this.q.e.f(localacv);
    }
  }
  
  public void a(View paramView, Rect paramRect)
  {
    if (this.q == null)
    {
      paramRect.set(0, 0, 0, 0);
      return;
    }
    paramRect.set(this.q.g(paramView));
  }
  
  public void a(View paramView, acm paramacm)
  {
    c(paramView);
    paramacm.a(paramView);
  }
  
  public void a(View paramView, rq paramrq)
  {
    acv localacv = RecyclerView.c(paramView);
    if ((localacv != null) && (!localacv.q()) && (!this.p.c(localacv.a))) {
      a(this.q.b, this.q.h, paramView, paramrq);
    }
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent)
  {
    a(this.q.b, this.q.h, paramAccessibilityEvent);
  }
  
  public void a(String paramString)
  {
    if (this.q != null) {
      this.q.a(paramString);
    }
  }
  
  public void a(abv paramabv1, abv paramabv2) {}
  
  public void a(acm paramacm)
  {
    int i = v() - 1;
    while (i >= 0)
    {
      a(paramacm, i, h(i));
      i -= 1;
    }
  }
  
  public void a(acm paramacm, acs paramacs, int paramInt1, int paramInt2)
  {
    this.q.d(paramInt1, paramInt2);
  }
  
  public void a(acm paramacm, acs paramacs, View paramView, rq paramrq)
  {
    int i;
    if (e())
    {
      i = d(paramView);
      if (!d()) {
        break label51;
      }
    }
    label51:
    for (int j = d(paramView);; j = 0)
    {
      paramrq.b(sb.a(i, 1, j, 1, false, false));
      return;
      i = 0;
      break;
    }
  }
  
  public void a(acm paramacm, acs paramacs, AccessibilityEvent paramAccessibilityEvent)
  {
    boolean bool2 = true;
    paramacm = rk.a(paramAccessibilityEvent);
    if ((this.q == null) || (paramacm == null)) {
      return;
    }
    boolean bool1 = bool2;
    if (!pe.b(this.q, 1))
    {
      bool1 = bool2;
      if (!pe.b(this.q, -1))
      {
        bool1 = bool2;
        if (!pe.a(this.q, -1)) {
          if (!pe.a(this.q, 1)) {
            break label111;
          }
        }
      }
    }
    label111:
    for (bool1 = bool2;; bool1 = false)
    {
      paramacm.a(bool1);
      if (RecyclerView.f(this.q) == null) {
        break;
      }
      paramacm.a(RecyclerView.f(this.q).a());
      return;
    }
  }
  
  public void a(acm paramacm, acs paramacs, rq paramrq)
  {
    if ((pe.b(this.q, -1)) || (pe.a(this.q, -1)))
    {
      paramrq.a(8192);
      paramrq.a(true);
    }
    if ((pe.b(this.q, 1)) || (pe.a(this.q, 1)))
    {
      paramrq.a(4096);
      paramrq.a(true);
    }
    paramrq.a(sa.a(a(paramacm, paramacs), b(paramacm, paramacs), e(paramacm, paramacs), d(paramacm, paramacs)));
  }
  
  void a(rq paramrq)
  {
    a(this.q.b, this.q.h, paramrq);
  }
  
  boolean a(int paramInt, Bundle paramBundle)
  {
    return a(this.q.b, this.q.h, paramInt, paramBundle);
  }
  
  public boolean a(RecyclerView paramRecyclerView, View paramView, Rect paramRect, boolean paramBoolean)
  {
    int i2 = A();
    int m = B();
    int i3 = y() - C();
    int i1 = z();
    int i6 = D();
    int i4 = paramView.getLeft() + paramRect.left - paramView.getScrollX();
    int n = paramView.getTop() + paramRect.top - paramView.getScrollY();
    int i5 = i4 + paramRect.width();
    int i7 = paramRect.height();
    int i = Math.min(0, i4 - i2);
    int j = Math.min(0, n - m);
    int k = Math.max(0, i5 - i3);
    i1 = Math.max(0, n + i7 - (i1 - i6));
    if (t() == 1) {
      if (k != 0)
      {
        i = k;
        if (j == 0) {
          break label217;
        }
        label154:
        if ((i == 0) && (j == 0)) {
          break label243;
        }
        if (!paramBoolean) {
          break label232;
        }
        paramRecyclerView.scrollBy(i, j);
      }
    }
    for (;;)
    {
      return true;
      i = Math.max(i, i5 - i3);
      break;
      if (i != 0) {
        break;
      }
      for (;;)
      {
        i = Math.min(i4 - i2, k);
      }
      label217:
      j = Math.min(n - m, i1);
      break label154;
      label232:
      paramRecyclerView.a(i, j);
    }
    label243:
    return false;
  }
  
  @Deprecated
  public boolean a(RecyclerView paramRecyclerView, View paramView1, View paramView2)
  {
    return (s()) || (paramRecyclerView.j());
  }
  
  public boolean a(RecyclerView paramRecyclerView, ArrayList<View> paramArrayList, int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public boolean a(RecyclerView paramRecyclerView, acs paramacs, View paramView1, View paramView2)
  {
    return a(paramRecyclerView, paramView1, paramView2);
  }
  
  public boolean a(View paramView, int paramInt1, int paramInt2, ach paramach)
  {
    return (!this.c) || (!b(paramView.getMeasuredWidth(), paramInt1, paramach.width)) || (!b(paramView.getMeasuredHeight(), paramInt2, paramach.height));
  }
  
  boolean a(View paramView, int paramInt, Bundle paramBundle)
  {
    return a(this.q.b, this.q.h, paramView, paramInt, paramBundle);
  }
  
  public boolean a(Runnable paramRunnable)
  {
    if (this.q != null) {
      return this.q.removeCallbacks(paramRunnable);
    }
    return false;
  }
  
  public boolean a(ach paramach)
  {
    return paramach != null;
  }
  
  public boolean a(acm paramacm, acs paramacs, int paramInt, Bundle paramBundle)
  {
    if (this.q == null) {}
    int i;
    do
    {
      return false;
      switch (paramInt)
      {
      default: 
        paramInt = 0;
        i = 0;
      }
    } while ((i == 0) && (paramInt == 0));
    this.q.scrollBy(paramInt, i);
    return true;
    if (pe.b(this.q, -1)) {}
    for (paramInt = -(z() - B() - D());; paramInt = 0)
    {
      i = paramInt;
      int j;
      if (pe.a(this.q, -1))
      {
        j = -(y() - A() - C());
        i = paramInt;
        paramInt = j;
        break;
        if (!pe.b(this.q, 1)) {
          break label207;
        }
      }
      label207:
      for (paramInt = z() - B() - D();; paramInt = 0)
      {
        i = paramInt;
        if (pe.a(this.q, 1))
        {
          j = y();
          int k = A();
          int m = C();
          i = paramInt;
          paramInt = j - k - m;
          break;
        }
        paramInt = 0;
        break;
      }
    }
  }
  
  public boolean a(acm paramacm, acs paramacs, View paramView, int paramInt, Bundle paramBundle)
  {
    return false;
  }
  
  public int b(int paramInt, acm paramacm, acs paramacs)
  {
    return 0;
  }
  
  public int b(acm paramacm, acs paramacs)
  {
    if ((this.q == null) || (RecyclerView.f(this.q) == null)) {}
    while (!d()) {
      return 1;
    }
    return RecyclerView.f(this.q).a();
  }
  
  public int b(acs paramacs)
  {
    return 0;
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    this.f = View.MeasureSpec.getSize(paramInt1);
    this.d = View.MeasureSpec.getMode(paramInt1);
    if ((this.d == 0) && (!RecyclerView.a)) {
      this.f = 0;
    }
    this.g = View.MeasureSpec.getSize(paramInt2);
    this.e = View.MeasureSpec.getMode(paramInt2);
    if ((this.e == 0) && (!RecyclerView.a)) {
      this.g = 0;
    }
  }
  
  public void b(RecyclerView paramRecyclerView)
  {
    if (paramRecyclerView == null)
    {
      this.q = null;
      this.p = null;
      this.f = 0;
    }
    for (this.g = 0;; this.g = paramRecyclerView.getHeight())
    {
      this.d = 1073741824;
      this.e = 1073741824;
      return;
      this.q = paramRecyclerView;
      this.p = paramRecyclerView.d;
      this.f = paramRecyclerView.getWidth();
    }
  }
  
  public void b(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
  
  public void b(RecyclerView paramRecyclerView, acm paramacm)
  {
    this.s = false;
    a(paramRecyclerView, paramacm);
  }
  
  public void b(View paramView)
  {
    b(paramView, -1);
  }
  
  public void b(View paramView, int paramInt)
  {
    a(paramView, paramInt, false);
  }
  
  public void b(acm paramacm)
  {
    int j = paramacm.d();
    int i = j - 1;
    if (i >= 0)
    {
      View localView = paramacm.e(i);
      acv localacv = RecyclerView.c(localView);
      if (localacv.c()) {}
      for (;;)
      {
        i -= 1;
        break;
        localacv.a(false);
        if (localacv.r()) {
          this.q.removeDetachedView(localView, false);
        }
        if (this.q.g != null) {
          this.q.g.c(localacv);
        }
        localacv.a(true);
        paramacm.b(localView);
      }
    }
    paramacm.e();
    if (j > 0) {
      this.q.invalidate();
    }
  }
  
  public boolean b()
  {
    return false;
  }
  
  public boolean b(View paramView, int paramInt1, int paramInt2, ach paramach)
  {
    return (paramView.isLayoutRequested()) || (!this.c) || (!b(paramView.getWidth(), paramInt1, paramach.width)) || (!b(paramView.getHeight(), paramInt2, paramach.height));
  }
  
  public int c(acs paramacs)
  {
    return 0;
  }
  
  public Parcelable c()
  {
    return null;
  }
  
  public View c(int paramInt)
  {
    int j = v();
    int i = 0;
    if (i < j)
    {
      View localView = h(i);
      acv localacv = RecyclerView.c(localView);
      if (localacv == null) {}
      while ((localacv.d() != paramInt) || (localacv.c()) || ((!this.q.h.a()) && (localacv.q())))
      {
        i += 1;
        break;
      }
      return localView;
    }
    return null;
  }
  
  public void c(int paramInt1, int paramInt2)
  {
    int j = Integer.MAX_VALUE;
    int i = Integer.MIN_VALUE;
    int i5 = v();
    if (i5 == 0)
    {
      this.q.d(paramInt1, paramInt2);
      return;
    }
    int n = 0;
    int k = Integer.MIN_VALUE;
    int m = Integer.MAX_VALUE;
    int i1;
    int i3;
    int i2;
    if (n < i5)
    {
      View localView = h(n);
      ach localach = (ach)localView.getLayoutParams();
      int i4 = h(localView) - localach.leftMargin;
      i1 = j(localView);
      i3 = localach.rightMargin + i1;
      i2 = i(localView) - localach.topMargin;
      i1 = k(localView);
      i1 = localach.bottomMargin + i1;
      if (i4 >= m) {
        break label221;
      }
      m = i4;
    }
    label221:
    for (;;)
    {
      if (i3 > k) {
        k = i3;
      }
      for (;;)
      {
        if (i2 < j) {
          j = i2;
        }
        for (;;)
        {
          if (i1 > i) {
            i = i1;
          }
          for (;;)
          {
            n += 1;
            break;
            RecyclerView.s(this.q).set(m, j, k, i);
            a(RecyclerView.s(this.q), paramInt1, paramInt2);
            return;
          }
        }
      }
    }
  }
  
  public void c(RecyclerView paramRecyclerView)
  {
    this.s = true;
    d(paramRecyclerView);
  }
  
  public void c(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
  
  public void c(View paramView)
  {
    this.p.a(paramView);
  }
  
  public void c(View paramView, int paramInt)
  {
    a(paramView, paramInt, (ach)paramView.getLayoutParams());
  }
  
  public void c(acm paramacm)
  {
    int i = v() - 1;
    while (i >= 0)
    {
      if (!RecyclerView.c(h(i)).c()) {
        a(i, paramacm);
      }
      i -= 1;
    }
  }
  
  public void c(acm paramacm, acs paramacs)
  {
    Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
  }
  
  public void c(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public int d(View paramView)
  {
    return ((ach)paramView.getLayoutParams()).e();
  }
  
  public int d(acm paramacm, acs paramacs)
  {
    return 0;
  }
  
  public int d(acs paramacs)
  {
    return 0;
  }
  
  public View d(View paramView, int paramInt)
  {
    return null;
  }
  
  public void d(int paramInt) {}
  
  public void d(int paramInt1, int paramInt2)
  {
    View localView = h(paramInt1);
    if (localView == null) {
      throw new IllegalArgumentException("Cannot move a child from non-existing index:" + paramInt1);
    }
    g(paramInt1);
    c(localView, paramInt2);
  }
  
  public void d(RecyclerView paramRecyclerView) {}
  
  public boolean d()
  {
    return false;
  }
  
  public int e(acs paramacs)
  {
    return 0;
  }
  
  public View e(View paramView)
  {
    if (this.q == null) {}
    do
    {
      return null;
      paramView = this.q.b(paramView);
    } while ((paramView == null) || (this.p.c(paramView)));
    return paramView;
  }
  
  public void e(int paramInt1, int paramInt2)
  {
    RecyclerView.b(this.q, paramInt1, paramInt2);
  }
  
  @Deprecated
  public void e(RecyclerView paramRecyclerView) {}
  
  public boolean e()
  {
    return false;
  }
  
  public boolean e(acm paramacm, acs paramacs)
  {
    return false;
  }
  
  public int f(View paramView)
  {
    Rect localRect = ((ach)paramView.getLayoutParams()).b;
    int i = paramView.getMeasuredWidth();
    int j = localRect.left;
    return localRect.right + (i + j);
  }
  
  public int f(acs paramacs)
  {
    return 0;
  }
  
  public void f(int paramInt)
  {
    if (h(paramInt) != null) {
      this.p.a(paramInt);
    }
  }
  
  public void f(RecyclerView paramRecyclerView)
  {
    b(View.MeasureSpec.makeMeasureSpec(paramRecyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(paramRecyclerView.getHeight(), 1073741824));
  }
  
  public int g(View paramView)
  {
    Rect localRect = ((ach)paramView.getLayoutParams()).b;
    int i = paramView.getMeasuredHeight();
    int j = localRect.top;
    return localRect.bottom + (i + j);
  }
  
  public int g(acs paramacs)
  {
    return 0;
  }
  
  public void g(int paramInt)
  {
    a(paramInt, h(paramInt));
  }
  
  public int h(View paramView)
  {
    return paramView.getLeft() - n(paramView);
  }
  
  public View h(int paramInt)
  {
    if (this.p != null) {
      return this.p.b(paramInt);
    }
    return null;
  }
  
  public int i(View paramView)
  {
    return paramView.getTop() - l(paramView);
  }
  
  public void i(int paramInt)
  {
    if (this.q != null) {
      this.q.b(paramInt);
    }
  }
  
  public int j(View paramView)
  {
    return paramView.getRight() + o(paramView);
  }
  
  public void j(int paramInt)
  {
    if (this.q != null) {
      this.q.a(paramInt);
    }
  }
  
  public int k(View paramView)
  {
    return paramView.getBottom() + m(paramView);
  }
  
  public void k(int paramInt) {}
  
  public int l(View paramView)
  {
    return ((ach)paramView.getLayoutParams()).b.top;
  }
  
  public boolean l()
  {
    return false;
  }
  
  public int m(View paramView)
  {
    return ((ach)paramView.getLayoutParams()).b.bottom;
  }
  
  public int n(View paramView)
  {
    return ((ach)paramView.getLayoutParams()).b.left;
  }
  
  public int o(View paramView)
  {
    return ((ach)paramView.getLayoutParams()).b.right;
  }
  
  public void p()
  {
    if (this.q != null) {
      this.q.requestLayout();
    }
  }
  
  public boolean q()
  {
    return this.s;
  }
  
  public boolean r()
  {
    return (this.q != null) && (RecyclerView.t(this.q));
  }
  
  public boolean s()
  {
    return (this.r != null) && (this.r.c());
  }
  
  public int t()
  {
    return pe.h(this.q);
  }
  
  public int u()
  {
    return -1;
  }
  
  public int v()
  {
    if (this.p != null) {
      return this.p.b();
    }
    return 0;
  }
  
  public int w()
  {
    return this.d;
  }
  
  public int x()
  {
    return this.e;
  }
  
  public int y()
  {
    return this.f;
  }
  
  public int z()
  {
    return this.g;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */