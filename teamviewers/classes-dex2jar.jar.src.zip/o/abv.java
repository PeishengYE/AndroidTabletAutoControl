package o;

import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;
import java.util.List;

public abstract class abv<VH extends acv>
{
  private final abw a = new abw();
  private boolean b = false;
  
  public abstract int a();
  
  public int a(int paramInt)
  {
    return 0;
  }
  
  public abstract VH a(ViewGroup paramViewGroup, int paramInt);
  
  public final void a(int paramInt1, int paramInt2)
  {
    this.a.a(paramInt1, paramInt2);
  }
  
  public void a(RecyclerView paramRecyclerView) {}
  
  public void a(abx paramabx)
  {
    this.a.registerObserver(paramabx);
  }
  
  public void a(VH paramVH) {}
  
  public abstract void a(VH paramVH, int paramInt);
  
  public void a(VH paramVH, int paramInt, List<Object> paramList)
  {
    a(paramVH, paramInt);
  }
  
  public long b(int paramInt)
  {
    return -1L;
  }
  
  public final VH b(ViewGroup paramViewGroup, int paramInt)
  {
    km.a("RV CreateView");
    paramViewGroup = a(paramViewGroup, paramInt);
    paramViewGroup.e = paramInt;
    km.a();
    return paramViewGroup;
  }
  
  public final void b(int paramInt1, int paramInt2)
  {
    this.a.d(paramInt1, paramInt2);
  }
  
  public void b(RecyclerView paramRecyclerView) {}
  
  public void b(abx paramabx)
  {
    this.a.unregisterObserver(paramabx);
  }
  
  public final void b(VH paramVH, int paramInt)
  {
    paramVH.b = paramInt;
    if (b()) {
      paramVH.d = b(paramInt);
    }
    paramVH.a(1, 519);
    km.a("RV OnBindView");
    a(paramVH, paramInt, paramVH.u());
    paramVH.t();
    km.a();
  }
  
  public final boolean b()
  {
    return this.b;
  }
  
  public boolean b(VH paramVH)
  {
    return false;
  }
  
  public final void c()
  {
    this.a.a();
  }
  
  public final void c(int paramInt)
  {
    this.a.b(paramInt, 1);
  }
  
  public final void c(int paramInt1, int paramInt2)
  {
    this.a.b(paramInt1, paramInt2);
  }
  
  public void c(VH paramVH) {}
  
  public final void d(int paramInt)
  {
    this.a.c(paramInt, 1);
  }
  
  public final void d(int paramInt1, int paramInt2)
  {
    this.a.c(paramInt1, paramInt2);
  }
  
  public void d(VH paramVH) {}
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */