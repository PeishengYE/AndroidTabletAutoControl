package o;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

public class abt
  implements zt
{
  public abt(RecyclerView paramRecyclerView) {}
  
  public int a()
  {
    return this.a.getChildCount();
  }
  
  public int a(View paramView)
  {
    return this.a.indexOfChild(paramView);
  }
  
  public void a(int paramInt)
  {
    View localView = this.a.getChildAt(paramInt);
    if (localView != null) {
      RecyclerView.b(this.a, localView);
    }
    this.a.removeViewAt(paramInt);
  }
  
  public void a(View paramView, int paramInt)
  {
    this.a.addView(paramView, paramInt);
    RecyclerView.a(this.a, paramView);
  }
  
  public void a(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    acv localacv = RecyclerView.c(paramView);
    if (localacv != null)
    {
      if ((!localacv.r()) && (!localacv.c())) {
        throw new IllegalArgumentException("Called attach on a child which is not detached: " + localacv);
      }
      localacv.m();
    }
    RecyclerView.a(this.a, paramView, paramInt, paramLayoutParams);
  }
  
  public View b(int paramInt)
  {
    return this.a.getChildAt(paramInt);
  }
  
  public acv b(View paramView)
  {
    return RecyclerView.c(paramView);
  }
  
  public void b()
  {
    int j = a();
    int i = 0;
    while (i < j)
    {
      RecyclerView.b(this.a, b(i));
      i += 1;
    }
    this.a.removeAllViews();
  }
  
  public void c(int paramInt)
  {
    Object localObject = b(paramInt);
    if (localObject != null)
    {
      localObject = RecyclerView.c((View)localObject);
      if (localObject != null)
      {
        if ((((acv)localObject).r()) && (!((acv)localObject).c())) {
          throw new IllegalArgumentException("called detach on an already detached child " + localObject);
        }
        ((acv)localObject).b(256);
      }
    }
    RecyclerView.a(this.a, paramInt);
  }
  
  public void c(View paramView)
  {
    paramView = RecyclerView.c(paramView);
    if (paramView != null) {
      acv.a(paramView);
    }
  }
  
  public void d(View paramView)
  {
    paramView = RecyclerView.c(paramView);
    if (paramView != null) {
      acv.b(paramView);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */