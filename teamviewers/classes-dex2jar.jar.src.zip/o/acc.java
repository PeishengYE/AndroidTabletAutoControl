package o;

import android.view.View;

public class acc
{
  public int a;
  public int b;
  public int c;
  public int d;
  
  public acc a(acv paramacv)
  {
    return a(paramacv, 0);
  }
  
  public acc a(acv paramacv, int paramInt)
  {
    paramacv = paramacv.a;
    this.a = paramacv.getLeft();
    this.b = paramacv.getTop();
    this.c = paramacv.getRight();
    this.d = paramacv.getBottom();
    return this;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */