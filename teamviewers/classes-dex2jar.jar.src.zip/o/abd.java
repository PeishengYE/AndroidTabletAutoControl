package o;

class abd
  implements Runnable
{
  private abd(aav paramaav) {}
  
  public void run()
  {
    this.a.j();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */