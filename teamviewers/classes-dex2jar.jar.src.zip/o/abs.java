package o;

import android.support.v7.widget.RecyclerView;

public class abs
  implements aem
{
  public abs(RecyclerView paramRecyclerView) {}
  
  public void a(acv paramacv)
  {
    this.a.f.a(paramacv.a, this.a.b);
  }
  
  public void a(acv paramacv, acc paramacc1, acc paramacc2)
  {
    this.a.b.d(paramacv);
    RecyclerView.a(this.a, paramacv, paramacc1, paramacc2);
  }
  
  public void b(acv paramacv, acc paramacc1, acc paramacc2)
  {
    RecyclerView.b(this.a, paramacv, paramacc1, paramacc2);
  }
  
  public void c(acv paramacv, acc paramacc1, acc paramacc2)
  {
    paramacv.a(false);
    if (RecyclerView.d(this.a)) {
      if (this.a.g.a(paramacv, paramacv, paramacc1, paramacc2)) {
        RecyclerView.e(this.a);
      }
    }
    while (!this.a.g.c(paramacv, paramacc1, paramacc2)) {
      return;
    }
    RecyclerView.e(this.a);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */