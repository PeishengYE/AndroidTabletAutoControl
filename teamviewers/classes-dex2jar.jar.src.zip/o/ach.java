package o;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class ach
  extends ViewGroup.MarginLayoutParams
{
  public acv a;
  public final Rect b = new Rect();
  public boolean c = true;
  boolean d = false;
  
  public ach(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }
  
  public ach(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public ach(ViewGroup.LayoutParams paramLayoutParams)
  {
    super(paramLayoutParams);
  }
  
  public ach(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    super(paramMarginLayoutParams);
  }
  
  public ach(ach paramach)
  {
    super(paramach);
  }
  
  public boolean c()
  {
    return this.a.q();
  }
  
  public boolean d()
  {
    return this.a.x();
  }
  
  public int e()
  {
    return this.a.d();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/ach.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */