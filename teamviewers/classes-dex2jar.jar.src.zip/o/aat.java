package o;

import android.view.View;
import java.util.List;

public class aat
{
  public boolean a = true;
  public int b;
  public int c;
  public int d;
  public int e;
  public int f;
  public int g;
  public int h = 0;
  public boolean i = false;
  public int j;
  public List<acv> k = null;
  public boolean l;
  
  private View b()
  {
    int n = this.k.size();
    int m = 0;
    if (m < n)
    {
      View localView = ((acv)this.k.get(m)).a;
      ach localach = (ach)localView.getLayoutParams();
      if (localach.c()) {}
      while (this.d != localach.e())
      {
        m += 1;
        break;
      }
      a(localView);
      return localView;
    }
    return null;
  }
  
  public View a(acm paramacm)
  {
    if (this.k != null) {
      return b();
    }
    paramacm = paramacm.c(this.d);
    this.d += this.e;
    return paramacm;
  }
  
  public void a()
  {
    a(null);
  }
  
  public void a(View paramView)
  {
    paramView = b(paramView);
    if (paramView == null)
    {
      this.d = -1;
      return;
    }
    this.d = ((ach)paramView.getLayoutParams()).e();
  }
  
  public boolean a(acs paramacs)
  {
    return (this.d >= 0) && (this.d < paramacs.e());
  }
  
  public View b(View paramView)
  {
    int i2 = this.k.size();
    Object localObject = null;
    int m = Integer.MAX_VALUE;
    int n = 0;
    if (n < i2)
    {
      View localView = ((acv)this.k.get(n)).a;
      ach localach = (ach)localView.getLayoutParams();
      if (localView != paramView) {
        if (!localach.c()) {}
      }
      for (;;)
      {
        n += 1;
        break;
        int i1 = (localach.e() - this.d) * this.e;
        if (i1 >= 0) {
          if (i1 < m)
          {
            if (i1 == 0) {
              return localView;
            }
            localObject = localView;
            m = i1;
          }
        }
      }
    }
    return (View)localObject;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */