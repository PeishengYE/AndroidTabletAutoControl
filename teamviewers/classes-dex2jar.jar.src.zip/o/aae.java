package o;

import android.view.View;
import java.util.ArrayList;

class aae
  extends aah
{
  aae(zw paramzw, aaf paramaaf, qr paramqr, View paramView)
  {
    super(null);
  }
  
  public void a(View paramView)
  {
    this.d.b(this.a.b, false);
  }
  
  public void b(View paramView)
  {
    this.b.a(null);
    pe.c(this.c, 1.0F);
    pe.a(this.c, 0.0F);
    pe.b(this.c, 0.0F);
    this.d.a(this.a.b, false);
    zw.h(this.d).remove(this.a.b);
    zw.e(this.d);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */