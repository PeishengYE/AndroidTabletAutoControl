package o;

import android.view.View;

final class abo
  extends abm
{
  abo(acf paramacf)
  {
    super(paramacf, null);
  }
  
  public int a(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    return this.a.i(paramView) - localach.topMargin;
  }
  
  public void a(int paramInt)
  {
    this.a.j(paramInt);
  }
  
  public int b(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.k(paramView);
    return localach.bottomMargin + i;
  }
  
  public int c()
  {
    return this.a.B();
  }
  
  public int c(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.g(paramView);
    int j = localach.topMargin;
    return localach.bottomMargin + (i + j);
  }
  
  public int d()
  {
    return this.a.z() - this.a.D();
  }
  
  public int d(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.f(paramView);
    int j = localach.leftMargin;
    return localach.rightMargin + (i + j);
  }
  
  public int e()
  {
    return this.a.z();
  }
  
  public int f()
  {
    return this.a.z() - this.a.B() - this.a.D();
  }
  
  public int g()
  {
    return this.a.D();
  }
  
  public int h()
  {
    return this.a.x();
  }
  
  public int i()
  {
    return this.a.w();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */