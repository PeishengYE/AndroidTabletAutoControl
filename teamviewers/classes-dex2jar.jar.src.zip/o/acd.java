package o;

import android.support.v7.widget.RecyclerView;

public class acd
  implements acb
{
  private acd(RecyclerView paramRecyclerView) {}
  
  public void a(acv paramacv)
  {
    paramacv.a(true);
    if ((paramacv.g != null) && (paramacv.h == null)) {
      paramacv.g = null;
    }
    paramacv.h = null;
    if ((!acv.e(paramacv)) && (!RecyclerView.c(this.a, paramacv.a)) && (paramacv.r())) {
      this.a.removeDetachedView(paramacv.a, false);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */