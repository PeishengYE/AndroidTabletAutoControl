package o;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class acm
{
  final ArrayList<acv> a = new ArrayList();
  final ArrayList<acv> b = new ArrayList();
  private ArrayList<acv> d = null;
  private final List<acv> e = Collections.unmodifiableList(this.a);
  private int f = 2;
  private acl g;
  private act h;
  
  public acm(RecyclerView paramRecyclerView) {}
  
  private void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    int i = paramViewGroup.getChildCount() - 1;
    while (i >= 0)
    {
      View localView = paramViewGroup.getChildAt(i);
      if ((localView instanceof ViewGroup)) {
        a((ViewGroup)localView, true);
      }
      i -= 1;
    }
    if (!paramBoolean) {
      return;
    }
    if (paramViewGroup.getVisibility() == 4)
    {
      paramViewGroup.setVisibility(0);
      paramViewGroup.setVisibility(4);
      return;
    }
    i = paramViewGroup.getVisibility();
    paramViewGroup.setVisibility(4);
    paramViewGroup.setVisibility(i);
  }
  
  private void d(View paramView)
  {
    if (this.c.i())
    {
      if (pe.e(paramView) == 0) {
        pe.c(paramView, 1);
      }
      if (!pe.b(paramView)) {
        pe.a(paramView, RecyclerView.q(this.c).b());
      }
    }
  }
  
  private void f(acv paramacv)
  {
    if ((paramacv.a instanceof ViewGroup)) {
      a((ViewGroup)paramacv.a, false);
    }
  }
  
  View a(int paramInt, boolean paramBoolean)
  {
    boolean bool = true;
    if ((paramInt < 0) || (paramInt >= this.c.h.e())) {
      throw new IndexOutOfBoundsException("Invalid item position " + paramInt + "(" + paramInt + "). Item count:" + this.c.h.e());
    }
    Object localObject2;
    int i;
    if (this.c.h.a())
    {
      localObject2 = f(paramInt);
      if (localObject2 != null) {
        i = 1;
      }
    }
    for (;;)
    {
      Object localObject1 = localObject2;
      if (localObject2 == null)
      {
        localObject2 = a(paramInt, -1, paramBoolean);
        localObject1 = localObject2;
        if (localObject2 != null) {
          if (!a((acv)localObject2)) {
            if (!paramBoolean)
            {
              ((acv)localObject2).b(4);
              if (((acv)localObject2).i())
              {
                this.c.removeDetachedView(((acv)localObject2).a, false);
                ((acv)localObject2).j();
                label174:
                b((acv)localObject2);
              }
            }
            else
            {
              localObject1 = null;
            }
          }
        }
      }
      for (;;)
      {
        Object localObject3 = localObject1;
        int k = i;
        int j;
        if (localObject1 == null)
        {
          k = this.c.c.b(paramInt);
          if ((k < 0) || (k >= RecyclerView.f(this.c).a()))
          {
            throw new IndexOutOfBoundsException("Inconsistency detected. Invalid item position " + paramInt + "(offset:" + k + ")." + "state:" + this.c.h.e());
            i = 0;
            break;
            if (!((acv)localObject2).k()) {
              break label174;
            }
            ((acv)localObject2).l();
            break label174;
            i = 1;
            localObject1 = localObject2;
            continue;
          }
          int m = RecyclerView.f(this.c).a(k);
          localObject2 = localObject1;
          j = i;
          if (RecyclerView.f(this.c).b())
          {
            localObject1 = a(RecyclerView.f(this.c).b(k), m, paramBoolean);
            localObject2 = localObject1;
            j = i;
            if (localObject1 != null)
            {
              ((acv)localObject1).b = k;
              j = 1;
              localObject2 = localObject1;
            }
          }
          localObject1 = localObject2;
          if (localObject2 == null)
          {
            localObject1 = localObject2;
            if (this.h != null)
            {
              localObject3 = this.h.a(this, paramInt, m);
              localObject1 = localObject2;
              if (localObject3 != null)
              {
                localObject2 = this.c.a((View)localObject3);
                if (localObject2 == null) {
                  throw new IllegalArgumentException("getViewForPositionAndType returned a view which does not have a ViewHolder");
                }
                localObject1 = localObject2;
                if (((acv)localObject2).c()) {
                  throw new IllegalArgumentException("getViewForPositionAndType returned a view that is ignored. You must call stopIgnoring before returning this view.");
                }
              }
            }
          }
          localObject2 = localObject1;
          if (localObject1 == null)
          {
            localObject1 = f().a(m);
            localObject2 = localObject1;
            if (localObject1 != null)
            {
              ((acv)localObject1).v();
              localObject2 = localObject1;
              if (RecyclerView.r())
              {
                f((acv)localObject1);
                localObject2 = localObject1;
              }
            }
          }
          localObject3 = localObject2;
          k = j;
          if (localObject2 == null) {
            localObject2 = RecyclerView.f(this.c).b(this.c, m);
          }
        }
        for (i = j;; i = k)
        {
          if ((i != 0) && (!this.c.h.a()) && (((acv)localObject2).a(8192)))
          {
            ((acv)localObject2).a(0, 8192);
            if (acs.c(this.c.h))
            {
              j = abz.d((acv)localObject2);
              localObject1 = this.c.g.a(this.c.h, (acv)localObject2, j | 0x1000, ((acv)localObject2).u());
              RecyclerView.a(this.c, (acv)localObject2, (acc)localObject1);
            }
          }
          if ((this.c.h.a()) && (((acv)localObject2).p()))
          {
            ((acv)localObject2).f = paramInt;
            paramInt = 0;
          }
          for (;;)
          {
            localObject1 = ((acv)localObject2).a.getLayoutParams();
            if (localObject1 == null)
            {
              localObject1 = (ach)this.c.generateDefaultLayoutParams();
              ((acv)localObject2).a.setLayoutParams((ViewGroup.LayoutParams)localObject1);
              label743:
              ((ach)localObject1).a = ((acv)localObject2);
              if ((i == 0) || (paramInt == 0)) {
                break label915;
              }
            }
            label915:
            for (paramBoolean = bool;; paramBoolean = false)
            {
              ((ach)localObject1).d = paramBoolean;
              return ((acv)localObject2).a;
              if ((((acv)localObject2).p()) && (!((acv)localObject2).o()) && (!((acv)localObject2).n())) {
                break label920;
              }
              j = this.c.c.b(paramInt);
              ((acv)localObject2).k = this.c;
              RecyclerView.f(this.c).b((acv)localObject2, j);
              d(((acv)localObject2).a);
              if (this.c.h.a()) {
                ((acv)localObject2).f = paramInt;
              }
              paramInt = 1;
              break;
              if (!this.c.checkLayoutParams((ViewGroup.LayoutParams)localObject1))
              {
                localObject1 = (ach)this.c.generateLayoutParams((ViewGroup.LayoutParams)localObject1);
                ((acv)localObject2).a.setLayoutParams((ViewGroup.LayoutParams)localObject1);
                break label743;
              }
              localObject1 = (ach)localObject1;
              break label743;
            }
            label920:
            paramInt = 0;
          }
          localObject2 = localObject3;
        }
      }
      localObject2 = null;
      i = 0;
    }
  }
  
  acv a(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int j = 0;
    int k = this.a.size();
    int i = 0;
    Object localObject;
    acv localacv;
    for (;;)
    {
      if (i < k)
      {
        localObject = (acv)this.a.get(i);
        if ((((acv)localObject).k()) || (((acv)localObject).d() != paramInt1) || (((acv)localObject).n()) || ((!acs.f(this.c.h)) && (((acv)localObject).q()))) {
          break label258;
        }
        if ((paramInt2 != -1) && (((acv)localObject).h() != paramInt2)) {
          Log.e("RecyclerView", "Scrap view for position " + paramInt1 + " isn't dirty but has" + " wrong view type! (found " + ((acv)localObject).h() + " but expected " + paramInt2 + ")");
        }
      }
      else
      {
        if (paramBoolean) {
          break label295;
        }
        localObject = this.c.d.a(paramInt1, paramInt2);
        if (localObject == null) {
          break label295;
        }
        localacv = RecyclerView.c((View)localObject);
        this.c.d.e((View)localObject);
        paramInt1 = this.c.d.b((View)localObject);
        if (paramInt1 != -1) {
          break;
        }
        throw new IllegalStateException("layout index should not be -1 after unhiding a view:" + localacv);
      }
      ((acv)localObject).b(32);
      return (acv)localObject;
      label258:
      i += 1;
    }
    this.c.d.d(paramInt1);
    c((View)localObject);
    localacv.b(8224);
    return localacv;
    label295:
    i = this.b.size();
    paramInt2 = j;
    for (;;)
    {
      if (paramInt2 >= i) {
        break label370;
      }
      localacv = (acv)this.b.get(paramInt2);
      if ((!localacv.n()) && (localacv.d() == paramInt1))
      {
        localObject = localacv;
        if (paramBoolean) {
          break;
        }
        this.b.remove(paramInt2);
        return localacv;
      }
      paramInt2 += 1;
    }
    label370:
    return null;
  }
  
  acv a(long paramLong, int paramInt, boolean paramBoolean)
  {
    int i = this.a.size() - 1;
    acv localacv2;
    acv localacv1;
    while (i >= 0)
    {
      localacv2 = (acv)this.a.get(i);
      if ((localacv2.g() == paramLong) && (!localacv2.k()))
      {
        if (paramInt == localacv2.h())
        {
          localacv2.b(32);
          localacv1 = localacv2;
          if (localacv2.q())
          {
            localacv1 = localacv2;
            if (!this.c.h.a())
            {
              localacv2.a(2, 14);
              localacv1 = localacv2;
            }
          }
          return localacv1;
        }
        if (!paramBoolean)
        {
          this.a.remove(i);
          this.c.removeDetachedView(localacv2.a, false);
          b(localacv2.a);
        }
      }
      i -= 1;
    }
    i = this.b.size() - 1;
    for (;;)
    {
      if (i < 0) {
        break label245;
      }
      localacv2 = (acv)this.b.get(i);
      if (localacv2.g() == paramLong)
      {
        if (paramInt == localacv2.h())
        {
          localacv1 = localacv2;
          if (paramBoolean) {
            break;
          }
          this.b.remove(i);
          return localacv2;
        }
        if (!paramBoolean) {
          d(i);
        }
      }
      i -= 1;
    }
    label245:
    return null;
  }
  
  public void a()
  {
    this.a.clear();
    c();
  }
  
  public void a(int paramInt)
  {
    this.f = paramInt;
    int i = this.b.size() - 1;
    while ((i >= 0) && (this.b.size() > paramInt))
    {
      d(i);
      i -= 1;
    }
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    int i;
    int j;
    int k;
    int m;
    label25:
    acv localacv;
    if (paramInt1 < paramInt2)
    {
      i = -1;
      j = paramInt2;
      k = paramInt1;
      int n = this.b.size();
      m = 0;
      if (m >= n) {
        return;
      }
      localacv = (acv)this.b.get(m);
      if ((localacv != null) && (localacv.b >= k) && (localacv.b <= j)) {
        break label91;
      }
    }
    for (;;)
    {
      m += 1;
      break label25;
      i = 1;
      j = paramInt1;
      k = paramInt2;
      break;
      label91:
      if (localacv.b == paramInt1) {
        localacv.a(paramInt2 - paramInt1, false);
      } else {
        localacv.a(i, false);
      }
    }
  }
  
  public void a(View paramView)
  {
    acv localacv = RecyclerView.c(paramView);
    if (localacv.r()) {
      this.c.removeDetachedView(paramView, false);
    }
    if (localacv.i()) {
      localacv.j();
    }
    for (;;)
    {
      b(localacv);
      return;
      if (localacv.k()) {
        localacv.l();
      }
    }
  }
  
  public void a(abv paramabv1, abv paramabv2, boolean paramBoolean)
  {
    a();
    f().a(paramabv1, paramabv2, paramBoolean);
  }
  
  public void a(acl paramacl)
  {
    if (this.g != null) {
      this.g.b();
    }
    this.g = paramacl;
    if (paramacl != null) {
      this.g.a(this.c.getAdapter());
    }
  }
  
  public void a(act paramact)
  {
    this.h = paramact;
  }
  
  boolean a(acv paramacv)
  {
    boolean bool2 = true;
    boolean bool1;
    if (paramacv.q()) {
      bool1 = this.c.h.a();
    }
    do
    {
      do
      {
        return bool1;
        if ((paramacv.b < 0) || (paramacv.b >= RecyclerView.f(this.c).a())) {
          throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + paramacv);
        }
        if ((!this.c.h.a()) && (RecyclerView.f(this.c).a(paramacv.b) != paramacv.h())) {
          return false;
        }
        bool1 = bool2;
      } while (!RecyclerView.f(this.c).b());
      bool1 = bool2;
    } while (paramacv.g() == RecyclerView.f(this.c).b(paramacv.b));
    return false;
  }
  
  public int b(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.c.h.e())) {
      throw new IndexOutOfBoundsException("invalid position " + paramInt + ". State " + "item count is " + this.c.h.e());
    }
    if (!this.c.h.a()) {
      return paramInt;
    }
    return this.c.c.b(paramInt);
  }
  
  public List<acv> b()
  {
    return this.e;
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      acv localacv = (acv)this.b.get(i);
      if ((localacv != null) && (localacv.b >= paramInt1)) {
        localacv.a(paramInt2, true);
      }
      i += 1;
    }
  }
  
  public void b(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = this.b.size() - 1;
    if (i >= 0)
    {
      acv localacv = (acv)this.b.get(i);
      if (localacv != null)
      {
        if (localacv.b < paramInt1 + paramInt2) {
          break label63;
        }
        localacv.a(-paramInt2, paramBoolean);
      }
      for (;;)
      {
        i -= 1;
        break;
        label63:
        if (localacv.b >= paramInt1)
        {
          localacv.b(8);
          d(i);
        }
      }
    }
  }
  
  void b(View paramView)
  {
    paramView = RecyclerView.c(paramView);
    acv.a(paramView, null);
    acv.a(paramView, false);
    paramView.l();
    b(paramView);
  }
  
  public void b(acv paramacv)
  {
    boolean bool = true;
    int j = 0;
    if ((paramacv.i()) || (paramacv.a.getParent() != null))
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Scrapped or attached views may not be recycled. isScrap:").append(paramacv.i()).append(" isAttached:");
      if (paramacv.a.getParent() != null) {}
      for (;;)
      {
        throw new IllegalArgumentException(bool);
        bool = false;
      }
    }
    if (paramacv.r()) {
      throw new IllegalArgumentException("Tmp detached view should be removed from RecyclerView before it can be recycled: " + paramacv);
    }
    if (paramacv.c()) {
      throw new IllegalArgumentException("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
    }
    bool = acv.c(paramacv);
    int i;
    if ((RecyclerView.f(this.c) != null) && (bool) && (RecyclerView.f(this.c).b(paramacv)))
    {
      i = 1;
      if ((i == 0) && (!paramacv.w())) {
        break label292;
      }
      if (paramacv.a(14)) {
        break label287;
      }
      i = this.b.size();
      if ((i == this.f) && (i > 0)) {
        d(0);
      }
      if (i >= this.f) {
        break label287;
      }
      this.b.add(paramacv);
      i = 1;
      label238:
      if (i != 0) {
        break label284;
      }
      c(paramacv);
      j = 1;
    }
    for (;;)
    {
      this.c.e.g(paramacv);
      if ((i == 0) && (j == 0) && (bool)) {
        paramacv.k = null;
      }
      return;
      i = 0;
      break;
      label284:
      continue;
      label287:
      i = 0;
      break label238;
      label292:
      i = 0;
    }
  }
  
  public View c(int paramInt)
  {
    return a(paramInt, false);
  }
  
  void c()
  {
    int i = this.b.size() - 1;
    while (i >= 0)
    {
      d(i);
      i -= 1;
    }
    this.b.clear();
  }
  
  public void c(int paramInt1, int paramInt2)
  {
    int i = this.b.size() - 1;
    if (i >= 0)
    {
      acv localacv = (acv)this.b.get(i);
      if (localacv == null) {}
      for (;;)
      {
        i -= 1;
        break;
        int j = localacv.d();
        if ((j >= paramInt1) && (j < paramInt1 + paramInt2))
        {
          localacv.b(2);
          d(i);
        }
      }
    }
  }
  
  void c(View paramView)
  {
    paramView = RecyclerView.c(paramView);
    if ((paramView.a(12)) || (!paramView.x()) || (RecyclerView.a(this.c, paramView)))
    {
      if ((paramView.n()) && (!paramView.q()) && (!RecyclerView.f(this.c).b())) {
        throw new IllegalArgumentException("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
      }
      paramView.a(this, false);
      this.a.add(paramView);
      return;
    }
    if (this.d == null) {
      this.d = new ArrayList();
    }
    paramView.a(this, true);
    this.d.add(paramView);
  }
  
  void c(acv paramacv)
  {
    pe.a(paramacv.a, null);
    e(paramacv);
    paramacv.k = null;
    f().a(paramacv);
  }
  
  int d()
  {
    return this.a.size();
  }
  
  void d(int paramInt)
  {
    c((acv)this.b.get(paramInt));
    this.b.remove(paramInt);
  }
  
  public void d(acv paramacv)
  {
    if (acv.d(paramacv)) {
      this.d.remove(paramacv);
    }
    for (;;)
    {
      acv.a(paramacv, null);
      acv.a(paramacv, false);
      paramacv.l();
      return;
      this.a.remove(paramacv);
    }
  }
  
  View e(int paramInt)
  {
    return ((acv)this.a.get(paramInt)).a;
  }
  
  void e()
  {
    this.a.clear();
    if (this.d != null) {
      this.d.clear();
    }
  }
  
  void e(acv paramacv)
  {
    if (RecyclerView.r(this.c) != null) {
      RecyclerView.r(this.c).a(paramacv);
    }
    if (RecyclerView.f(this.c) != null) {
      RecyclerView.f(this.c).a(paramacv);
    }
    if (this.c.h != null) {
      this.c.e.g(paramacv);
    }
  }
  
  public acl f()
  {
    if (this.g == null) {
      this.g = new acl();
    }
    return this.g;
  }
  
  acv f(int paramInt)
  {
    int j = 0;
    int k;
    if (this.d != null)
    {
      k = this.d.size();
      if (k != 0) {}
    }
    else
    {
      return null;
    }
    int i = 0;
    acv localacv;
    while (i < k)
    {
      localacv = (acv)this.d.get(i);
      if ((!localacv.k()) && (localacv.d() == paramInt))
      {
        localacv.b(32);
        return localacv;
      }
      i += 1;
    }
    if (RecyclerView.f(this.c).b())
    {
      paramInt = this.c.c.b(paramInt);
      if ((paramInt > 0) && (paramInt < RecyclerView.f(this.c).a()))
      {
        long l = RecyclerView.f(this.c).b(paramInt);
        paramInt = j;
        while (paramInt < k)
        {
          localacv = (acv)this.d.get(paramInt);
          if ((!localacv.k()) && (localacv.g() == l))
          {
            localacv.b(32);
            return localacv;
          }
          paramInt += 1;
        }
      }
    }
    return null;
  }
  
  public void g()
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      acv localacv = (acv)this.b.get(i);
      if (localacv != null) {
        localacv.b(512);
      }
      i += 1;
    }
  }
  
  public void h()
  {
    int j;
    int i;
    if ((RecyclerView.f(this.c) != null) && (RecyclerView.f(this.c).b()))
    {
      j = this.b.size();
      i = 0;
    }
    while (i < j)
    {
      acv localacv = (acv)this.b.get(i);
      if (localacv != null)
      {
        localacv.b(6);
        localacv.a(null);
      }
      i += 1;
      continue;
      c();
    }
  }
  
  public void i()
  {
    int j = 0;
    int k = this.b.size();
    int i = 0;
    while (i < k)
    {
      ((acv)this.b.get(i)).a();
      i += 1;
    }
    k = this.a.size();
    i = 0;
    while (i < k)
    {
      ((acv)this.a.get(i)).a();
      i += 1;
    }
    if (this.d != null)
    {
      k = this.d.size();
      i = j;
      while (i < k)
      {
        ((acv)this.d.get(i)).a();
        i += 1;
      }
    }
  }
  
  public void j()
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      ach localach = (ach)((acv)this.b.get(i)).a.getLayoutParams();
      if (localach != null) {
        localach.c = true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */