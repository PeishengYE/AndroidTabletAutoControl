package o;

import android.view.View;
import java.util.ArrayList;

class aac
  extends aah
{
  aac(zw paramzw, acv paramacv, int paramInt1, int paramInt2, qr paramqr)
  {
    super(null);
  }
  
  public void a(View paramView)
  {
    this.e.l(this.a);
  }
  
  public void b(View paramView)
  {
    this.d.a(null);
    this.e.i(this.a);
    zw.g(this.e).remove(this.a);
    zw.e(this.e);
  }
  
  public void c(View paramView)
  {
    if (this.b != 0) {
      pe.a(paramView, 0.0F);
    }
    if (this.c != 0) {
      pe.b(paramView, 0.0F);
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */