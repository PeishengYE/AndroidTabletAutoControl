package o;

class abc
  implements Runnable
{
  private abc(aba paramaba) {}
  
  public void run()
  {
    aba.b(this.a);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */