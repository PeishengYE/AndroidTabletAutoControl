package o;

import android.support.v7.widget.RecyclerView;

public class abu
  implements yt
{
  public abu(RecyclerView paramRecyclerView) {}
  
  public acv a(int paramInt)
  {
    acv localacv = this.a.a(paramInt, true);
    if (localacv == null) {}
    while (this.a.d.c(localacv.a)) {
      return null;
    }
    return localacv;
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    this.a.a(paramInt1, paramInt2, true);
    this.a.i = true;
    acs.a(this.a.h, paramInt2);
  }
  
  public void a(int paramInt1, int paramInt2, Object paramObject)
  {
    this.a.a(paramInt1, paramInt2, paramObject);
    this.a.j = true;
  }
  
  public void a(yu paramyu)
  {
    c(paramyu);
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    this.a.a(paramInt1, paramInt2, false);
    this.a.i = true;
  }
  
  public void b(yu paramyu)
  {
    c(paramyu);
  }
  
  public void c(int paramInt1, int paramInt2)
  {
    this.a.f(paramInt1, paramInt2);
    this.a.i = true;
  }
  
  void c(yu paramyu)
  {
    switch (paramyu.a)
    {
    case 3: 
    case 5: 
    case 6: 
    case 7: 
    default: 
      return;
    case 1: 
      this.a.f.a(this.a, paramyu.b, paramyu.d);
      return;
    case 2: 
      this.a.f.b(this.a, paramyu.b, paramyu.d);
      return;
    case 4: 
      this.a.f.a(this.a, paramyu.b, paramyu.d, paramyu.c);
      return;
    }
    this.a.f.a(this.a, paramyu.b, paramyu.d, 1);
  }
  
  public void d(int paramInt1, int paramInt2)
  {
    this.a.e(paramInt1, paramInt2);
    this.a.i = true;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */