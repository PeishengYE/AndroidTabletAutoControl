package o;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

public class aam
  extends ach
{
  private int e = -1;
  private int f = 0;
  
  public aam(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }
  
  public aam(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public aam(ViewGroup.LayoutParams paramLayoutParams)
  {
    super(paramLayoutParams);
  }
  
  public aam(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    super(paramMarginLayoutParams);
  }
  
  public int a()
  {
    return this.e;
  }
  
  public int b()
  {
    return this.f;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */