package o;

import android.view.View;
import java.util.ArrayList;

class aaa
  extends aah
{
  aaa(zw paramzw, acv paramacv, qr paramqr)
  {
    super(null);
  }
  
  public void a(View paramView)
  {
    this.c.k(this.a);
  }
  
  public void b(View paramView)
  {
    this.b.a(null);
    pe.c(paramView, 1.0F);
    this.c.h(this.a);
    zw.d(this.c).remove(this.a);
    zw.e(this.c);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aaa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */