package o;

import android.view.View;
import java.util.ArrayList;

class aad
  extends aah
{
  aad(zw paramzw, aaf paramaaf, qr paramqr)
  {
    super(null);
  }
  
  public void a(View paramView)
  {
    this.c.b(this.a.a, true);
  }
  
  public void b(View paramView)
  {
    this.b.a(null);
    pe.c(paramView, 1.0F);
    pe.a(paramView, 0.0F);
    pe.b(paramView, 0.0F);
    this.c.a(this.a.a, true);
    zw.h(this.c).remove(this.a.a);
    zw.e(this.c);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */