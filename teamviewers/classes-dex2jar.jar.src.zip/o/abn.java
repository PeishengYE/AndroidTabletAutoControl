package o;

import android.view.View;

final class abn
  extends abm
{
  abn(acf paramacf)
  {
    super(paramacf, null);
  }
  
  public int a(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    return this.a.h(paramView) - localach.leftMargin;
  }
  
  public void a(int paramInt)
  {
    this.a.i(paramInt);
  }
  
  public int b(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.j(paramView);
    return localach.rightMargin + i;
  }
  
  public int c()
  {
    return this.a.A();
  }
  
  public int c(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.f(paramView);
    int j = localach.leftMargin;
    return localach.rightMargin + (i + j);
  }
  
  public int d()
  {
    return this.a.y() - this.a.C();
  }
  
  public int d(View paramView)
  {
    ach localach = (ach)paramView.getLayoutParams();
    int i = this.a.g(paramView);
    int j = localach.topMargin;
    return localach.bottomMargin + (i + j);
  }
  
  public int e()
  {
    return this.a.y();
  }
  
  public int f()
  {
    return this.a.y() - this.a.A() - this.a.C();
  }
  
  public int g()
  {
    return this.a.C();
  }
  
  public int h()
  {
    return this.a.w();
  }
  
  public int i()
  {
    return this.a.x();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */