package o;

import android.view.View;

public abstract class abm
{
  protected final acf a;
  private int b = Integer.MIN_VALUE;
  
  private abm(acf paramacf)
  {
    this.a = paramacf;
  }
  
  public static abm a(acf paramacf)
  {
    return new abn(paramacf);
  }
  
  public static abm a(acf paramacf, int paramInt)
  {
    switch (paramInt)
    {
    default: 
      throw new IllegalArgumentException("invalid orientation");
    case 0: 
      return a(paramacf);
    }
    return b(paramacf);
  }
  
  public static abm b(acf paramacf)
  {
    return new abo(paramacf);
  }
  
  public abstract int a(View paramView);
  
  public void a()
  {
    this.b = f();
  }
  
  public abstract void a(int paramInt);
  
  public int b()
  {
    if (Integer.MIN_VALUE == this.b) {
      return 0;
    }
    return f() - this.b;
  }
  
  public abstract int b(View paramView);
  
  public abstract int c();
  
  public abstract int c(View paramView);
  
  public abstract int d();
  
  public abstract int d(View paramView);
  
  public abstract int e();
  
  public abstract int f();
  
  public abstract int g();
  
  public abstract int h();
  
  public abstract int i();
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */