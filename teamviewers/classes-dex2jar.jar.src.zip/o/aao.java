package o;

import android.view.View;

public class aao
{
  public boolean a = true;
  public int b;
  public int c;
  public int d;
  public int e;
  public int f = 0;
  public int g = 0;
  public boolean h;
  public boolean i;
  
  public View a(acm paramacm)
  {
    paramacm = paramacm.c(this.c);
    this.c += this.d;
    return paramacm;
  }
  
  public boolean a(acs paramacs)
  {
    return (this.c >= 0) && (this.c < paramacs.e());
  }
  
  public String toString()
  {
    return "LayoutState{mAvailable=" + this.b + ", mCurrentPosition=" + this.c + ", mItemDirection=" + this.d + ", mLayoutDirection=" + this.e + ", mStartLine=" + this.f + ", mEndLine=" + this.g + '}';
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */