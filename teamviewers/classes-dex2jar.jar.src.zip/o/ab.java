package o;

import android.support.design.widget.CoordinatorLayout;
import android.view.ViewTreeObserver.OnPreDrawListener;

public class ab
  implements ViewTreeObserver.OnPreDrawListener
{
  public ab(CoordinatorLayout paramCoordinatorLayout) {}
  
  public boolean onPreDraw()
  {
    this.a.a(false);
    return true;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */