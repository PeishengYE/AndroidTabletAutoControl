package o;

public class aas
{
  public int a;
  public boolean b;
  public boolean c;
  public boolean d;
  
  public void a()
  {
    this.a = 0;
    this.b = false;
    this.c = false;
    this.d = false;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */