package o;

import android.os.Handler;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.PopupWindow;

class abf
  implements AbsListView.OnScrollListener
{
  private abf(aav paramaav) {}
  
  public void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    if ((paramInt == 1) && (!this.a.l()) && (aav.b(this.a).getContentView() != null))
    {
      aav.d(this.a).removeCallbacks(aav.c(this.a));
      aav.c(this.a).run();
    }
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */