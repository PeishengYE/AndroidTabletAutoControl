package o;

abstract interface abl
{
  public abstract yu a(int paramInt1, int paramInt2, int paramInt3, Object paramObject);
  
  public abstract void a(yu paramyu);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */