package o;

import java.util.ArrayList;
import java.util.List;

public abstract class abz
{
  private acb a = null;
  private ArrayList<aca> b = new ArrayList();
  private long c = 120L;
  private long d = 120L;
  private long e = 250L;
  private long f = 250L;
  
  public static int d(acv paramacv)
  {
    int j = acv.f(paramacv) & 0xE;
    int i;
    if (paramacv.n()) {
      i = 4;
    }
    int k;
    int m;
    do
    {
      do
      {
        do
        {
          do
          {
            return i;
            i = j;
          } while ((j & 0x4) != 0);
          k = paramacv.f();
          m = paramacv.e();
          i = j;
        } while (k == -1);
        i = j;
      } while (m == -1);
      i = j;
    } while (k == m);
    return j | 0x800;
  }
  
  public acc a(acs paramacs, acv paramacv)
  {
    return i().a(paramacv);
  }
  
  public acc a(acs paramacs, acv paramacv, int paramInt, List<Object> paramList)
  {
    return i().a(paramacv);
  }
  
  public abstract void a();
  
  public void a(acb paramacb)
  {
    this.a = paramacb;
  }
  
  public boolean a(acv paramacv, List<Object> paramList)
  {
    return g(paramacv);
  }
  
  public abstract boolean a(acv paramacv, acc paramacc1, acc paramacc2);
  
  public abstract boolean a(acv paramacv1, acv paramacv2, acc paramacc1, acc paramacc2);
  
  public abstract boolean b();
  
  public abstract boolean b(acv paramacv, acc paramacc1, acc paramacc2);
  
  public abstract void c();
  
  public abstract void c(acv paramacv);
  
  public abstract boolean c(acv paramacv, acc paramacc1, acc paramacc2);
  
  public long d()
  {
    return this.e;
  }
  
  public long e()
  {
    return this.c;
  }
  
  public final void e(acv paramacv)
  {
    f(paramacv);
    if (this.a != null) {
      this.a.a(paramacv);
    }
  }
  
  public long f()
  {
    return this.d;
  }
  
  public void f(acv paramacv) {}
  
  public long g()
  {
    return this.f;
  }
  
  public boolean g(acv paramacv)
  {
    return true;
  }
  
  public final void h()
  {
    int j = this.b.size();
    int i = 0;
    while (i < j)
    {
      ((aca)this.b.get(i)).a();
      i += 1;
    }
    this.b.clear();
  }
  
  public acc i()
  {
    return new acc();
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */