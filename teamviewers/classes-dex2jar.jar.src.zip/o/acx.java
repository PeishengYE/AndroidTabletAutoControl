package o;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;

class acx
  extends mf
{
  acx(acw paramacw) {}
  
  public void a(View paramView, rq paramrq)
  {
    super.a(paramView, paramrq);
    if ((!acw.a(this.b)) && (this.b.b.getLayoutManager() != null)) {
      this.b.b.getLayoutManager().a(paramView, paramrq);
    }
  }
  
  public boolean a(View paramView, int paramInt, Bundle paramBundle)
  {
    if (super.a(paramView, paramInt, paramBundle)) {
      return true;
    }
    if ((!acw.a(this.b)) && (this.b.b.getLayoutManager() != null)) {
      return this.b.b.getLayoutManager().a(paramView, paramInt, paramBundle);
    }
    return false;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */