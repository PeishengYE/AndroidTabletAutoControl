package o;

import android.util.SparseArray;
import android.util.SparseIntArray;
import java.util.ArrayList;

public class acl
{
  private SparseArray<ArrayList<acv>> a = new SparseArray();
  private SparseIntArray b = new SparseIntArray();
  private int c = 0;
  
  private ArrayList<acv> b(int paramInt)
  {
    ArrayList localArrayList2 = (ArrayList)this.a.get(paramInt);
    ArrayList localArrayList1 = localArrayList2;
    if (localArrayList2 == null)
    {
      localArrayList2 = new ArrayList();
      this.a.put(paramInt, localArrayList2);
      localArrayList1 = localArrayList2;
      if (this.b.indexOfKey(paramInt) < 0)
      {
        this.b.put(paramInt, 5);
        localArrayList1 = localArrayList2;
      }
    }
    return localArrayList1;
  }
  
  public acv a(int paramInt)
  {
    ArrayList localArrayList = (ArrayList)this.a.get(paramInt);
    if ((localArrayList != null) && (!localArrayList.isEmpty()))
    {
      paramInt = localArrayList.size() - 1;
      acv localacv = (acv)localArrayList.get(paramInt);
      localArrayList.remove(paramInt);
      return localacv;
    }
    return null;
  }
  
  public void a()
  {
    this.a.clear();
  }
  
  void a(abv paramabv)
  {
    this.c += 1;
  }
  
  void a(abv paramabv1, abv paramabv2, boolean paramBoolean)
  {
    if (paramabv1 != null) {
      b();
    }
    if ((!paramBoolean) && (this.c == 0)) {
      a();
    }
    if (paramabv2 != null) {
      a(paramabv2);
    }
  }
  
  public void a(acv paramacv)
  {
    int i = paramacv.h();
    ArrayList localArrayList = b(i);
    if (this.b.get(i) <= localArrayList.size()) {
      return;
    }
    paramacv.v();
    localArrayList.add(paramacv);
  }
  
  void b()
  {
    this.c -= 1;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/acl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */