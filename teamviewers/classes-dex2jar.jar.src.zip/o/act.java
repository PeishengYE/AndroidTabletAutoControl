package o;

import android.view.View;

public abstract class act
{
  public abstract View a(acm paramacm, int paramInt1, int paramInt2);
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/act.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */