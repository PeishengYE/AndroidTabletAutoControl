package o;

class aaf
{
  public acv a;
  public acv b;
  public int c;
  public int d;
  public int e;
  public int f;
  
  private aaf(acv paramacv1, acv paramacv2)
  {
    this.a = paramacv1;
    this.b = paramacv2;
  }
  
  private aaf(acv paramacv1, acv paramacv2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this(paramacv1, paramacv2);
    this.c = paramInt1;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = paramInt4;
  }
  
  public String toString()
  {
    return "ChangeInfo{oldHolder=" + this.a + ", newHolder=" + this.b + ", fromX=" + this.c + ", fromY=" + this.d + ", toX=" + this.e + ", toY=" + this.f + '}';
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aaf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */