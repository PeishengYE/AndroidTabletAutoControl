package o;

import android.support.v7.widget.RecyclerView;

public class abq
  implements Runnable
{
  public abq(RecyclerView paramRecyclerView) {}
  
  public void run()
  {
    if (this.a.g != null) {
      this.a.g.a();
    }
    RecyclerView.b(this.a, false);
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/abq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */