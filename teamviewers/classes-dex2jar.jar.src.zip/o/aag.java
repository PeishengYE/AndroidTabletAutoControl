package o;

class aag
{
  public acv a;
  public int b;
  public int c;
  public int d;
  public int e;
  
  private aag(acv paramacv, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.a = paramacv;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramInt3;
    this.e = paramInt4;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */