package o;

public final class aal
  extends aan
{
  public int a(int paramInt)
  {
    return 1;
  }
  
  public int a(int paramInt1, int paramInt2)
  {
    return paramInt1 % paramInt2;
  }
}


/* Location:              /home/yep/android_work/video_apks_to_test/reverse_engineering/teamviewer_reverse/unzipped/classes-dex2jar.jar!/o/aal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */